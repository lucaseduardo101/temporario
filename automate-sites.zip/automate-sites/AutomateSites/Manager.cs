﻿using System;
using System.IO;
using Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Linq;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Diagnostics;
using Automate;

namespace AutomateSites
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class Manager
    {
        static void Main(string[] args)
        {
            try
            {
                Automate.Manager manager = new Automate.Manager(args);
                
                string output = manager.Run();

                Console.WriteLine(output);
            }
            catch(System.Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
    }
}
