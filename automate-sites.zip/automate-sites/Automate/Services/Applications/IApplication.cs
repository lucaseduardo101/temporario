﻿using System;
using System.Collections.Generic;

namespace Automate.Services.Applications
{
    public interface IApplication
    {
        void Open(string url);
        void Open(IntPtr appHandle);

        void Close();

        void Fill(string target, string value, int waitTime);

        void Clear(string target, int waitTime);

        void Click(string target, int waitTime, string offset = "");

        void ClickByMouse(string target, int waitTime, string offset = "");

        void ClickByText(string target, int wait);
       
        void WaitShow(string target, int waitTime);

        bool ElementExistClass(string target, int wait);

        string Download(string target, string value, int waitTime);

        string Upload(string target, string value, int waitTime);
        
        string GetText(string target, int waitTime);

        string GetTextByClick(string target, int wait);

        List<string> GetAllTexts(string target, int wait);

        string GetTable(string target, int waitTime);

        void WaitPageLoad(int waitTime);

        void Captcha(string target, string value, int wait);

        bool ElementExist(string target, int wait);

        bool ElementExistId(string target, int wait);

        bool AlertExistClass(string target, int wait);

        void ClickAlert(string target, string value, int wait);

        void Navigate(string value, int wait);

        void NavigateToElement(string target, int wait);

        void SelectFromDropdown(string target, string value, int wait);

        string Print(string target, string value, int wait);

        void SwitchToTab(int ind);

        bool ElementIsEmpty(string target, int wait);

        void SwitchToFrame(string target, string value, int waitTime);

        void SwitchToMainFrame(int wait);

        string RunJavaScript(string value);

        string GetDropdownOptions(string target, string value, int wait);

        void WaitAlertOrElement(string target, int wait);

        bool AlertOrElementExist(string target, int wait);

        string GetAlertText(int wait);

        void AcceptAlert(int wait);

        string GetListOptions(string target, string value, int wait);

        string SaveFile(string value, int wait);

        int CountElements(string target, int wait);

        string GetAttribute(string target, string value, int wait);

        void TakeScreenshot(string value);

        void DownloadSetUp();

        string WaitDownload(int wait);

        Boolean DownloadCleanUp(string target, string value);

        Boolean OngoingDownload(int wait);

        void HideBrowser();

        void ShowBrowser();

        void ChangeWindowFocus(string value);

        List<string> GetAllAtributes(string target, string value, int wait);
    }
}
