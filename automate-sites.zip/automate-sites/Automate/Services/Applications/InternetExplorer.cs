﻿using Automate.Utils;
using OpenQA.Selenium.IE;
using System;

namespace Automate.Services.Applications
{
    class InternetExplorer : WebBrowser
    {
        protected override string BrowserWindow
        {
            get { return "IEFrame"; }
        }

        protected override string PrintKeys
        {
            get { return "^p"; }
        }

        protected override string[] DownloadExtensions
        {
            get { return new string[] { ".tmp" }; }
        }

        public override void Open(string url)
        {
            // Falta setar local padrao de download
            InternetExplorerOptions options = new InternetExplorerOptions();
            InternetExplorerDriverService service = InternetExplorerDriverService.CreateDefaultService(AppDomain.CurrentDomain.BaseDirectory);

            options.RequireWindowFocus = true;
            options.PageLoadStrategy = InternetExplorerPageLoadStrategy.Eager;
            options.UnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Accept;
            
            browser = new InternetExplorerDriver(service, options);
            browserHandle = UIAutomation.FindWindow(BrowserWindow, UIAutomation.GetActiveWindowTitle());
            if (!(url.StartsWith("https://") || url.StartsWith("http://")))
            {
                url = "http://" + url;
            }

            browser.Navigate().GoToUrl(url);
        }
    }
}
