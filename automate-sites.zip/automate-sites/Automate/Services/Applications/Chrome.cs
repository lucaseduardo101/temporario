﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using Automate.Utils;
using System.IO;
using OpenQA.Selenium.Remote;

namespace Automate.Services.Applications
{
    class Chrome : WebBrowser
    {
        protected override string BrowserWindow
        {
            get { return "Chrome_WidgetWin_1"; }
        }

        protected override string PrintKeys
        {
            get { return "^+p"; }
        }

        protected override string[] DownloadExtensions
        {
            get { return new string[] {".tmp", ".crdownload"}; }
        }

        public override void Open(string url)
        {
            ChromeOptions options = new ChromeOptions();
            DesiredCapabilities capabilities = DesiredCapabilities.Chrome();

            tempDownloadPath = Path.Combine(Manager.parameters.Get("$Caminho Download Final$").ToString(), "$Hera$");

            var downloadPrefs = new Dictionary<string, object>
            {
                {"default_directory", tempDownloadPath},
                {"directory_upgrade", true}
            };
            options.AddUserProfilePreference("download", downloadPrefs);
            options.AddUserProfilePreference("download.prompt_for_download", false);
            options.AddUserProfilePreference("plugins.plugins_disabled", new[] { "Chrome PDF Viewer" });
            options.AddArguments("--disable-extensions");
            options.AddArguments("--disable-gpu");

            capabilities.SetCapability(ChromeOptions.Capability, options);
            ChromeDriverService service = ChromeDriverService.CreateDefaultService(AppDomain.CurrentDomain.BaseDirectory);
            service.SuppressInitialDiagnosticInformation = true;

            browser = new ChromeDriver(service, options);
            browserHandle = UIAutomation.FindWindow(BrowserWindow, UIAutomation.GetActiveWindowTitle());
            if (!(url.StartsWith("https://") || url.StartsWith("http://")))
            {
                url = "http://" + url;
            }

            browser.Navigate().GoToUrl(url);
        }
    }
}
