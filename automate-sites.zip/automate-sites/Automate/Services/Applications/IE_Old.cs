﻿using System;
using mshtml;
using System.Threading;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Drawing.Imaging;
using System.Web.Script.Serialization;
using System.Collections.Generic;
using DeathByCaptcha;
using Automate.Utils;
using System.Diagnostics;
using UIAutomationClient;

namespace Automate.Services.Applications
{
    class IE_Old : IApplication
    {
        private SHDocVw.InternetExplorer browser;

        public void Open(string url)
        {
            browser = new SHDocVw.InternetExplorer();

            browser.Visible = true;
            browser.FullScreen = false;
            browser.Navigate2(url);
            UIAutomation.SetForegroundWindow((IntPtr) browser.HWND);
        }
        public void Open(IntPtr appHandle)
        {
            throw new NotImplementedException();
        }

        public void Close()
        {
            WaitBusy();
            browser.Quit();
        }

        public void Fill(string target, string value, int waitTime)
        {
            RunScript("document.querySelector(\"" + target + "\").innerText = \"" + value + "\";");
            SO.Wait(waitTime);
        }

        public void Clear(string target, int waitTime)
        {
            throw new NotImplementedException();
        }

        public void Click(string target, int waitTime, string offset = "")
        {
            RunScript("document.querySelector(\"" + target + "\").click();");
            SO.Wait(waitTime);
        }

        public void ClickByMouse(string target, int waitTime, string offset = "")
        {
            throw new NotImplementedException();
        }

        public void ClickByText(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public void WaitShow(string target, int waitTime)
        {
            int timeout = 0;
            while (browser.Document.IHTMLDocument3_getElementById(target) == null)
            {
                timeout += 200;

                if (timeout > waitTime)
                {
                    throw new Automate.Exceptions.TimeoutException(waitTime);
                }

                SO.Wait(200);
            }
        }

        private string ExistElementScript(string target)
        {
            return "var element = document.querySelector('" + target + "');"
                + "var retVal;"
                + "if(document.querySelector('#UiAutomationReturnElement') == null)"
                + "{"
                    + "var returnElement = document.createElement('div');"
                    + "returnElement.style.display = 'none';"
                    + "returnElement.setAttribute('id', 'UiAutomationReturnElement');"
                    + "document.body.appendChild(returnElement);"
                + "}"
                + "if (element == null)"
                + "{"
                    + "retVal = \"null\";"
                + "}"
                + "else"
                + "{"
                    + "retVal = \"exist\";"
                + "}"
                + "var returnElement = document.querySelector('#UiAutomationReturnElement');"
                + "returnElement.innerHTML = retVal;";
        }

        public bool ElementExist(string target, int wait)
        {
            Thread aThread = RunScript(ExistElementScript(target));
            aThread.Join();

            SO.Wait(wait);

            return browser.Document.IHTMLDocument3_getElementById("UiAutomationReturnElement").innerText == "exist";
        }

        public bool ElementExistId(string target, int wait)
        {
            return !(browser.Document.IHTMLDocument3_getElementById(target) == null);
        }

        public bool ElementExistClass(string target, int wait)
        {
            string[] words = target.Split('.');
            string tagName;
            string className;

            if(words.Length > 1)
            {
                tagName = words[0];
                className = words[1];
            } else
            {
                tagName = "*";
                className = target;
            }

            var elements = browser.Document.IHTMLDocument3_getElementsByTagName(tagName);
            foreach(var element in elements)
            {
                if(element.ClassName == className)
                {
                    return true;
                }
            }
            return false;
        }

        public string Download(string target, string value, int waitTime)
        {
            RunScript("document.querySelector(\"" + target + "\").click();");
            SO.Wait(waitTime);
            return SaveAs(value, Manager.parameters.Get("$Caminho Download Final$").ToString());
        }

        public string GetText(string target, int waitTime)
        {
            return GetElementText(target, waitTime);
        }

        public string GetTextByClick(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public List<string> GetAllTexts(string target, int wait)
        {
            return GetAllElementsTexts(target, wait);
        }

        public string GetTable(string target, int waitTime)
        {
            List<List<string>> table = GetTableElement(target, waitTime);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(table);
        }

        public void Captcha(string target, string value, int wait)
        {
            Image image;

            HTMLDocument objDoc            = (HTMLDocument)browser.Document;
            IHTMLElement2 body2            = (IHTMLElement2)objDoc.body;
       
            IHTMLControlRange controlRange = (IHTMLControlRange)body2.createControlRange();
            HTMLImg captcha                = browser.Document.IHTMLDocument3_getElementById(target);

            controlRange.add((mshtml.IHTMLControlElement)captcha);

            Thread closeAllowedCopyThread = new Thread(
                    delegate ()
                    {
                        waitAllowedCopyShowIE11();
                    });
            closeAllowedCopyThread.SetApartmentState(ApartmentState.STA);
            closeAllowedCopyThread.Start();
            controlRange.execCommand("Copy", false, System.Reflection.Missing.Value);
            closeAllowedCopyThread.Join();

            controlRange.remove(0);

            Thread clipboardThread = new Thread(
                    delegate ()
                    {
                        image = Clipboard.GetImage();

                        using (var msCaptcha = new MemoryStream())
                        {
                            image.Save(msCaptcha, ImageFormat.Png);

                            var client = new HttpClient("victor.campos", "vlc130192");
                            var res = client.Decode(msCaptcha.GetBuffer(), 20);
                            if (res != null && res.Solved && res.Correct)
                            {
                                Fill(value, res.Text, wait);
                            }
                        }
                    });

            clipboardThread.SetApartmentState(ApartmentState.STA);
            clipboardThread.Start();
            clipboardThread.Join();
        }

        private void waitAllowedCopyShowIE11()
        {
            Boolean waitAllowedCopy = true;

            while (waitAllowedCopy)
            {
                SO.Wait(200);
                string windowTitle = WindowTitle();
                IntPtr parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle);

                var childElement = UIAutomation.FindByName(parentHandle, "Permitir acesso");

                if(childElement != null)
                {
                    SendKeys.SendWait("%(p)");
                    SO.Wait(2000);
                    SendKeys.SendWait("p");
                    waitAllowedCopy = false;
                    break;
                }
            }
        }

        public string Print(string target, string value, int waitTime)
        {
            RunScript("window.print();");
            return PrintIE(target, value, waitTime);
        }

        private string WindowTitle()
        {          
            //return browser.LocationName + " - Windows Internet Explorer";
            UIAutomation.SetForegroundWindow((IntPtr) browser.HWND);
            string windowTitle = UIAutomation.GetActiveWindowTitle();
            return windowTitle;
        }

        private int Version()
        {
            var version = FileVersionInfo.GetVersionInfo(browser.FullName).FileVersion.Split('.')[0];
            return Convert.ToInt16(version);
        }

        private string PrintIE(string target, string value, int waitTime)
        {
            string windowTitle = WindowTitle();
            int i = waitTime;
            IntPtr parentHandle = IntPtr.Zero;

            IUIAutomationElement printElement = null;

            while (i > 0 && printElement == null)
            {
                parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle);

                if (parentHandle == IntPtr.Zero)
                {
                    parentHandle = UIAutomation.FindWindow("IEFrame", windowTitle);
                }

                printElement = UIAutomation.FindByName(parentHandle, target);
                SO.Wait(200);
                i -= 200;
            }

            if (printElement != null)
            {
                UIAutomation.click(printElement);

                i = waitTime;
                IntPtr saveASHandle = IntPtr.Zero;

                while(i > 0 && saveASHandle == IntPtr.Zero)
                {
                    saveASHandle = UIAutomation.FindWindow("#32770", "Save the file as");

                    if (saveASHandle == IntPtr.Zero)
                    {
                        saveASHandle = UIAutomation.FindWindow("#32770", "Save as");
                    }

                    SO.Wait(200);
                    i -= 200;
                }

                var painelElement = UIAutomation.FindByNameAndClass(saveASHandle, "File name:", "AppControlHost");

                if (painelElement != null)
                {
                    UIAutomation.fill(painelElement, value);
                    UIAutomation.click(UIAutomation.FindByName(saveASHandle, "Save"));

                    SO.Wait(100);

                    IntPtr saveAsDuplicateHandler = UIAutomation.FindWindow("#32770", "Confirm Save As");
                    if (saveAsDuplicateHandler != IntPtr.Zero)
                    {
                        UIAutomation.click(UIAutomation.FindByName(saveAsDuplicateHandler, "Yes"));
                    }
                }
            }

            return value;
        }

        public void Navigate(string value, int wait)
        {
            browser.Navigate(value);
            WaitBusy();
        }

        public void NavigateToElement(string target, int wait)
        {
            throw new NotImplementedException();
        }

        private void WaitBusy()
        {
            while (browser.Busy) { SO.Wait(200); }
        }

        public void ClickAlert(string targe, string value, int wait)
        {
            string windowTitle = WindowTitle();
            IntPtr parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle);

            var childElement = UIAutomation.FindByName(parentHandle, value);

            if (childElement != null)
            {
                childElement.SetFocus();
                UIAutomation.click(childElement);
            }
        }

        public bool AlertExistClass(string target, int wait)
        {
            SO.Wait(wait);
            string windowTitle = WindowTitle();
            IntPtr parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle); 
              
            if(parentHandle != null && parentHandle != IntPtr.Zero)
            {
                CUIAutomation UIA = UIAutomation.GetUIAutomation();
                IUIAutomationElement parentElement = UIA.ElementFromHandle(parentHandle).FindFirst(UIAutomationClient.TreeScope.TreeScope_Children, UIA.CreateTrueCondition());
                if (Convert.ToString(parentElement.CurrentName).Equals(Convert.ToString(target)))
                {
                    return true;
                }
            }

            return false;
        }

        private string SaveAs(string value, string downloadPath)
        {
            return SaveAsIE11(value, downloadPath);
        }

        private string SaveAsIE11(string value, string downloadPath)
        {
            string windowTitle = WindowTitle();
            IntPtr parentHandle = UIAutomation.FindWindow("IEFrame", windowTitle);

            UIAutomation.click(UIAutomation.FindByName(parentHandle, "Salvar"));

            while (true)
            {
                SO.Wait(200);
                var ctrlButton = UIAutomation.FindByName(parentHandle, "Abrir pasta");

                if (ctrlButton != null)
                {
                    string fileName = GetIE11FileDownloadName(parentHandle);

                    MoveFileToRightDownloadPathPath(downloadPath, fileName, value);
                    CloseDownloadBarIE11(parentHandle);

                    return Path.Combine(value, fileName);
                }
            }
        }
        
        private void CloseDownloadBarIE11(IntPtr parentHandle)
        {
            UIAutomation.click(UIAutomation.FindByName(parentHandle, "Fechar"));
        }

        private string GetIE11FileDownloadName(IntPtr parentHandle)
        {
            var ctrlButton = UIAutomation.FindByName(parentHandle, "Texto da Barra de notificação");
            if(ctrlButton != null)
            {
                string text = UIAutomation.GetText(ctrlButton);
                Match match = Regex.Match(text, @"Download\sde\s(.+)\sconcluído.", RegexOptions.IgnoreCase);
                if (match.Success)
                {
                    return match.Groups[1].Value;
                }
            }
            return "not_found";
        }

        private void MoveFileToRightDownloadPathPath(string downloadPath, string fileName, string value)
        {
            SO.MoveFile(Path.Combine(downloadPath, fileName), Path.Combine(value, fileName));
        }

        public void WaitPageLoad(int waitTime)
        {
            int timeout = 0;

            while (browser.ReadyState != SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE)
            {
                if (timeout > waitTime)
                {
                    throw new Automate.Exceptions.TimeoutException(waitTime);
                }

                SO.Wait(200);
            }
        }

        private Thread RunScript(string script)
        {
            WaitBusy();
            Thread aThread = new Thread(() => ExecuteJavaScriptWorker(script));
            aThread.SetApartmentState(ApartmentState.STA);
            aThread.Start();
            return aThread;
        }

        private void ExecuteJavaScriptWorker(string script)
        {
            mshtml.HTMLDocument doc = browser.Document;
            doc.parentWindow.execScript(script);
        }

        private string GetElementText(string target, int waitTime)
        {
            return GetAllElementsTexts(target, waitTime)[0];
        }

        private List<string> GetAllElementsTexts(string target, int wait)
        {
            Thread aThread  = RunScript(GetElementsScript(target));
            aThread.Join();

            string objetJSON = browser.Document.IHTMLDocument3_getElementById("UiAutomationReturnElement").innerText;

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Deserialize<List<string>>(objetJSON);
        }

        private string GetElementsScript(string target)
        {
            return "var elements = document.querySelectorAll('" + target + "');"
                + "var rowArray = [];"
                + "if(document.querySelector('#UiAutomationReturnElement') == null)"
                + "{"
                    + "var returnElement = document.createElement('div');"
                    + "returnElement.style.display = 'none';"
                    + "returnElement.setAttribute('id', 'UiAutomationReturnElement');"
                    + "document.body.appendChild(returnElement);"
                + "}"
                + "for(var i = 0; i < elements.length; i++) { rowArray.push(elements[i].innerText) };"
                + "var returnElement = document.querySelector('#UiAutomationReturnElement');"
                + "returnElement.innerHTML = JSON.stringify(rowArray);";
        }

        private List<List<string>> GetTableElement(string target, int waitTime)
        {

            RunScript("var tableInfo=document.querySelector('" + target + "');"
                + "var tableArray= [];"
                + ""
                + "for (var i = 0; i < tableInfo.rows.length; i++) {"
                    + "var row = tableInfo.rows[i];"
                    + "var rowArray = [];"
                    + "for(var j = 0; j < row.cells.length; j++) {"
                        + "rowArray.push(row.cells[j].textContent.trim());"
                    + "}"
                    + "tableArray.push(rowArray);"
                + "}"
                + ""
                + "if(document.querySelector('#UiAutomationReturnElement') == null)"
                + "{"
                    + "var returnElement = document.createElement('div');"
                    + "returnElement.style.display = 'none';"
                    + "returnElement.setAttribute('id', 'UiAutomationReturnElement');"
                    + "document.body.appendChild(returnElement);"
                + "}"
                + "var returnElement = document.querySelector('#UiAutomationReturnElement');"
                + "while (returnElement.firstChild) { returnElement.removeChild(returnElement.firstChild); }"
                + "returnElement.innerHTML = JSON.stringify(tableArray);");

            SO.Wait(waitTime);

            string objetJSON = browser.Document.IHTMLDocument3_getElementById("UiAutomationReturnElement").innerText;

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Deserialize<List<List<string>>>(objetJSON);
        }

        public void SelectFromDropdown(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public void SwitchToTab(int ind)
        {
            throw new NotImplementedException();
        }

        public bool ElementIsEmpty(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public void SwitchToFrame(string target, string value, int waitTime)
        {
            throw new NotImplementedException();
        }

        public void SwitchToMainFrame(int wait)
        {
            throw new NotImplementedException();
        }

        public string RunJavaScript(string value)
        {
            RunScript(value);
            return "Not Implemented";
        }

        public string GetDropdownOptions(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public void AcceptAlert(int wait)
        {
            throw new NotImplementedException();
        }

        public void WaitAlertOrElement(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public bool AlertOrElementExist(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public string GetAlertText(int wait)
        {
            throw new NotImplementedException();
        }

        public string GetListOptions(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public string SaveFile(string value, int wait)
        {
            throw new NotImplementedException();
        }

        public int CountElements(string target, int wait)
        {
            throw new NotImplementedException();
        }

        private string GetElementsAttributeScript(string target, string value)
        {
            return "var elements = document.querySelectorAll('" + target + "');"
                + "var rowArray = [];"
                + "if(document.querySelector('#UiAutomationReturnElement') == null)"
                + "{"
                    + "var returnElement = document.createElement('div');"
                    + "returnElement.style.display = 'none';"
                    + "returnElement.setAttribute('id', 'UiAutomationReturnElement');"
                    + "document.body.appendChild(returnElement);"
                + "}"
                + "for(var i = 0; i < elements.length; i++) { rowArray.push(elements[i].getAttribute('" + value + "')) };"
                + "var returnElement = document.querySelector('#UiAutomationReturnElement');"
                + "returnElement.innerHTML = JSON.stringify(rowArray);";
        }

        public string GetAttribute(string target, string value, int wait)
        {
            return GetAllElementsAttribute(target, value, wait)[0];
        }

        private List<string> GetAllElementsAttribute(string target, string value, int wait)
        {
            Thread aThread = RunScript(GetElementsAttributeScript(target, value));
            aThread.Join();

            SO.Wait(wait);
            string objectJSON = browser.Document.IHTMLDocument3_getElementById("UiAutomationReturnElement").innerText;

            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Deserialize<List<string>>(objectJSON);
        }

        public void TakeScreenshot(string value)
        {
            throw new NotImplementedException();
        }

        public void DownloadSetUp()
        {
            throw new NotImplementedException();
        }

        public string WaitDownload(int wait)
        {
            throw new NotImplementedException();
        }

        public Boolean DownloadCleanUp(string tempFile, string destFile)
        {
            throw new NotImplementedException();
        }

        public Boolean OngoingDownload(int wait)
        {
            throw new NotImplementedException();
        }
        public void HideBrowser()
        {
            throw new NotImplementedException();
        }

        public void ShowBrowser()
        {
            throw new NotImplementedException();
        }

        public List<string> GetAllAtributes(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public string Upload(string target, string value, int waitTime)
        {
            throw new NotImplementedException();
        }
        public void ChangeWindowFocus(string value)
        {
            throw new NotImplementedException();
        }
    }
}
