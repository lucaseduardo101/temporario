﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Automate.Exceptions
{
    class NonExistentLabelException : System.Exception
    {
        public NonExistentLabelException(string label) :
            base("O label \'" + label + "\' nao existe na planilha!")
        { }
    }
}
