﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Automate.Exceptions
{
    class TimeoutException : System.Exception
    {
        public TimeoutException(int wait) :
             base("O sistema demorou mais do que " + wait / 1000.0 + " segundos")
        { }

        public TimeoutException(string operation, int wait) :
            base("O(a) " +  operation + " demorou mais do que " + wait / 1000.0 + " segundos")
        { }
    }
}
