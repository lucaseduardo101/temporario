﻿using System.Runtime.InteropServices;
using System.Collections.Generic;
using Automate.Services.Applications;
using System.Text.RegularExpressions;
using Automate.Utils;
using System;

namespace Automate.Models
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class ManagerApps
    {
        private List<IApplication> apps;
        public IApplication activeApp { get; private set; }

        public ManagerApps()
        {
            apps = new List<IApplication>();
            activeApp = null;
        }

        public bool Contains(IApplication app)
        {
            return apps.Contains(app);
        }

        public int OpenApplication<ApplicationType>(string target) where ApplicationType : IApplication, new()
        {
            if (target == null) return 0;

            IApplication app;
            switch(GetActionType(target))
            {
                case "Reopen":
                    app = apps[int.Parse(target)];
                    break;
                case "Start New":
                    app = new ApplicationType();    
                    app.Open(target);
                    apps.Add(app);
                    break;
                case "Open":
                    string className = "";

                    if (Regex.Match(target, "(?i).*?(?:\")?className=(.*?)(?:\"| )* \"?windowTitle").Success)
                    {
                        className = Regex.Match(target, "(?i).*?(?:\")?className=(.*?)(?:\"| )* \"?windowTitle").Groups[1].Value;
                    }
                    else
                    {
                        className = null;
                    }
                   
                    string windowTitle = Regex.Match(target, "(?i).*?(?:\")?windowTitle=(.*?)(?:\"| )*$").Groups[1].Value.Trim();

                    IntPtr appHandle = UIAutomation.FindWindow(className, windowTitle);
                    if (appHandle == IntPtr.Zero)
                    {
                        foreach (System.Diagnostics.Process pList in System.Diagnostics.Process.GetProcesses())
                        {
                            if (pList.MainWindowTitle.IsLike(windowTitle))
                            {
                                appHandle = pList.MainWindowHandle;
                                break;
                            }
                        }
                        if (appHandle == IntPtr.Zero)
                        {
                            throw new Exception("Application with window title like " + windowTitle + " not found ");
                        }
                    }

                    UIAutomation.SetForegroundWindow(appHandle);

                    app = new ApplicationType();
                    app.Open(appHandle);
                    apps.Add(app);
                    break;
                default:
                    throw new Exception("Invalid OpenApplication Target Parameter");
            }

            activeApp = app;
            return apps.IndexOf(app); //return app id
        }

        public void Close()
        {
            foreach (var application in apps)
            {
                application.Close();
            }
        }

        public void Close(int appIndex)
        {
            apps[appIndex].Close();
        }

        private string GetActionType(string action)
        {
            int result;
            if(int.TryParse(action, out result))
            {
                return "Reopen";
            }

            else if (Regex.IsMatch(action, "(?i).*?windowTitle.*?"))
            {
                return "Open";
            }
            else
            {
                return "Start New";
            }
        }
    }
}
