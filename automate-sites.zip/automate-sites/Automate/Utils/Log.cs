﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;
using NLog.Config;
using NLog.Targets;

namespace Automate.Utils
{
    static class Log
    {
        private static Logger Instance { get; set; }

        static Log()
        {
            var config = new LoggingConfiguration();
            var fileTarget = new FileTarget();
            LogLevel logLevel;

            string fileName = Manager.parameters.Get("$logFileName$").ToString();
            string layout = Manager.parameters.Get("$logLayout$").ToString();
            string level = Manager.parameters.Get("$logLevel$").ToString();

            if (fileName == "")
            {
                fileName = "${basedir}/execution.log";
            }
            if (layout == "")
            {
                layout = "${stacktrace} - ${message}";
            }

            switch (level)
            {
                case "trace":
                    logLevel = LogLevel.Trace;
                    break;
                case "debug":
                    logLevel = LogLevel.Debug;
                    break;
                case "info":
                    logLevel = LogLevel.Info;
                    break;
                case "warn":
                    logLevel = LogLevel.Warn;
                    break;
                case "error":
                    logLevel = LogLevel.Error;
                    break;
                case "fatal":
                    logLevel = LogLevel.Fatal;
                    break;
                default:
                    logLevel = LogLevel.Debug;
                    break;
            }

            fileTarget.FileName = fileName;
            fileTarget.Layout = layout;
            fileTarget.DeleteOldFileOnStartup = true;

            var rule = new LoggingRule("*", logLevel, fileTarget);
            config.LoggingRules.Add(rule);

            LogManager.Configuration = config;
            LogManager.ReconfigExistingLoggers();
            Instance = LogManager.GetCurrentClassLogger();
        }

        public static void Trace(string str)
        {
            Instance.Trace(str); ;
        }

        public static void Debug(string str)
        {
            Instance.Debug(str);
        }

        public static void Info(string str)
        {
            Instance.Info(str);
        }

        public static void Warn(string str)
        {
            Instance.Warn(str);
        }

        public static void Error(string str)
        {
            Instance.Error(str);
        }

        public static void Fatal(string str)
        {
            Instance.Fatal(str);
        }
    }
}
