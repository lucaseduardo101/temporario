﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic.CompilerServices;


namespace Automate.Utils
{
    static class StringUtils
    {
        public static string EncodeString(string value)
        {
            StringBuilder sb = new StringBuilder();
            foreach (char c in value)
            {
                if (c > 127)
                {
                    string encodedValue = "\\u" + ((int)c).ToString("x4");
                    sb.Append(encodedValue);
                }
                else
                {
                    sb.Append(c);
                }
            }
            return sb.ToString();
        }

        public static bool IsLike(this string s, string pattern)
        {
            return LikeOperator.LikeString(s, pattern, Microsoft.VisualBasic.CompareMethod.Text);
        }
    }
}