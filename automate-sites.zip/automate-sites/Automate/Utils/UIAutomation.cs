﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using UIAutomationClient;

namespace Automate.Utils
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public static class UIAutomation
    {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr FindWindow(string className, string windowTitle);

        [DllImport("user32.dll", ExactSpelling = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern int GetWindowThreadProcessId(IntPtr handle, out int processID);

        [DllImport("user32.dll")]
        static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
        
        private static CUIAutomation UIA;

        public static CUIAutomation GetUIAutomation()
        {
            if (UIA == null)
            {
                UIA = new CUIAutomation();
            }
            return UIA;
        }

        public static IUIAutomationElement FindByAutomationId(IntPtr handle, string automationId)
        {
            return FindByAutomationId(handle, null, automationId);
        }

        public static IUIAutomationElement FindByAutomationId(IntPtr handle, IUIAutomationElement parentElement, string automationId)
        {
            IUIAutomationCondition condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_AutomationIdPropertyId, automationId);
            return FindFirst(handle, parentElement, condition);
        }

        public static IUIAutomationElement FindByName(IntPtr handle, string name)
        {
            return FindByName(handle, null, name);
        }

        public static IUIAutomationElement FindByName(IntPtr handle, IUIAutomationElement parentElement, string name)
        {
            IUIAutomationCondition condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_NamePropertyId, name);
            return FindFirst(handle, parentElement, condition);
        }

        public static IUIAutomationElement FindByNameAndClass(IntPtr handle, string name, string className)
        {
            return FindByNameAndClass(handle, null, name, className);
        }

        public static IUIAutomationElement FindByNameAndClass(IntPtr handle, IUIAutomationElement parentElement, string name, string className)
        {
            IUIAutomationCondition nameCondition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_NamePropertyId, name);
            IUIAutomationCondition classCondition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_ClassNamePropertyId, className);
            IUIAutomationCondition condition = GetUIAutomation().CreateAndCondition(nameCondition, classCondition);
            return FindFirst(handle, parentElement, condition);
        }

        public static IUIAutomationElement FindFirst(IntPtr handle, IUIAutomationElement element, IUIAutomationCondition condition)
        {
            if (element == null)
            {
                return GetUIAutomation().ElementFromHandle(handle).FindFirst(UIAutomationClient.TreeScope.TreeScope_Subtree, condition);
            }
            else
            {
                return element.FindFirst(UIAutomationClient.TreeScope.TreeScope_Subtree, condition);
            }
        }

        public static IUIAutomationElement FindByIndex(IntPtr handle, IUIAutomationElement element, IUIAutomationCondition condition, int index)
        {
            if (element == null)
            {
                return GetUIAutomation().ElementFromHandle(handle).FindAll(UIAutomationClient.TreeScope.TreeScope_Children, condition).GetElement(index);
            }
            else
            {
                return element.FindAll(UIAutomationClient.TreeScope.TreeScope_Children, condition).GetElement(index);
            }
        }

        public static object TryGetCurrentPattern(IUIAutomationElement element, int pattern)
        {
            try
            {
                return element.GetCurrentPattern(pattern);
            } 
            catch (Exception e)
            {
                return null;
            }
        }

        public static void click(IUIAutomationElement element, string offset = "")
        {
            object invokePattern = TryGetCurrentPattern(element, UIA_PatternIds.UIA_InvokePatternId);

            if (invokePattern != null)
            {
                try
                {
                    IUIAutomationInvokePattern pattern = (IUIAutomationInvokePattern) invokePattern;
                    pattern.Invoke();
                    return;
                }
                catch
                {
                    Log.Debug("Element: " + element.CurrentName + " invoke pattern exist but invoke failed");
                }
            }

            ManuallyClick(element, offset);
        }

        public static void ManuallyClick(IUIAutomationElement element, string offset = "")
        {
            tagPOINT point;
            double multX = 0.0;
            int incX = 0;
            double multY = 0.0;
            int incY = 0;

            if (offset != "" || element.GetClickablePoint(out point) == 0) // Null clickable point
            {
                InterpretOffset(offset, ref multX, ref incX, ref multY, ref incY);
                tagRECT rect = element.CurrentBoundingRectangle;

                point.x = rect.left + Convert.ToInt32(Convert.ToDouble(rect.right - rect.left) * multX) + incX;
                point.y = rect.top + Convert.ToInt32(Convert.ToDouble(rect.bottom - rect.top) * multY) + incY;

                Log.Debug("Ponto base " + rect.left + " | " + rect.right);
            }

            Log.Debug("Manual click " + point.x.ToString() + " " + point.y.ToString());
            SO.Click(point.x, point.y);
        }

        private static void InterpretOffset(string offset, ref double multX, ref int incX, ref double multY, ref int incY)
        {
            string[] aux;

            multX = 0.5; multY = 0.5; incX = 0; incY = 0;

            aux = offset.Replace(" ", "").Split('|');

            if (offset == "" || aux.Length > 2)
            {
                return;
            }

            try
            {
                if (aux[0].Contains("%"))
                {
                    multX = InterpretPercentage(aux[0]);
                }
                else
                {
                    incX = Convert.ToInt32(aux[0]);
                    multX = 0.0;
                }

                multY = multX;
                incY = incX;

                if (aux.Length == 2 && aux[1].Contains("%"))
                {
                    multY = InterpretPercentage(aux[1]);
                    incY = 0;
                }
                else if (aux.Length == 2)
                {
                    incY = Convert.ToInt32(aux[1]);
                    multY = 0.0;
                }
            }
            catch
            {
                Log.Debug("Formato errado no offset do click, clicando no meio do elemento, o padrão é: x[%] [ | y[%] ]");
                multX = 0.5;
                multY = 0.5;
                incX = 0;
                incY = 0;
            }

            Log.Debug("Multiplicadores de ponto x*" + multX.ToString() + " + " + incX.ToString() +
                        " | y*" + multY.ToString() + " + " + incY.ToString());
        }

        private static double InterpretPercentage(string offset)
        {
            return Convert.ToDouble(offset.Replace("%", "")) / 100.0;
        }

        public static void fill(IUIAutomationElement element, string value)
        {
            object valuePattern = TryGetCurrentPattern(element, UIA_PatternIds.UIA_ValuePatternId);
            if (valuePattern != null) // if (element == null || !element.Current.IsEnabled || !element.Current.IsKeyboardFocusable)
            {
                SO.Wait(200);
                ((IUIAutomationValuePattern)valuePattern).SetValue(value);
            }
            else
            {
                ManuallyFill(element, value);
            }
        }

        private static void ManuallyFill(IUIAutomationElement element, string value)
        {
            //Don't accept ValuePattern
            object isKeyboardFocusable = element.GetCurrentPropertyValueEx(UIA_PropertyIds.UIA_IsKeyboardFocusablePropertyId, 1);
            if (isKeyboardFocusable == GetUIAutomation().ReservedNotSupportedValue)
                click(element);
            else
                element.SetFocus();

            // Pause before sending keyboard input.
            SO.Wait(100);

            // Delete existing content in the control and insert new content.
            SO.TypeKeyboard("^{HOME}");   // Move to start of control
            SO.TypeKeyboard("^+{END}");   // Select everything
            SO.TypeKeyboard("{DEL}");     // Delete selection
            SO.TypeKeyboard(value);
        }

        public static string GetText(IUIAutomationElement element)
        {
            object patternObj;
            if (element == null || !(Boolean)element.GetCurrentPropertyValue(UIA_PropertyIds.UIA_IsEnabledPropertyId))
            {
                return (string)element.GetCurrentPropertyValue(UIA_PropertyIds.UIA_NamePropertyId);
            }
            else if ((patternObj = TryGetCurrentPattern(element, UIA_PatternIds.UIA_ValuePatternId)) != null)
            {
                return ((IUIAutomationValuePattern)patternObj).CurrentValue;
            }
            else if ((patternObj = TryGetCurrentPattern(element, UIA_PatternIds.UIA_TablePatternId)) != null)
            {
                return ((IUIAutomationTextPattern)patternObj).DocumentRange.GetText(-1).TrimEnd('\r'); // often there is an extra '\r' hanging off the end.
            }
            else
            {
                return (string) element.GetCurrentPropertyValue(UIA_PropertyIds.UIA_NamePropertyId);
            }
        }

        public static int GetSelectorIndex(string selector)
        {
            Match match = Regex.Match(selector, "(\"\\[)(\\d)(\\])$");
            if (match.Success)
            {
                return Int32.Parse(match.Groups[2].Value);
            }
            return 0;
        }

        public static string GetSelectorWithoutIndex(string selector)
        {
            string[] split = Regex.Split(selector, "(\"\\[)(\\d)(\\])$");
            return split[0].Replace("\"", String.Empty);
        }

        public static IUIAutomationElement GetElement(IntPtr handle, IUIAutomationElement parentElement, string stringSelector)
        {
            string[] selectors = Regex.Split(stringSelector, "[ ](?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)"); // Split by whitespace if not enclosured by double quotes

            IUIAutomationElement element = GetElementFromSingleSelector(handle, parentElement, GetSelectorWithoutIndex(selectors[0]), GetSelectorIndex(selectors[0]));

            foreach (string selector in selectors.Skip(1).ToArray())
            {
                element = GetElementFromSingleSelector(handle, element, GetSelectorWithoutIndex(selector), GetSelectorIndex(selector));
            }
            return element;
        }

        public static bool ElementExist(IntPtr handle, IUIAutomationElement parentElement, string stringSelector)
        {
            try
            {
                return GetElement(handle, parentElement, stringSelector) != null ? true : false;
            }
            catch (Exception e) // TODO tratar excecao especifica quando o elemento realmente nao existe
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public static string GetActiveWindowTitle()
        {
            const int nChars = 256;
            StringBuilder Buff = new StringBuilder(nChars);
            IntPtr handle = GetForegroundWindow();

            if (GetWindowText(handle, Buff, nChars) > 0)
            {
                return Buff.ToString();
            }
            return null;
        }

        private static IUIAutomationElement GetElementFromSingleSelector(IntPtr handle, IUIAutomationElement parentElement, string stringSelector, int index = 0)
        {
            // First item always a element, the others the functions
            string[] splittedSelector = Regex.Split(stringSelector, "(?<![\\\\]):");
            splittedSelector.Select(i => i.Replace("\\:", ":"));

            IUIAutomationElement element;
            if(splittedSelector[0].StartsWith("rootElement", StringComparison.CurrentCultureIgnoreCase))
            {
                element = GetUIAutomation().GetRootElement();
            }
            else
            {
                IUIAutomationCondition condition = GetCondition(splittedSelector[0]);
                if (index == 0)
                {
                    element = FindFirst(handle, parentElement, condition);
                }
                else
                {
                    element = FindByIndex(handle, parentElement, condition, index);
                }
            }
            return HandleSelectorFunctions(element, splittedSelector.Skip(1).ToArray());
        }

        private static IUIAutomationElement HandleSelectorFunctions(IUIAutomationElement element, string[] functions)
        {
            IUIAutomationTreeWalker treeWalker = GetUIAutomation().CreateTreeWalker(GetUIAutomation().CreateTrueCondition());
            foreach(string function in functions)
            {
                switch(function.ToLower())
                {
                    case "proximoirmao":
                        element = treeWalker.GetNextSiblingElement(element);
                        break;
                    case "pai":
                        element = treeWalker.GetParentElement(element);
                        break;
                    case "primeirofilho":
                        element = treeWalker.GetFirstChildElement(element);
                        break;
                    case "ultimofilho":
                        element = treeWalker.GetLastChildElement(element);
                        break;
                    case "irmaoanterior":
                        element = treeWalker.GetPreviousSiblingElement(element);
                        break;
                    default:
                        throw new Exception("Function \"" + function + "\" isn't recognized");
                }
            }

            return element;
        }

        private static IUIAutomationCondition GetCondition(string selector)
        {
            string matchValue;
            List<IUIAutomationCondition> conditions = new List<IUIAutomationCondition>();
            foreach (Match itemMatch in Regex.Matches(selector, "((?:(?<![\\\\])[#.@%]).+?)(?=(?<![\\\\])[@.#%]|$)"))
            {
                matchValue = itemMatch.Value.Replace("\\#", "#");
                matchValue = matchValue.Replace("\\.", ".");
                matchValue = matchValue.Replace("\\@", "@");
                matchValue = matchValue.Replace("\\%", "%");
                matchValue = matchValue.Trim('"');

                //Match everything between not escapeds brackets
                foreach (Match attributeMatch in Regex.Matches(matchValue, "(?<=(?<![\\\\])[[])(.*?)(?=(?<![\\\\])[]])"))
                {
                    string[] attributesAndValue = Regex.Split(attributeMatch.Value, "(?<![\\\\])=");
                    attributesAndValue.Select(i => i.Replace("\\=", "="));
                    conditions.Add(GetSingleCondition(attributesAndValue[0], attributesAndValue[1]));
                }

                matchValue.Replace("\\[", "[");
                conditions.Add(GetSingleCondition(matchValue.Split('[')[0]));
            }

            if(conditions.Count > 1)
            {
                return GetUIAutomation().CreateAndConditionFromArray(conditions.ToArray());
            }
            else if (conditions.Count == 1)
            {
                return conditions[0];
            }
            else
            {
                return null;
            }
        }

        private static IUIAutomationCondition GetSingleCondition(string selector)
        {
            IUIAutomationCondition condition;
            switch (selector[0])
            {
                case '#':
                    condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_AutomationIdPropertyId, selector.Substring(1));
                    break;
                case '.':
                    condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_ClassNamePropertyId, selector.Substring(1));
                    break;
                case '@':
                    condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_NamePropertyId, selector.Substring(1));
                    break;
                case '%':
                    condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_LocalizedControlTypePropertyId, selector.Substring(1));
                    break;
                default:
                    condition = GetUIAutomation().CreatePropertyCondition(UIA_PropertyIds.UIA_NamePropertyId, selector);
                    break;
            }
            return condition;
        }

        private static IUIAutomationCondition GetSingleCondition(string property, string value)
        {
            var fields = typeof(UIA_PropertyIds).GetFields();
            IUIAutomationCondition condition = null;

            foreach (var field in fields)
            {
                if (field.Name == "UIA_" + property + "PropertyId")
                {
                    condition = GetUIAutomation().CreatePropertyCondition((int)field.GetValue(null), value);
                }
            }
            return condition;
        }
    }
}
