﻿using System.Text;
using System.Windows.Xps.Packaging;

namespace Automate.Utils
{

    class XPS
    {        
        public static string Read(string fileName)
        {
            XpsDocument _xpsDocument = new XpsDocument(fileName, System.IO.FileAccess.Read);
            IXpsFixedDocumentSequenceReader fixedDocSeqReader
                = _xpsDocument.FixedDocumentSequenceReader;
            IXpsFixedDocumentReader _document = fixedDocSeqReader.FixedDocuments[0];
            string _fullPageText = "";
            try
            {
                for (int pageCount = 0; ; ++pageCount)
                {
                    IXpsFixedPageReader _page = _document.FixedPages[pageCount];
                    StringBuilder _currentText = new StringBuilder();
                    System.Xml.XmlReader _pageContentReader = _page.XmlReader;
                    if (_pageContentReader != null)
                    {
                        while (_pageContentReader.Read())
                        {
                            if (_pageContentReader.GetAttribute("UnicodeString") != null)
                            {
                                _currentText.
                                  Append(_pageContentReader.
                                  GetAttribute("UnicodeString"));
                            }
                        }
                    }
                    _fullPageText += _currentText.ToString();
                }
            } catch
            {
            }

            return _fullPageText;
        }
    }
}
