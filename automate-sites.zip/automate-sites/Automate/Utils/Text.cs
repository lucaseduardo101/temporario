﻿using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace Automate.Utils
{
    class Text
    {
        public static string SearchFor(string text, string pattern)
        {
            Regex rgx = new Regex(pattern);
            GroupCollection groupCollection = rgx.Match(text).Groups;
            
            return groupCollection.Count > 1 ? String.Join("\t", groupCollection.Cast<Group>()
                                                                                .ToArray()
                                                                                .Skip(1)
                                                                                .Select(g => g.Value)
                                                                                .Where(g => !string.IsNullOrEmpty(g))) : "";
        }

        internal static string Remove(string target, string pattern)
        {
            Regex rgx = new Regex(pattern);
            return rgx.Replace(target, "");
        }
    }
}
