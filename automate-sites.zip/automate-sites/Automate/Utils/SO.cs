﻿using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Automate.Utils
{
    static class SO
    {
        [DllImport("user32.dll", EntryPoint = "SetCursorPos")]
        public static extern bool SetCursorPos(int x, int y);

        [DllImport("user32.dll")]
        public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;

        public static string MoveFile(string source, string target)
        {
            if (source == target)
            {
                return target;
            }

            if (File.Exists(target))
            {
                File.Delete(target);
            }

            File.Move(source, target);

            return target;
        }

        public static string CreateFolder(string target)
        {
            Directory.CreateDirectory(target);
            return target;
        }

        public static string RemoveFolder(string target)
        {
            if (Directory.Exists(target))
            {
                Directory.Delete(target, true);
            }
            return target;
        }

        public static void Wait(int wait)
        {
            System.Threading.Thread.Sleep(wait);
        }

        public static void WriteToFile(string path, string text)
        {
            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine(text);
            }
        }

        public static void TypeKeyboard(string value, int wait = 0)
        {
            SendKeys.SendWait(value);
            Wait(wait);
        }

        public static void Click(int x, int y)
        {
            Cursor.Position = new Point(x, y);
            mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, x, y, 0, 0);
        }
    }
}
