﻿using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using System.Xml.Serialization;
using System.Linq;

namespace Automate.Models
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class ManagerReturn : IO
    {
        private string SerializeJSON()
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(parameters);
        }

        private string SerializeXML()
        {
            throw new System.NotImplementedException();
        }

        private string SerializePattern(string pattern)
        {
            string ret = "";

            foreach (string key in parameters.Keys)
            {
                if (ret != "")
                {
                    ret += '\n';
                }

                ret += pattern.Replace("$k$", key).Replace("$v$", parameters[key].ToString());
            }

            return ret;
        }

        public string Serialize(string typeOutput = "")
        {
            string ret;

            switch (typeOutput)
            {
                // Uses json when type is not defined
                case "":
                case "json":
                    ret = SerializeJSON();
                    break;
                case "xml":
                    ret = SerializeXML();
                    break;
                default:
                    ret = SerializePattern(typeOutput);
                    break;
            }

            Manager.parameters.Get("ola");

            return ret;
        }
    }
}
