﻿using System;
using System.Net;

namespace Automate.Models
{
    public class WebClientTimeout : WebClient
    {
        public int Timeout { get; private set; }

        public WebClientTimeout(int timeout)
        {
            this.Timeout = timeout;
        }

        protected override WebRequest GetWebRequest(Uri address)
        {
            var request = base.GetWebRequest(address);

            if (request != null)
            {
                request.Timeout = this.Timeout;
            }

            return request;
        }
    }
}