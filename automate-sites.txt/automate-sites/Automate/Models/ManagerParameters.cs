﻿using System;
using System.Linq;
using System.Runtime.InteropServices;

namespace Automate.Models
{
    [ComVisible(true)]
    [ClassInterface(ClassInterfaceType.AutoDual)]
    public class ManagerParameters : IO
    {
        public void Deserialize(string[] args)
        {
            foreach (string arg in args)
            {
                string[] splitedArg = arg.Split('=');

                string value = String.Join("=", splitedArg.Skip(1));

                Add(splitedArg[0], value.Trim('\r').Trim('\n'));
            }
        }
    }
}
