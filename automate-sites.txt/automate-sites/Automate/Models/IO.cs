﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace Automate.Models
{
    public abstract class IO
    {
        protected Dictionary<string, object> parameters;

        public IO()
        {
            this.parameters = new Dictionary<string, object>();
        }

        [ComVisible(true)]
        public List<string> Keys
        {
            get { return parameters.Keys.ToList(); }
        }

        [ComVisible(true)]
        public void Add(string key, object value)
        {
            if (ContainsKey(key))
            {
                this.parameters.Remove(key);
            }

            this.parameters.Add(key, value);
        }

        [ComVisible(true)]
        public Boolean ContainsKey(string key)
        {
            return parameters.ContainsKey(key);
        }

        [ComVisible(true)]
        public object Get(string xlsValue)
        {
            return ContainsKey(xlsValue) ? parameters[xlsValue] : "";
        }
    }
}
