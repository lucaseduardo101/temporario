﻿using Automate.Utils;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Threading;
using System.Windows.Forms;
using UIAutomationClient;

namespace Automate.Services.Applications
{
    class DesktopApp : IApplication
    {
        private Process process;
        private string tempDownloadPath;
        public IntPtr handle
        {
            get; private set;
        }

        public IUIAutomationElement parentElement
        {
            get; private set;
        }

        protected string[] DownloadExtensions
        {
            get { return new string[] { ".tmp" }; }
        }

        public void SetHandle(IntPtr hwnd)
        {
            handle = hwnd;
        }

        public void Open(string url)
        {            
            ProcessStartInfo procInfo = new ProcessStartInfo();
            procInfo.FileName = (url);
            process = Process.Start(procInfo);

            while (handle == IntPtr.Zero)
            {
                SO.Wait(250);
                handle = process.MainWindowHandle;
            }

            tempDownloadPath = Path.Combine(Manager.parameters.Get("$Caminho Download Final$").ToString(), "$Hera$");
        }

        public void Open(IntPtr appHandle)
        {
            ProcessStartInfo procInfo = new ProcessStartInfo();
            int processID;

            UIAutomation.GetWindowThreadProcessId(appHandle, out processID);
            process = Process.GetProcessById(processID);
            handle = appHandle;
            UIAutomation.SetForegroundWindow(handle);
            tempDownloadPath = Path.Combine(Manager.parameters.Get("$Caminho Download Final$").ToString(), "$Hera$");
        }

        public void Close()
        {
            //TODO: Find a better way
            process.Kill();
        }

        private IUIAutomationElement GetElement(string target, int wait)
        {
            IUIAutomationElement element = null;

            var stopwatch = new Stopwatch();
            stopwatch.Start();

            while (element == null && stopwatch.ElapsedMilliseconds <= wait)
            {
                SO.Wait(250);
                element = UIAutomation.GetElement(handle, parentElement, target);
            }

            if (element == null)
            {
                Log.Debug("Element " + target + " doesn't exist");
                throw new Exception("Element " + target + " doesn't exist");
            }

            return element;
        }

        public void Click(string target, int waitTime, string offset = "")
        {
            IUIAutomationElement element = GetElement(target, waitTime);
            UIAutomation.click(element, offset);
        }

        public void ClickByMouse(string target, int waitTime, string offset = "")
        {
            IUIAutomationElement element = GetElement(target, waitTime);
            UIAutomation.ManuallyClick(element, offset);
        }

        public void ClickByText(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public string Download(string target, string value, int waitTime)
        {
            throw new NotImplementedException();
        }

        public bool ElementExist(string target, int wait)
        {
            try
            {
                var stopwatch = new Stopwatch();
                stopwatch.Start();
                IUIAutomationElement element = null;
                while ((element = UIAutomation.GetElement(handle, parentElement, target)) == null)
                {
                    if (stopwatch.ElapsedMilliseconds > wait) return false;
                    SO.Wait(100);
                }
                stopwatch.Stop();
                return true;
            }
            catch (Exception e)
            {
                Log.Debug(e.StackTrace);
                Log.Info("Element does not exist.");
                return false;
            }
        }

        public bool ElementExistClass(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public void Fill(string target, string value, int waitTime)
        {
            IUIAutomationElement element = GetElement(target, waitTime);
            UIAutomation.fill(element, value);
        }

        public void Clear(string target, int waitTime)
        {
            throw new NotImplementedException();
        }

        public string GetTable(string target, int waitTime)
        {
            throw new NotImplementedException();
        }

        public string GetText(string target, int wait)
        {
            IUIAutomationElement element = GetElement(target, wait);
            return GetTextByPattern(element);
        }

        private string GetTextByPattern(IUIAutomationElement element)
        {
            object patternObj;

            if ((patternObj = UIAutomation.TryGetCurrentPattern(element, Utils.UIA_PatternIds.UIA_ValuePatternId)) != null)
            {
                return ((IUIAutomationValuePattern)patternObj).CurrentValue.Trim();
            }
            else if ((patternObj = UIAutomation.TryGetCurrentPattern(element, Utils.UIA_PatternIds.UIA_LegacyIAccessiblePatternId)) != null
                                            && ((IUIAutomationLegacyIAccessiblePattern)patternObj).CurrentValue.Trim() != "")
            {
                return ((IUIAutomationLegacyIAccessiblePattern)patternObj).CurrentValue.Trim();
            }
            else if ((patternObj = UIAutomation.TryGetCurrentPattern(element, Utils.UIA_PatternIds.UIA_TextPatternId)) != null)
            {
                return ((IUIAutomationTextPattern)patternObj).DocumentRange.GetText(-1).TrimEnd('\r').Trim();
            }
            else if ((patternObj = UIAutomation.TryGetCurrentPattern(element, Utils.UIA_PatternIds.UIA_TogglePatternId)) != null)
            {
                return ((IUIAutomationTogglePattern)patternObj).CurrentToggleState.ToString();
            }
            else
            {
                return element.CurrentName;
            }
        }

        public string GetTextByClick(string target, int wait)
        {
            string ret = "";
            Thread copyThreadh = new Thread(() => { ret = GetTextByClickThread(target, wait); });

            copyThreadh.SetApartmentState(ApartmentState.STA);
            copyThreadh.Start();
            copyThreadh.Join();

            return ret;
        }

        private string GetTextByClickThread(string target, int wait)
        {
            IUIAutomationElement element = GetElement(target, wait);

            UIAutomation.click(element);
            SO.TypeKeyboard("{END}+{HOME}^c");

            return System.Windows.Clipboard.GetText();
        }

        public List<string> GetAllTexts(string target, int wait)
        {
            IUIAutomationElement targetElement = GetElement(target, wait);
            List<string> allTexts = new List<string>();

            allTexts.Add(GetTextByPattern(targetElement));
            IUIAutomationElementArray elements = targetElement.FindAll(UIAutomationClient.TreeScope.TreeScope_Subtree, UIAutomation.GetUIAutomation().CreateTrueCondition());

            for (int i = 0; i < elements.Length; i++)
            {
                IUIAutomationElement element = elements.GetElement(i);
                allTexts.Add(GetTextByPattern(element));
            }

            return allTexts;
        }

        public List<string> GetAllAtributes(string target, string value, int wait)
        {
            IUIAutomationElement targetElement = GetElement(target, wait);
            List<string> allTexts = new List<string>();

            allTexts.Add(GetTextByPattern(targetElement));
            IUIAutomationElementArray elements = targetElement.FindAll(UIAutomationClient.TreeScope.TreeScope_Subtree, UIAutomation.GetUIAutomation().CreateTrueCondition());

            for (int i = 0; i < elements.Length; i++)
            {
                IUIAutomationElement element = elements.GetElement(i);
                switch (value.ToLower())
                {
                    case "nome":
                        allTexts.Add(element.CurrentName);
                        break;
                }                
            }

            return allTexts;
        }

        public void WaitPageLoad(int waitTime)
        {
            throw new NotImplementedException();
        }

        public void WaitShow(string target, int waitTime)
        {
            if (ElementExist(target, waitTime))
            {
                return;
            }
            else
            {
                throw new Exception("Element \"" + target + "\" Didn't Show");
            }
        }

        public void Captcha(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public bool ElementExistId(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public bool AlertExistClass(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public bool AlertOrElementExist(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public void ClickAlert(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public void AcceptAlert(int wait)
        {
            throw new NotImplementedException();
        }

        public void WaitAlertOrElement(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public string GetAlertText(int wait)
        {
            throw new NotImplementedException();
        }

        public void Navigate(string value, int wait)
        {
            NavigateToElement(value, wait);
        }

        public void NavigateToElement(string target, int wait)
        {
            IUIAutomationElement element = GetElement(target, wait);
            parentElement = element;
        }

        public string Print(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public void SelectFromDropdown(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public void SwitchToTab(int ind)
        {
            throw new NotImplementedException();
        }

        public bool ElementIsEmpty(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public void SwitchToFrame(string target, string value, int waitTime)
        {
            throw new NotImplementedException();
        }

        public void SwitchToMainFrame(int wait)
        {
            throw new NotImplementedException();
        }

        public string RunJavaScript(string value)
        {
            throw new NotImplementedException();
        }

        public string GetDropdownOptions(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public string GetListOptions (string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public int CountElements(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public string SaveFile(string value, int wait)
        {
            // TODO: Reuse same savefile for browser and desktopapp
            UIAutomation.SetForegroundWindow(handle);
            SendKeys.SendWait("^+s");

            if (!SaveRoutine(wait, value))
            {
                throw new Exceptions.TimeoutException("salvamento do arquivo", wait);
            }

            return value;
        }

        public Boolean SaveRoutine(int wait, string name)
        {
            Stopwatch stopwatch = new Stopwatch();
            IntPtr saveAsHandle = IntPtr.Zero;
            IUIAutomationElement saveInput = null;
            IUIAutomationElement saveWindowButton = null;
            string CODE = "#32770";
            int STEP = 300;

            ResourceManager rm = GetResourceManager();

            string saveAs = rm.GetString("SAVE_AS");
            string saveButton = rm.GetString("SAVE_BUTTON");
            string saveTheFileAs = rm.GetString("SAVE_THE_FILE_AS");
            string fileName = rm.GetString("FILE_NAME");

            stopwatch.Start();

            while (saveAsHandle == IntPtr.Zero)
            {
                SO.Wait(STEP);
                saveAsHandle = UIAutomation.FindWindow(CODE, saveTheFileAs);
                if (saveAsHandle == IntPtr.Zero)
                {
                    saveAsHandle = UIAutomation.FindWindow(CODE, saveAs);
                }

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            while (saveInput == null)
            {
                SO.Wait(STEP);
                saveInput = UIAutomation.FindByNameAndClass(saveAsHandle, fileName, "AppControlHost");

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            string tempFile = Path.Combine(tempDownloadPath, "Persephone");

            while (UIAutomation.GetText(saveInput) != tempFile)
            {
                UIAutomation.fill(saveInput, "");

                foreach (char c in tempFile)
                {
                    SO.TypeKeyboard(c.ToString(), 25);
                }
            }

            while (saveWindowButton == null)
            {
                SO.Wait(STEP);
                saveWindowButton = UIAutomation.FindByName(saveAsHandle, saveButton);

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            DownloadSetUp();

            UIAutomation.click(UIAutomation.FindByName(saveAsHandle, saveButton));

            return DownloadCleanUp(WaitDownload(wait - (int)stopwatch.ElapsedMilliseconds), name);
        }

        public string GetAttribute(string target, string value, int wait)
        {
            IUIAutomationElement targetElement = GetElement(target, wait);
            switch (value.ToLower())
            {
                case "nome":
                    return targetElement.CurrentName;
            }

            return "";
        }

        private ResourceManager GetResourceManager()
        {
            string language = CultureInfo.InstalledUICulture.TwoLetterISOLanguageName;
            if (language == "pt")
            {
                return new ResourceManager("Automate.PrintCommandsPt", Assembly.GetExecutingAssembly());
            }

            return new ResourceManager("Automate.PrintCommandsEng", Assembly.GetExecutingAssembly());
        }

        public void DownloadSetUp()
        {
            SO.RemoveFolder(tempDownloadPath);
            SO.CreateFolder(tempDownloadPath);
        }

        public string WaitDownload(int wait)
        {
            Stopwatch stopwatch = new Stopwatch();
            int STEP = 500;
            string file = "fail";
            Boolean finished = false;

            stopwatch.Start();

            while (!finished)
            {
                SO.Wait(STEP);
                finished = true;

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    Log.Debug("Download timeout!");
                    return "$error$";
                }

                try
                {
                    file = Directory.GetFiles(tempDownloadPath)[0];

                    if (file.EndsWith(".xps"))
                    {
                        var aux = File.Open(file, FileMode.Open);
                        aux.Close();
                    }
                }
                catch
                {
                    finished = false;
                    continue;
                }

                foreach (string extension in DownloadExtensions)
                {
                    if (file.EndsWith(extension))
                    {
                        finished = false;
                        break;
                    }
                }
            }

            return file;
        }

        public Boolean DownloadCleanUp(string tempFile, string destFile)
        {
            Boolean res = true;

            try
            {
                SO.MoveFile(tempFile, destFile);
            }
            catch (System.Exception e)
            {
                Log.Debug("Failed to move temp file.");
                res = false;
            }

            SO.RemoveFolder(tempDownloadPath);

            return res;
        }

        public void TakeScreenshot(string value)
        {
            throw new NotImplementedException();
        }

        public Boolean OngoingDownload(int wait)
        {
            throw new NotImplementedException();
        }

        public void HideBrowser()
        {
            throw new NotImplementedException();
        }

        public void ShowBrowser()
        {
            throw new NotImplementedException();
        }

        public string Upload(string target, string value, int waitTime)
        {
            throw new NotImplementedException();
        }
        public void ChangeWindowFocus(string value)
        {
            throw new NotImplementedException();
        }
    }
}
