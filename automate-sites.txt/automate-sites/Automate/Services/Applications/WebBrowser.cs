﻿using System;
using System.Collections.Generic;
using OpenQA.Selenium;
using Automate.Utils;
using System.Web.Script.Serialization;
using System.Collections.ObjectModel;
using System.Drawing;
using System.IO;
using System.Drawing.Imaging;
using DeathByCaptcha;
using OpenQA.Selenium.Support.UI;
using System.Windows.Forms;
using System.Globalization;
using System.Resources;
using System.Reflection;
using System.Diagnostics;
using UIAutomationClient;

namespace Automate.Services.Applications
{
    abstract class WebBrowser : IApplication
    {
        protected IWebDriver browser;
        protected IntPtr browserHandle;
        protected string tempDownloadPath;
        protected abstract string BrowserWindow { get; }
        protected abstract string PrintKeys { get; }
        protected abstract string[] DownloadExtensions { get; }

        public abstract void Open(string url);

        public void Open(IntPtr appHandle)
        {
            throw new NotImplementedException();
        }

        public virtual void Close()
        {
            browser.Quit();
        }

        public bool ElementExist(string target, int wait)
        {
            try
            {
                WaitShow(target, wait);
                return true;
            }
            catch
            {
                Log.Info("Element" + target + " does not exist");
                return false;
            }
        }

        public void WaitShow(string target, int waitTime)
        {
            try
            {
                if (waitTime > 0)
                {
                    WebDriverWait wait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(waitTime));
                    wait.Until(ExpectedConditions.ElementIsVisible(By.CssSelector(target)));
                }
            }
            catch (UnhandledAlertException)
            {
                SendKeys.SendWait("~"); //Enter Key
                WaitShow(target, waitTime);
            }
        }

        public bool ElementExistClass(string target, int wait)
        {
            SO.Wait(wait);
            return browser.FindElement(By.ClassName(target)).Displayed;
        }

        public bool ElementExistId(string target, int wait)
        {
            SO.Wait(wait);
            return browser.FindElement(By.Id(target)).Displayed;
        }

        public void Click(string target, int waitTime, string offset = "")
        {
            WaitShow(target, waitTime);
            browser.FindElement(By.CssSelector(target)).Click();
        }

        public void ClickByMouse(string target, int waitTime, string offset = "")
        {
            throw new NotImplementedException();
        }

        public void ClickByText(string target, int wait)
        {
            WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(wait));

            try
            {
                webWait.Until(ExpectedConditions.ElementIsVisible(By.PartialLinkText(target)));
                browser.FindElement(By.PartialLinkText(target)).Click();
            }
            catch
            {
                Log.Debug("Didn't find element by text '" + target + "'");
            }
        }

        public void Fill(string target, string value, int waitTime)
        {
            WaitShow(target, waitTime);
            browser.FindElement(By.CssSelector(target)).SendKeys(value);
        }

        public void Clear(string target, int waitTime)
        {
            WaitShow(target, waitTime);
            browser.FindElement(By.CssSelector(target)).Clear();
        }

        public bool ElementIsEmpty(string target, int wait)
        {
            return GetText(target, wait) == "";
        }

        public string GetText(string target, int waitTime)
        {
            try
            {
                WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(waitTime));
                webWait.Until(driver => { return GetTextByTag(target) != ""; });

                return GetTextByTag(target);
            }
            catch (System.Exception)
            {
                return "";
            }
        }

        private string GetTextByTag(string target)
        {
            var elem = browser.FindElement(By.CssSelector(target));

            switch (elem.TagName)
            {
                case "input":
                    return RunJavaScript("return document.querySelector(\"" + target + "\").value");
                case "select":
                    var mySelect = new SelectElement(elem);
                    return mySelect.SelectedOption.Text.Trim();
                default:
                    return elem.Text;
            }
        }

        public string GetTextByClick(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public List<string> GetAllTexts(string target, int wait)
        {
            ReadOnlyCollection<IWebElement> allElements = browser.FindElements(By.CssSelector(target));
            List<string> allTexts = new List<string>();

            foreach (IWebElement element in allElements)
            {
                allTexts.Add(element.Text);
            }

            return allTexts;
        }

        public void SwitchToFrame(string target, string value, int waitTime)
        {
            WaitShow(target, waitTime);
            browser.SwitchTo().Frame(browser.FindElement(By.CssSelector(target)));
        }

        public void SwitchToMainFrame(int wait)
        {
            WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(wait));
            webWait.Until(driver => { browser.SwitchTo().DefaultContent(); return true; });
        }

        public void DownloadSetUp()
        {
            SO.RemoveFolder(tempDownloadPath);
            SO.CreateFolder(tempDownloadPath);
        }

        public Boolean DownloadCleanUp(string tempFile, string destFile)
        {
            Boolean res = true;

            try
            {
                SO.MoveFile(tempFile, destFile);
            }
            catch (System.Exception e)
            {
                Log.Debug("Failed to move temp file.");
                res = false;
            }

            SO.RemoveFolder(tempDownloadPath);

            return res;
        }

        public string WaitDownload(int wait)
        {
            Stopwatch stopwatch = new Stopwatch();
            int STEP = 500;
            string file = "fail";
            Boolean finished = false;

            stopwatch.Start();

            while (!finished)
            {
                SO.Wait(STEP);
                finished = true;

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    Log.Debug("Download timeout!");
                    return "$error$";
                }

                try
                {
                    file = Directory.GetFiles(tempDownloadPath)[0];

                    if (file.EndsWith(".xps"))
                    {
                        var aux = File.Open(file, FileMode.Open);
                        aux.Close();
                    }
                }
                catch
                {
                    finished = false;
                    continue;
                }

                foreach (string extension in DownloadExtensions)
                {
                    if (file.EndsWith(extension))
                    {
                        finished = false;
                        break;
                    }
                }
            }

            return file;
        }

        public Boolean OngoingDownload(int wait)
        {
            try
            {
                WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(wait));
                webWait.Until(driver => { return Directory.GetFiles(tempDownloadPath).Length > 0; });

                return true;
            }
            catch
            {
                return false;
            }
        }

        public string Download(string target, string fileName, int waitTime)
        {
            Stopwatch stopwatch = new Stopwatch();

            stopwatch.Start();

            DownloadSetUp();
            Click(target, waitTime);

            if (!DownloadCleanUp(WaitDownload(waitTime - (int)stopwatch.ElapsedMilliseconds), fileName))
            {
                return "failure";
            }

            return fileName;
        }

        public void AcceptAlert(int wait)
        {
            try
            {
                WaitAlertOrElement("", wait);
                browser.SwitchTo().Alert().Accept();
            }
            catch
            {

            }
        }

        public void WaitAlertOrElement(string target, int wait)
        {
            if (wait > 0)
            {
                WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(wait));
                webWait.Until(driver => {
                    if (ExpectedConditions.AlertIsPresent().Invoke(driver) != null)
                        return true;

                    if (target == "")
                        return false;

                    return driver.FindElement(By.CssSelector(target)) != null;
                });
            }
        }

        public bool AlertOrElementExist(string target, int wait)
        {
            try
            {
                WaitAlertOrElement(target, wait);
                return true;
            }
            catch
            {
                Log.Debug("Nor the alert nor the element " + target + " exist!");
                return false;
            }
        }

        public string GetAlertText(int wait)
        {
            try
            {
                WaitAlertOrElement("", wait);
                return browser.SwitchTo().Alert().Text;
            }
            catch
            {
                return "";
            }
        }

        public bool AlertExistClass(string target, int wait)
        {
            string windowTitle = browser.Title;
            IntPtr parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle);

            if (parentHandle != null && parentHandle != IntPtr.Zero)
            {
                IUIAutomationElement parentElement = UIAutomation.GetUIAutomation().ElementFromHandle(parentHandle).FindFirst(UIAutomationClient.TreeScope.TreeScope_Children, UIAutomation.GetUIAutomation().CreateTrueCondition());
                if (Convert.ToString(parentElement.CurrentName).Equals(Convert.ToString(target)))
                {
                    return true;
                }
            }
            return false;
        }

        public void ClickAlert(string target, string value, int wait)
        {
            string windowTitle = browser.Title;
            IntPtr parentHandle = UIAutomation.FindWindow("Alternate Modal Top Most", windowTitle);

            var childElement = UIAutomation.FindByName(parentHandle, value);

            if (childElement != null)
            {
                childElement.SetFocus();
                UIAutomation.click(childElement);
            }
        }

        public void Captcha(string target, string value, int wait)
        {
            System.Threading.Thread.Sleep(2000);
            ITakesScreenshot screenshotDriver = browser as ITakesScreenshot;
            var screenshot = screenshotDriver.GetScreenshot().AsByteArray;
            using (var msScreen = new MemoryStream(screenshot))
            {
                var bmpScreen = new Bitmap(msScreen);
                var cap = browser.FindElement(By.Id(target));
                var rcCrop = new Rectangle(cap.Location, cap.Size);
                Image imgCap = bmpScreen.Clone(rcCrop, bmpScreen.PixelFormat);

                using (var msCaptcha = new MemoryStream())
                {
                    imgCap.Save(msCaptcha, ImageFormat.Png);

                    // put your DeathByCaptcha credentials here
                    var client = new SocketClient("victor.campos", "vlc130192");

                    Console.WriteLine("Sending request to DeathByCaptcha...");
                    var res = client.Decode(msCaptcha.GetBuffer(), 20);
                    if (res != null && res.Solved && res.Correct)
                    {
                        browser.FindElement(By.CssSelector(value)).SendKeys(res.Text);
                    }
                    else
                        Console.WriteLine("Captcha recognition error occured");
                }
            }
        }

        public string GetTable(string target, int waitTime)
        {
            List<List<string>> allElements = new List<List<string>>();
            IWebElement tableElement = browser.FindElement(By.CssSelector(target));
            IList<IWebElement> tableRows = tableElement.FindElements(By.TagName("tr"));
            IList<IWebElement> rowTD;

            foreach (IWebElement row in tableRows)
            {
                List<string> elementsOfRow = new List<string>();
                rowTD = row.FindElements(By.TagName("td"));
                foreach(IWebElement td in rowTD)
                {
                    try
                    {
                        elementsOfRow.Add(td.Text);
                    }
                    catch (System.Exception)
                    {

                    }
                }
                allElements.Add(elementsOfRow);
            }

            SO.Wait(waitTime);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(allElements);            
        }

        public string GetDropdownOptions(string target, string value, int wait)
        {
            int i = 0;
            List<string> allValues = new List<string>();
            IWebElement dropDown = browser.FindElement(By.CssSelector(target));
            IList<IWebElement> dropDownList = dropDown.FindElements(By.TagName("option"));
            
            if (value == "true")
            {
                i = 1;
            }
            
            for (; i < dropDownList.Count ; i++)
            {
                IWebElement option = dropDownList[i];
                allValues.Add(option.Text);
            }
           
            SO.Wait(wait);
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(allValues);   
        }

        public string GetListOptions(string target, string value, int wait)
        {
            IWebElement list = browser.FindElement(By.CssSelector(target));
            IList<IWebElement> listValues = list.FindElements(By.TagName("li"));
            string text = "";

            foreach (IWebElement li in listValues)
            {
                text = text + '\n' + li.Text;
            }
            SO.Wait(wait);
            return text;
        }

        public void Navigate(string value, int wait)
        {
            browser.Navigate().GoToUrl(value);
        }

        public void NavigateToElement(string target, int wait)
        {
            throw new NotImplementedException();
        }

        public string Print(string target, string value, int waitTime)
        {
            Stopwatch stopwatch = new Stopwatch();
            IntPtr printHandle = IntPtr.Zero;
            IUIAutomationElement printElement = null;
            string CODE = "#32770";
            int STEP = 300;

            ResourceManager rm = GetResourceManager();

            string print = rm.GetString("PRINT");

            UIAutomation.SetForegroundWindow(browserHandle);
            SendKeys.SendWait(PrintKeys);

            stopwatch.Start();

            while (printHandle == IntPtr.Zero)
            {
                SO.Wait(STEP);
                printHandle = UIAutomation.FindWindow(CODE, print);

                if (stopwatch.ElapsedMilliseconds > waitTime)
                {
                    throw new Exceptions.TimeoutException("impressao do arquivo", waitTime);
                }
            }

            while (printElement == null)
            {
                SO.Wait(STEP);
                printElement = UIAutomation.FindByName(printHandle, target);

                if (stopwatch.ElapsedMilliseconds > waitTime)
                {
                    throw new Exceptions.TimeoutException("impressao do arquivo", waitTime);
                }
            }

            UIAutomation.click(printElement);

            if (!SaveRoutine(waitTime - (int)stopwatch.ElapsedMilliseconds, value))
            {
                throw new Exceptions.TimeoutException("impressao do arquivo", waitTime);
            }

            return value;
        }

        private ResourceManager GetResourceManager()
        {
            string language = CultureInfo.InstalledUICulture.TwoLetterISOLanguageName;
            if (language == "pt")
            {
                return new ResourceManager("Automate.PrintCommandsPt", Assembly.GetExecutingAssembly());
            }

            return new ResourceManager("Automate.PrintCommandsEng", Assembly.GetExecutingAssembly());
        }

        public Boolean SaveRoutine(int wait, string name)
        {
            Stopwatch stopwatch = new Stopwatch();
            IntPtr saveAsHandle = IntPtr.Zero;
            IUIAutomationElement saveInput = null;
            IUIAutomationElement saveWindowButton = null;
            string CODE = "#32770";
            int STEP = 300;

            ResourceManager rm = GetResourceManager();

            string saveAs = rm.GetString("SAVE_AS");
            string saveButton = rm.GetString("SAVE_BUTTON");
            string saveTheFileAs = rm.GetString("SAVE_THE_FILE_AS");
            string fileName = rm.GetString("FILE_NAME");

            stopwatch.Start();

            while (saveAsHandle == IntPtr.Zero)
            {
                SO.Wait(STEP);
                saveAsHandle = UIAutomation.FindWindow(CODE, saveTheFileAs);
                if (saveAsHandle == IntPtr.Zero)
                {
                    saveAsHandle = UIAutomation.FindWindow(CODE, saveAs);
                }

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            while (saveInput == null)
            {
                SO.Wait(STEP);
                saveInput = UIAutomation.FindByNameAndClass(saveAsHandle, fileName, "AppControlHost");

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            UIAutomation.fill(saveInput, Path.Combine(tempDownloadPath, "Persephone"));

            while (saveWindowButton == null)
            {
                SO.Wait(STEP);
                saveWindowButton = UIAutomation.FindByName(saveAsHandle, saveButton);

                if (stopwatch.ElapsedMilliseconds > wait)
                {
                    return false;
                }
            }

            DownloadSetUp();

            UIAutomation.click(UIAutomation.FindByName(saveAsHandle, saveButton));

            return DownloadCleanUp(WaitDownload(wait - (int)stopwatch.ElapsedMilliseconds), name);
        }

        public string SaveFile(string value, int wait)
        {
            // Nao funciona no IE devido ao nome da janela de salvar, tambem nao funcionava antes do WebBrowser
            UIAutomation.SetForegroundWindow(browserHandle);
            SendKeys.SendWait("^s");

            if (!SaveRoutine(wait, value))
            {
                throw new Exceptions.TimeoutException("salvamento do arquivo", wait);
            }

            return value;
        }

        public void WaitPageLoad(int waitTime)
        {
            try
            {
                WebDriverWait webWait = new WebDriverWait(browser, TimeSpan.FromMilliseconds(waitTime));

                webWait.Until(driver => {
                    if (browser.WindowHandles.Count == 1)
                    {
                        SwitchToTab(0);
                    }
                    return RunJavaScript("return document.readyState") == "complete";
                });
            }
            catch
            {
                Log.Debug("Page didn't load");
            }
        }

        public void SelectFromDropdown(string target, string value, int wait)
        {
            WaitShow(target, wait);
            // select the drop down list
            var education = browser.FindElement(By.CssSelector(target));
            //create select element object
            var selectElement = new SelectElement(education);
            //create list of options from the dropdown
            var options = selectElement.Options;
            
            foreach (var option in options)
            {
                if (option.Text.IsLike(value))
                {
                    selectElement.SelectByText(option.Text);
                    return;
                }
            }
            // if no value like option is found, it tries to select the exact value
            selectElement.SelectByText(value);
        }

        public void SwitchToTab(int ind)
        {
            try
            {
                browser.SwitchTo().Window(browser.WindowHandles[ind]);
            }
            catch
            {
                Log.Debug("Tab doesn't exist.");
            }
        }

        public string RunJavaScript(string value)
        {
            IJavaScriptExecutor js = (IJavaScriptExecutor)browser;
            return (string)js.ExecuteScript(value);
        }

        public int CountElements(string target, int wait)
        {
            WaitShow(target, wait);
            return browser.FindElements(By.CssSelector(target)).Count;
        }

        public string GetAttribute(string target, string value, int wait)
        {
            WaitShow(target, wait);
            return browser.FindElement(By.CssSelector(target)).GetAttribute(value);
        }

        public void TakeScreenshot(string fileName)
        {
            ITakesScreenshot screenshotDriver = browser as ITakesScreenshot;
            var screenshot = screenshotDriver.GetScreenshot();

            screenshot.SaveAsFile(fileName, ScreenshotImageFormat.Jpeg);
        }

        public void HideBrowser()
        {
            browser.Manage().Window.Position = new System.Drawing.Point(-1000, -1000);
        }

        public void ShowBrowser()
        {
            browser.Manage().Window.Position = new System.Drawing.Point(0, 0);
        }

        public List<string> GetAllAtributes(string target, string value, int wait)
        {
            throw new NotImplementedException();
        }

        public string Upload(string target, string value, int waitTime)
        {

            //System.Windows.Automation.AutomationElement e = System.Windows.Automation.AutomationElement.FromHandle(browserHandle);
            //int[] runtimeIdentifier = (int[])e.GetRuntimeId();
            //Console.WriteLine(runtimeIdentifier);

            DesktopApp desktopApp = new DesktopApp();
            desktopApp.SetHandle(this.browserHandle);
            desktopApp.NavigateToElement(target, waitTime);
            desktopApp.Fill(".Edit", value, waitTime);
            desktopApp.Click(target+":primeiroFilho:proximoIrmao:proximoIrmao:proximoIrmao:proximoIrmao", waitTime);
            
            //desktopApp.Click("%text", 10000);


            //IUIAutomationElement E = UIAutomation.FindFirst(this.browserHandle, null, null);
            return null;
        }

        public void ChangeWindowFocus(string value)
        {
            int index = 0;

            if(Int32.TryParse(value,out index))
            browser.SwitchTo().Window(browser.WindowHandles[index]);
        }

    }
}
