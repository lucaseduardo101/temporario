﻿/*
 * Created by SharpDevelop.
 * User: hannahm
 * Date: 08/09/2017
 * Time: 11:14
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using Mailbot.Data.Entity;


namespace Mailbot.Data
{
	/// <summary>
	/// Description of IMobiosDataAdapter.
	/// </summary>
	public interface IMobiosDataAdapter
	{
		int RegistrarServico(Servico novoServico);		
		int BuscarIDServico(string CaixaEntrada, DateTime dataRecebimento);
		void RegistrarFluxoServico(FluxoServico novoFluxoServico);
		void RegistrarDadosServico(DadosServico dadosServico);
		void RegistrarDadosFollowUp(DadosFollowUp dadosFollowUp);
		bool ExisteConversationID(string CID);        
        void RegistrarAnexos(DadosAnexo anexo);
        bool ExisteAnexo(DadosAnexo anexo);
        int GetServicoByEmailConversationId(string conversationId);  
        int getEtapaAtual(int ID_Servico);
        void ReabrirChamado(int servicoPaiId, int servicoFilhoId);
        void CreateServicoConversationId(int novoServicoId, string conversationId);
        int GetCampoIDByNome(string nome);
        void RegistrarFollowUpEtapaServico(FollowUp FollowUpDados);
        void AlterarStatusEtapa(int servicoId, int ID_Status, int ID_Etapa = -1, bool reabrir = false);
        bool HasStatus(int idServico, int idEtapa, int idStatus);
        bool IsServicoPortalTEF(int servicoId);
        int GetServicoTo(int servicoId);
        bool VerificaObjetoFluxoAreas(int servicoID);
        DataTable BuscarConstantes();
        bool ValidaFluxoAreas(int IdServico);
        void RegistrarFluxosServico(int servicoId, int idObjeto, string SistemaLog = "");
        void RegistrarDadosStatusEtapa(int servicoId, int ID_Status, int ID_Etapa);
        void ReabrirServico(int servicoId);
        bool IsConcluido(int servicoId);
        int GetObjetoIdByName(string nomeObjeto);
        int GetSegmentoIdByName(string nomeSegmento);
	}
}
