﻿/*
 * Created by SharpDevelop.
 * User: hannahm
 * Date: 08/09/2017
 * Time: 11:54
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using ItauBE.Core.Data;
using System.Data.Common;

namespace Mailbot.Data
{
	/// <summary>
	/// Description of DataConnectorSqlServer.
	/// </summary>
	public class DataConnectorSqlServer
	{
		private Database db;
		private DbConnection connection;
		//Formato de data (NLS)
		public string formatoData {get; private set;}
		
		public DataConnectorSqlServer()
		{
			DefinirFormatoData();
		}
		
		public DataTable ExecuteDataTable(string query)
        {
			DataTable result = null;
			try
			{
				this.db = DatabaseFactory.CreateDatabase("DBU109");
				using (this.connection = db.CreateConnection()) 
				{				
		        	using (DbCommand cmd = connection.CreateCommand())
		        	{
		        		cmd.CommandTimeout = 60;
		        		cmd.CommandText = query;
		        		
		        		using (DataSet ds = db.ExecuteDataSet(cmd))
		            	{
		        			result = ds.Tables.Count > 0 ? ds.Tables[0] : new DataTable();		        			
		        			this.connection.Close();
		        			return result;
		        		}
		       		}	
				}
			}
			catch(Exception e)
			{				
				Log.WriteLog("Erro na ExecuteDataTable. " + Environment.NewLine +
				             "Query: "+ query + Environment.NewLine + 
				             "Erro:" + e.Message);
				
				if (!DataConnectorErrorHandler.CheckConnectionState())
				{
					Log.WriteLog("Não foi possível reestabelecer a conexão com SQL Server. Encerrando Mailbot...");
					SharedData.Quit();
					return new DataTable();
				}
				return ExecuteDataTable(query);				
			}
			
        }
		
		//Recupera formato de data adotado no sql server
        private void DefinirFormatoData()
        {
            const string sqlCommand = "select	s.date_format from sys.dm_exec_sessions s where s.session_id = @@SPID";
            
            DataTable result = ExecuteDataTable(sqlCommand);

            if (result.Rows.Count > 0)
            {
            	formatoData = result.Rows[0][0].ToString();
            }
            else
            {
            	//Arbitra um valor default para formato de data (ymd)
            	formatoData = "ymd";
            }
        }
		
	}
}
