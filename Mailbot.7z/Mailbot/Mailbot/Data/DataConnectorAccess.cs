﻿using System;
using System.Data;
using System.Data.OleDb;

namespace Mailbot.Data
{
	public enum DBConnectionString {Mobios = 0, Mailbot = 1};
	
	public class DataConnectorAccess
	{
		private string DATABASE_NAME;
		private string MOBIOS_CONNECTION_STRING = System.Configuration.ConfigurationManager.AppSettings["MOBIOS_CONNECTION_STRING"];
        private string MAILBOT_CONNECTION_STRING = System.Configuration.ConfigurationManager.AppSettings["MAILBOT_CONNECTION_STRING"];               
        private readonly string _connectionString = "";
		
		public DataConnectorAccess() {}
		
		public DataConnectorAccess(DBConnectionString db)
		{
			_connectionString = (db == DBConnectionString.Mobios) ?
			                    MOBIOS_CONNECTION_STRING : MAILBOT_CONNECTION_STRING;			
			DATABASE_NAME = (db == DBConnectionString.Mobios)? "Mobios" : "Mailbot";
		}
		
		public DataTable ExecuteDataTable(string query)
        {
            DataTable table = new DataTable();
            using (OleDbConnection conn = ReturnOpenConnection())
            {
                if (conn.State == ConnectionState.Open)
                {
                    int i = 0;
                    while (i < 10)
                    {
                        try
                        {
                            OleDbCommand cmd = new OleDbCommand(query, conn);
                            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
                            da.Fill(table);
                            i = 10;
                        }
                        catch (Exception e)
                        {
                        	Log.WriteLog("Erro ao executar query: " + e.Message + "Tentativa: " + i);
                            Time.pausaMilisegundos(800);
                            i = i + 1;
                            if (i == 10)
                            {
                            	Log.WriteLog("[ERRO] Nro Tentativas excedeu o limite. Quit Mailbot");
                            	SharedData.Quit();
                            }
                        }
                    }
                }
                conn.Close();
            }
            return table;
		}
		
		public OleDbConnection ReturnOpenConnection()
        {
            int i = 0;

            OleDbConnection conn = new OleDbConnection();
            
            while (i < 5)
            {                          
                try
                {
                    bool connect = false;
                    try
                    {
                    	conn = new OleDbConnection(_connectionString);
                    	conn.Open();	                    	                       
                        i = 5; //Faz sair do while!
                    }
                    catch (Exception ex)
                    {                    	
                    	Log.WriteLog("Erro ao conectar a base de " + DATABASE_NAME + ": " + ex.StackTrace);
                    	connect = true;						
                    }
                    finally
                    {
                        if (connect)
                        {
                        	Log.WriteLog("Iteração de Conexão: " + i);
                    		conn = new OleDbConnection(_connectionString);
                    		conn.Open();
                            i = 5;
                        }
                    }
                }
                catch (Exception exp)
                {
                	Log.WriteLog("Iteração de Conexão: " + i + " Erro de Acesso ao BD." +
                	                  " \n Erro:" + exp.Message);
                }
                i = i + 1;
            }
            return conn;
        }
	}
}
