﻿/*
 * Created by SharpDevelop.
 * User: hannahm
 * Date: 10/11/2017
 * Time: 14:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using ItauBE.Core.Data;
using System.Data.Common;

namespace Mailbot.Data
{
	/// <summary>
	/// Description of DataConnectorErrorHandler.
	/// </summary>
	public static class DataConnectorErrorHandler
	{
		private static Database db;
		private static DbConnection connection;
		
		public static bool CheckConnectionState()
		{
			Log.WriteLog("Iniciando tratamento de recuperação da conexão com SQL Server");
			int tentativa = 0;
			DataTable result = null;
			while (tentativa < 200)
			{
				try
				{
					db = DatabaseFactory.CreateDatabase("DBU109");
					using (connection = db.CreateConnection()) 
					{				
		        		using (DbCommand cmd = connection.CreateCommand())
		        		{
		        			cmd.CommandTimeout = 120;
		        			cmd.CommandText = "Select * from tb_0200_Parametros";
		        		
		        			using (DataSet ds = db.ExecuteDataSet(cmd))
		            		{
		        				result = ds.Tables.Count > 0 ? ds.Tables[0] : new DataTable();		        				
		        				connection.Close();			        				
		        			}
		        		}			
					}
					if ((result != null) && (result.Rows.Count > 0))
					{
						tentativa = 200;
					}
						
				}
				catch
				{
					Log.WriteLog("Tentativa: " + tentativa);
					tentativa++;
					//Não deixar centenas de conexoes abertas				
					if( connection != null &&
						connection.State == ConnectionState.Connecting ||
						connection.State == ConnectionState.Open)
					{
						connection.Close();
					}
					//Pausa para aguardar servidor retornar						
					Time.pausaMilisegundos(5000);
				}
			}
			
			if(result == null)
			{
				Log.WriteLog("Não foi possivel estabelecer conexão com SQL Server");
				return false;							
			}
			else
			{
				Log.WriteLog("Conexão recuperada com sucesso");
				return true;							
			}						
		}		
	}
}
				
