﻿using System;
using System.Collections.Generic;
using System.Data;
using Mailbot.Data.Entity;
using Mailbot.Formater;

namespace Mailbot.Data
{
	/// <summary>
	/// Classe que faz acesso a base de dados do MailBot
	/// </summary>
	public class MailbotDataAccess
	{
		private readonly DataConnectorAccess dataConnector;
		
		public MailbotDataAccess() 
		{
			dataConnector = new DataConnectorAccess(DBConnectionString.Mailbot);
		}
		
		public DataTable GetIgnoreSubjects()
		{
			string sqlCommand = string.Format("SELECT Ignore_Content, Pasta_Destino FROM tb_0002_Ignore_Subject");
			
			return dataConnector.ExecuteDataTable(sqlCommand);		
			
		}
		
		public List<SubjectCelula> GetSubjectCelulas()
		{
			string sqlCommand = string.Format("SELECT ID_Subject_Redirect, Subject_Content, " +
			                                  "ID_Celula, ID_Segmento, ID_Objeto, ID_Etapa " +
			                                  "FROM tb_0001_Subject_Celula");
			
			var result = dataConnector.ExecuteDataTable(sqlCommand);
			
			List<SubjectCelula> subjectCelulaList = new List<SubjectCelula>();
			
			foreach (DataRow row in result.Rows) 
			{
				subjectCelulaList.Add(new SubjectCelula(row));
			}
			
			return subjectCelulaList;
		}

        public bool IsDomainBlackListed(string email, ref string pastaDestino)
        {
        	string domain = Utils.GetDomain(email);
            string sqlCommand = string.Format("SELECT Dominio, Pasta_Destino FROM tb_0003_Dominios_Bloqueados WHERE Dominio = '{0}'", domain); 
            var result = dataConnector.ExecuteDataTable(sqlCommand);
            if(result.Rows.Count > 0)
            {
            	pastaDestino = result.Rows[0]["Pasta_Destino"].ToString();
            	return true;
            }
            else
            {
            	return false;
            }
        }
        
        public bool IsEmailBlackListed(string email, ref string pastaDestino)
        {
            string sqlCommand = string.Format("SELECT Dominio, Pasta_Destino FROM tb_0003_Dominios_Bloqueados WHERE Dominio = '{0}'", email); 
            var result = dataConnector.ExecuteDataTable(sqlCommand);
            if(result.Rows.Count > 0)
            {
            	pastaDestino = result.Rows[0]["Pasta_Destino"].ToString();
            	return true;
            }
            else
            {
            	return false;
            }
        }
        
        public List<string> GetMailBoxes(string RACF, string maquina)
        {
        	List<string> mailBoxList = new List<string>();
        	
        	string sqlCommand = string.Format("SELECT CaixaEntrada " +
        	                                  "FROM tb_0010_Acessos " +
        	                                  "WHERE Ativo = true AND UCase(RACF) = '" + RACF.ToUpper() + "'" +
        	                                  "and UCase(maquina) ='"+ maquina.ToUpper()+"'"
        	                                 );
        	var result = dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count > 0)
	    		foreach (DataRow row in result.Rows) 
        			mailBoxList.Add(row[0].ToString());
        	
        	return mailBoxList;
        }
        
        public List<string> GetMailBoxes(string tag)
        {
        	List<string> mailBoxList = new List<string>();
        	
        	string sqlCommand = string.Format("SELECT NomeCaixaStore " +
        	                                  "FROM tb_0004_CaixasEmail " +
        	                                  "WHERE Ativo = true AND Tag = '" + tag + "'");
        	var result = dataConnector.ExecuteDataTable(sqlCommand);
        	if (result.Rows.Count > 0)
	    		foreach (DataRow row in result.Rows) 
        			mailBoxList.Add(row[0].ToString());
        	
        	return mailBoxList;
        }
        
        public bool IsMailAllowed(string Email, string RACF)
        {
        	//Trata caracteres nao suportados no nome
        	Email = StringFormater.RemoveUnsuportedCharacters(Email);
			        	
        	bool todos = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["ALL"]);
        	string cmdSQL = string.Format("Select EmailSmtp from tb_0005_AllowedMails where EmailSmtp ='{0}'", Email);
        	if (!todos)
        	{
        		cmdSQL += string.Format(" and Tag='{0}'", RACF);       		        			
        	}     	
        	
        	DataTable dt = dataConnector.ExecuteDataTable(cmdSQL);
        	        
        	if (dt.Rows.Count > 0)
        	{
        		//Dupla verificação
        		if (dt.Rows[0]["EmailSmtp"].Equals(Email))
        		{
        			return true;
        		}
        	}
        	return false;
        }

        public void UpdateMailboxLastCheck(string mailbox, DateTime dateTime)
        {
            string query = string.Format(" UPDATE tb_0004_CaixasEmail " +
                                         " SET UltimaExecucao = '" + dateTime.ToString("dd/MM/yyyy HH:mm:ss") + "' " +
                                         " WHERE NomeCaixaStore = '" + mailbox + "'");
            var result = dataConnector.ExecuteDataTable(query);
        }
        
        public List<string> GetEsteiraFluxo(string inboxEmail, string senderEmail, string assunto)
        {
        	
        	string sqlCommand = "SELECT ID_CaixaFluxo, NomeCaixaStore, SenderEmail, Subject, NomeEsteira, NomeFluxo " +
	                            "FROM tb_0006_CaixaFluxo " + 
	                            "LEFT JOIN tb_0004_CaixasEmail " + 
        						"ON tb_0006_CaixaFluxo.ID_Caixa = tb_0004_CaixasEmail.ID_Caixa"; 
        	
        	DataTable result = dataConnector.ExecuteDataTable(sqlCommand);
        	
        	List<string> Lstring = new List<string>();
        	
        	foreach(DataRow row in result.Rows){
        		string T_inboxEmail = row["NomeCaixaStore"].ToString();
        		string T_senderEmail = row["SenderEmail"].ToString();
        		string T_assunto = row["Subject"].ToString();
        		string T_NomeEsteira = row["NomeEsteira"].ToString();
        		string T_NomeFluxo = row["NomeFluxo"].ToString();
        		string T_ID_Caixa = row["ID_CaixaFluxo"].ToString();
        		
        		if ((inboxEmail.ToTrimUpper() == T_inboxEmail.ToTrimUpper()   || T_inboxEmail == "") 	&&
        			(senderEmail.ToTrimUpper() == T_senderEmail.ToTrimUpper() || T_senderEmail == "")	&&
        			(assunto.ToTrimUpper().Contains(T_assunto.ToTrimUpper()) 		  || T_assunto == "") 		&&
        			(T_NomeEsteira != ""))
        		{
        			Lstring.Add(T_ID_Caixa);
        			Lstring.Add(T_NomeEsteira);
            		Lstring.Add(T_NomeFluxo);
            		break;
        		}
        	}
        	
        	return Lstring;
        }
        
        public DataTable GetCamposValor(int idCaixaFluxo){
        	string sqlCommand = string.Format("SELECT ID_Campo, NomeCampo, ValorCampo " +
	                            			  "FROM tb_0007_CamposValor " + 
	                            			  "WHERE ID_CaixaFluxo = {0}", idCaixaFluxo);
        	
        	DataTable result = dataConnector.ExecuteDataTable(sqlCommand);
        	return result;
        }
        
        public List<string> GetEmailsParaReportarErro(){
        	
        	List<string> mailBoxList = new List<string>();
        	
        	string sqlCommand = string.Format("SELECT NomeCaixaStore " +
        	                                  "FROM tb_0004_CaixasEmail " +
        	                                  "WHERE Ativo = true AND EmailErros = true");
        	var result = dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count > 0)
	    		foreach (DataRow row in result.Rows) 
        			mailBoxList.Add(row[0].ToString());
        	
        	return mailBoxList;
        	
        }
                        
        public bool CheckAcessos(string usuario, string maquina)
        {
        	string sqlCommand = "";
        	DataTable result = null;
        	try
        	{
        		sqlCommand = string.Format("SELECT RACF, Maquina " +
        	                                  "FROM tb_0010_Acessos " +
        	                               "where UCase(RACF)='{0}' and " +
        	                                     "UCase(Maquina) = '{1}' and Ativo = true"
        	                                  ,usuario.ToUpper()
        	                                  ,maquina.ToUpper());
	        	result = dataConnector.ExecuteDataTable(sqlCommand);
        	}
        	catch(Exception e)
        	{
        		Log.GravaLog("Erro ao recuperar acesso. Erro:"+ e.Message +".StackTrace: "+ e.StackTrace);
        		if (result == null) result = new DataTable();
        	}
        	
        	if (result.Rows.Count >= 1)
        	{
        		return true;
        	}
        	return false;
        		        		
        }
        
        public void AtualizaUltimaExecucao (string usuario, string maquina, string caixaEntrada)
        {
        	string sqlCommand = "";        	        	
        	try
        	{
        		sqlCommand = string.Format("Update tb_0010_Acessos set UltimaExecucao=#{0}# "+
        		                           "where UCase(RACF) = '{1}' and " +
										   "UCase(Maquina) = '{2}' and UCase(CaixaEntrada) ='{3}'"
        	                                  ,DateTime.Now
        	                                  ,usuario.ToUpper()
        	                                  ,maquina.ToUpper()
        	                                  ,caixaEntrada.ToUpper());
	        	dataConnector.ExecuteDataTable(sqlCommand);
        	}
        	catch(Exception e)
        	{
        		Log.GravaLog("Erro ao atualizar data do último acesso. Erro:"+ e.Message +".StackTrace: "+ e.StackTrace);        		        		
        	}        	
        }
        
        public string VerificaVersaoExchangeServer(string usuario, string maquina, string caixaEntrada)
        {
        	string sqlCommand = "";
        	DataTable result = null;
        	sqlCommand = string.Format("SELECT ExchangeVersion " +
    	                                  "FROM tb_0010_Acessos " +
    	                               "where UCase(RACF)='{0}' and " +
    	                                     "UCase(Maquina) = '{1}' and UCase(CaixaEntrada) = '{2}'"
    	                                  ,usuario.ToUpper()
    	                                  ,maquina.ToUpper()
    	                                  ,caixaEntrada.ToUpper());
        	result = dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count >=1)
        	{
        		return result.Rows[0]["ExchangeVersion"].ToString();
        	}
        	return "";        	
        }
        
        public string GetTipoGarantia(string nomePastaEntrada)
        {
        	string sqlCommand = string.Format("SELECT TipoGarantia " +
        	                                  "FROM tb_0008_DeParaTipoGarantia " +
        	                                  "WHERE FolderName = '{0}'", nomePastaEntrada);
        	
        	var result = dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count > 0)
        		return result.Rows[0][0].ToString();
        	
        	return "";
        }
        
        public DataTable GetParametros()
        {
            string sql = "SELECT * FROM tb_0009_Parametros";
			return dataConnector.ExecuteDataTable(sql);
        }
	}
}
