﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Mailbot.Data.Entity;
using Mobios.Utils;
using Mailbot.Formater;

namespace Mailbot.Data
{
	/// <summary>
	/// Description of MobiosDataSqlServer.
	/// </summary>
	public class MobiosDataSqlServer : IMobiosDataAdapter
	{
		private readonly DataConnectorSqlServer _dataConnector;
		
		public MobiosDataSqlServer()
		{
			_dataConnector = new DataConnectorSqlServer();
		}
								
		public int RegistrarServico(Servico novoServico)
        {
			string formatoData = _dataConnector.formatoData;
			string dataCriacao = (string)DateParser.Parse(formatoData,novoServico.DataCriacao.ToString(),true);
			string dataRecebimento=(string)DateParser.Parse(formatoData,novoServico.DataRecebimento.ToString(),true);
						
            string sqlCommand = string.Format("INSERT INTO tb_0125_Servico (ID_Objeto, DataCriacao, Usuario, " +
                                              "ID_SEGMENTO, Prioridade, EmailCliente, DataRecebimento, CaixaEntrada) " +
                                              "VALUES ({0}, '{1}', '{2}', {3}, {4}, '{5}','{6}','{7}')", 
                                              novoServico.ID_Objeto,
                                              dataCriacao,
                                              novoServico.Usuario, novoServico.ID_Segmento, 
                                              TratamentoBoolean.TransformarBoolean(novoServico.Prioridade),
                                              novoServico.EmailCliente,
                                              dataRecebimento,
                                              novoServico.CaixaEntrada
                                              );
			
			//Teste de data
			try
			{
				Log.GravaLog(String.Format("Original - DataCriacao: {0} DataRecebimento: {1}", novoServico.DataCriacao.ToString(), novoServico.DataRecebimento.ToString()));
				Log.GravaLog(String.Format("SQLServer - DataCriacao:{0} DataRecebimento: {1}", dataCriacao,dataRecebimento));
			}
			catch(Exception){}
							
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            int servicoId = 0;
            servicoId = BuscarIDServico(novoServico.CaixaEntrada, novoServico.DataRecebimento);
            
            return servicoId;
        }
		
		public  int BuscarIDServico(string CaixaEntrada, DateTime dataRecebimento)
        {
			string formato = _dataConnector.formatoData;
			string sqlCommand = string.Format("SELECT MAX(ID_Servico) FROM tb_0125_Servico WHERE CaixaEntrada = '{0}' AND DataRecebimento = '{1}'",CaixaEntrada, (string) DateParser.Parse(formato,dataRecebimento.ToString(), true));
            int maiorId;

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            if (result.Rows.Count > 0)
            	maiorId = Convert.ToInt32(result.Rows[0][0]);
            else
            	maiorId = 0;

            return maiorId;
        }
		
		public  void RegistrarFluxoServico(FluxoServico novoFluxoServico)
		{
			string formato = _dataConnector.formatoData;
			string sqlCommand = String.Format("INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, " +
			                                  " DataAlteracaoStatus, DataCriacao, DataAlteracao, UserCriacao, " +
			                                  " UserAlteracao, ID_Responsavel, ID_Celula)" +
                                              " VALUES ({0}, {1}, {2}, '{3}', '{3}', '{3}', '{4}', '{4}', {5}, {6})"
                                              , novoFluxoServico.ID_Servico 
                                              , novoFluxoServico.ID_Fluxo
                                              , novoFluxoServico.ID_Status
                                              , DateParser.Parse(formato,novoFluxoServico.DataCriacao.ToString(), true)
                                              , novoFluxoServico.UserCriacao
                                              , novoFluxoServico.ID_Responsavel
                                              , novoFluxoServico.ID_Celula);
			
			DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
		}

        public  void RegistrarDadosServico(DadosServico dadosServico)
        {

            string sqlCommandSelect = String.Format("Select ID_Servico, ID_Campo from tb_0126_DadosServico " +
                                                    "WHERE ID_Servico={0} and ID_Campo={1}"
                                                    , dadosServico.ID_Servico
                                                    , dadosServico.ID_Campo);

            DataTable dt = _dataConnector.ExecuteDataTable(sqlCommandSelect);

            string sqlCommand = "";
            string formato = _dataConnector.formatoData;

            if (dt.Rows.Count > 0)
            {
                sqlCommand = String.Format("UPDATE tb_0126_DadosServico SET [Data Atualizacao] = '{0}', ValorCampo='{1}' " +
                                                    "WHERE ID_Servico = {2} and ID_Campo = {3}"
                                                    , DateParser.Parse(formato,DateTime.Now.ToString(),true)
                                                    , StringFormater.RemoveUnsuportedCharacters(dadosServico.ValorCampo)
                                                    , dadosServico.ID_Servico
                                                    , dadosServico.ID_Campo);
            }
            else
            {
                sqlCommand = String.Format("INSERT INTO tb_0126_DadosServico (ID_Servico, Id_Campo, NomeCampo, ValorCampo, " +
                                              " [Data Criacao], [Data Atualizacao])" +
                                              " VALUES ({0}, {1}, '{2}', '{3}', '{4}', '{4}')"
                                              , dadosServico.ID_Servico
                                              , dadosServico.ID_Campo
                                              , StringFormater.RemoveUnsuportedCharacters(dadosServico.NomeCampo)
                                              , StringFormater.RemoveUnsuportedCharacters(dadosServico.ValorCampo)
                                              , DateParser.Parse(formato,dadosServico.DataCriacao.ToString(),true)
                                             );
                                              

            }

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

        }

        public  void RegistrarDadosFollowUp(DadosFollowUp dadosFollowUp)
        {
        	string formato = _dataConnector.formatoData;
            string sqlCommand = String.Format("INSERT INTO tb_0114_FollowUpEmail (ID_Servico, ID_FollowUpServico, ID_Email," +
                                                " Assunto, Body, ReceivedTime)" +
                                              " VALUES ({0}, {1}, '{2}', '{3}', '{4}','{5}')"
                                              , dadosFollowUp.ID_Servico
                                              , dadosFollowUp.ID_FollowUpServico
                                              , dadosFollowUp.ConversationID
                                              , StringFormater.RemoveUnsuportedCharacters(dadosFollowUp.Assunto)
                                              , StringFormater.RemoveUnsuportedCharacters(dadosFollowUp.Body)
                                              , DateParser.Parse(formato,dadosFollowUp.ReceivedTime.ToString(), true));

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }

        public  bool ExisteConversationID(string CID)
        {

            string sqlCommand = string.Format("SELECT ID_Servico, MAX(ID_FollowUpServico) FROM tb_0114_FollowUpEmail WHERE ID_Email = '{0}' GROUP BY ID_Servico", CID);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            Log.WriteLog("ID_Servico: "+ result.Rows[0][0] + "   Max id follow up:"+ result.Rows[0][1] );

            return true;

        }
                     
        /*Registrar Anexos tb_0022_AnexosServicos*/
        public  void RegistrarAnexos(DadosAnexo anexo){
        	string sqlCommand = string.Format("Insert into tb_0022_AnexosServicos(ID_Servico,FileName,ID_Responsavel) "+
        	                                  "values({0},'{1}',{2})"
        	                                  ,anexo.ID_Servico
        	                                  ,StringFormater.RemoveUnsuportedCharacters(anexo.Filename)
        	                                  ,anexo.ID_Responsavel);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        }
        
        /*Verificar Anexos tb_0022_AnexosServicos*/
        public bool ExisteAnexo(DadosAnexo anexo){
        	string sqlCommand = string.Format("SELECT COUNT(*) FROM tb_0022_AnexosServicos WHERE ID_Servico = {0} AND FileName = '{1}'"
        	                                  ,anexo.ID_Servico
        	                                  ,anexo.Filename);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	if (Convert.ToInt32(result.Rows[0][0]) > 0)
        		return true;
        	return false;
        }
        
        public  int GetServicoByEmailConversationId(string conversationId)
        {
        	string sqlCommand = string.Format("SELECT ID_Servico " +
			                                  "FROM tb_0025_ServicoEmail " +
        			                                  "WHERE ID_ConversaEmail = '{0}'", conversationId);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count > 0)
        		return Convert.ToInt32(result.Rows[0]["ID_Servico"]);
        	
        	return 0;
        }
        
        public  void ReabrirChamado(int servicoPaiId, int servicoFilhoId)
        {
        	string formato = _dataConnector.formatoData;
        	string dataHora = (string) DateParser.Parse(formato,DateTime.Now.ToString(),true);
        	string sqlCommand = string.Format("INSERT INTO tb_0024_ServicoReabertura (ID_ServicoPai, ID_ServicoFilho, Usuario, Data, Reclassificacao) " +
        	                                  "VALUES({0}, {1}, '{2}', '{3}', {4})", servicoPaiId, servicoFilhoId, "MAILBOT", dataHora, TratamentoBoolean.GetFalse());
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	//Refletir na tabela Servico para atualizar o Pipeline
    		sqlCommand = string.Format("UPDATE tb_0125_Servico " +
    		                           "SET Reclassificado = {0}, Reaberto = {1} " +
    		                           "WHERE ID_Servico = {2}", TratamentoBoolean.GetFalse(), TratamentoBoolean.GetTrue(), servicoPaiId);
    		result = _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public  void CreateServicoConversationId(int novoServicoId, string conversationId)
        {
        	string sqlCommand = string.Format("INSERT INTO tb_0025_ServicoEmail (ID_Servico, ID_ConversaEmail) " +
        	                                  "VALUES({0}, '{1}')", novoServicoId, conversationId);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }

        public  int GetCampoIDByNome(string nome)
        {
            string sqlCmd = "Select ID_Campo from tb_0003_Campos where CampoNome = '{0}'";
            sqlCmd = String.Format(sqlCmd, nome);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCmd);

            if (result.Rows.Count > 0)
            {
                return Convert.ToInt32(result.Rows[0]["ID_Campo"]);
            }
            return -1;
        }

        public  void RegistrarFollowUpEtapaServico(FollowUp FollowUpDados)
        {
        	string formato = _dataConnector.formatoData;
        	string datahora = (string) DateParser.Parse(formato,DateTime.Now.ToString(),true);

            string sqlCommand = string.Format("INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, FollowUpEtapa, DataCriacao, DataAlteracao, Login) " +
                                              "VALUES ({0}, {1}, '{2}', '{3}', '{4}', '{5}')",
                                              FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo,
                                              StringFormater.RemoveUnsuportedCharacters(FollowUpDados.FollowUpEtapa),
                                              datahora, datahora, FollowUpDados.LOGIN);
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public int getEtapaAtual(int ID_Servico){
			
			const string sqlCommand = "select ID_Servico, ID_Etapa from " +
								"( SELECT aux.ID_Servico, aux.ID_Objeto, aux.MaxDataAlteracao as MaxDataAlteracao, MIN(eo.OrdemEtapa) AS OrdemEtapa	FROM " + 
								"(SELECT aux.ID_Servico, aux.ID_Objeto, f.ID_Fluxo, aux.MaxDataAlteracao " +
								"FROM  (( " +
								"SELECT f.ID_Servico, s.ID_Objeto, MAX(f.DataAlteracao) as MaxDataAlteracao " +
								"FROM " + 
								"(tb_0127_FluxoServico AS f INNER JOIN tb_0125_Servico AS s ON f.ID_Servico = s.ID_Servico) " + 
								"WHERE f.ID_Status <> 0  AND f.ID_Servico = {0} GROUP BY f.ID_Servico, s.ID_Objeto ) AS aux " +
								"INNER JOIN tb_0127_FluxoServico AS f ON (aux.ID_Servico = f.ID_Servico AND aux.MaxDataAlteracao = f.DataAlteracao))) AS aux " + 
								"INNER JOIN tb_0010_EtapasObjetos as eo ON aux.ID_Objeto = eo.ID_Objeto AND aux.ID_Fluxo = eo.ID_Etapa " +
								"GROUP BY aux.ID_Servico, aux.ID_Objeto, aux.MaxDataAlteracao) as t " +
								"INNER JOIN dbo.tb_0010_EtapasObjetos as eo ON eo.ID_Objeto = t.ID_Objeto AND eo.OrdemEtapa = t.OrdemEtapa";

			string sqlCommandWithParameter = String.Format(sqlCommand,ID_Servico);
			
			DataTable result = _dataConnector.ExecuteDataTable(sqlCommandWithParameter);
			
			if(result.Rows.Count > 0)					
				return Convert.ToInt32(result.Rows[0]["ID_Etapa"]);

			return 0;
		}

        public void AlterarStatusEtapa(int servicoId, int ID_Status, int ID_Etapa = -1, bool reabrir = false)
        {
        	string formato = _dataConnector.formatoData;
        	string datahora = (string) DateParser.Parse(formato,DateTime.Now.ToString(), true);        	        

            string sqlCommand = String.Format(
                "Update tb_0127_FluxoServico " +
                "set ID_Status = {0}, " +
                "DataAlteracaoStatus='{1}', " +
                "DataAlteracao='{1}', " +
                "UserAlteracao='{2}' " +
                "where ID_Servico = {3} and ID_Fluxo={4}"
                , ID_Status
                , datahora
                , System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"]
                , servicoId
                , ID_Etapa);

            _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public bool HasStatus(int idServico, int idEtapa, int idStatus)
        {
        	string sqlCommand = String.Format("SELECT COUNT(*) " + 
											  "FROM tb_0119_StatusEtapas " + 
											  "INNER JOIN tb_0125_Servico ON tb_0119_StatusEtapas.ID_Objeto = tb_0125_Servico.ID_Objeto " + 
											  "WHERE (((tb_0125_Servico.ID_Servico)={0}) " + 
											  "AND ((tb_0119_StatusEtapas.ID_Etapa)={1}) " + 
											  "AND ((tb_0119_StatusEtapas.ID_Status)={2}))", 
											  idServico, idEtapa, idStatus);

        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	if(result != null)
        	{
        		if(Convert.ToInt32(result.Rows[0][0]) > 0)
	        		return true;
        	}
        	return false;
        }
        
        public int GetServicoTo(int servicoId)
       	{
            string sqlCommand = "SELECT ID_Servico_To " +
            					"FROM tb_0130_ServicoFromTo " +
            					"WHERE ID_Servico_From = " + servicoId;
            
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
            
            if (result != null && result.Rows.Count > 0)
            	return Convert.ToInt32(result.Rows[0][0]);
            
            return 0;
        }

        public  bool VerificaObjetoFluxoAreas(int servicoID)
        {
        	
        	//DEPRECATED:
            //string sqlCommand = String.Format("select FluxoAreas from tb_0001_Objetos where ID_Objeto = (Select ID_Objeto from tb_0125_Servico where ID_Servico ={0})", servicoID);
            string sqlCommand = String.Format("select bool1 as FluxoAreas from tracking.Entity1 where Int1 = (Select ID_Objeto from tb_0125_Servico where ID_Servico = {0}) and Str1='tb_0001_Objetos' and Str2='FluxoAreas'", servicoID);
            DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
            
            if(dt.Rows.Count > 0)
            	return Convert.ToBoolean(dt.Rows[0]["FluxoAreas"]);
            return false;
        }

		//Recupera DataTable com os valores de IDs e nomes
        public DataTable BuscarConstantes()
        {
        	string sqlCommand="Select ID_SEGMENTO as ID, COD_SEGMENTO as Nome, 'Segmento' as src from tb_0110_Segmento UNION ALL " +
        					  "Select ID_Etapa as ID, NomeEtapa as Nome, 'Etapas' as src from tb_0008_Etapas UNION ALL " +
        					  "Select ID_Status as ID, TipoStatus as Nome, 'Status' as src from tb_0111_Status UNION ALL " +
        					  "Select ID_Celula as ID, NomeCelulaResumido as Nome, 'Celula' as src from tb_0113_Celula UNION ALL " +
        					  "Select ID_Objeto as ID, NomeObjeto as Nome, 'Objeto' as src from tb_0001_Objetos UNION ALL " +
        					  "Select ID_Campo as ID, CampoNome as Nome, 'Campos' as src from tb_0003_Campos";
        	
			return _dataConnector.ExecuteDataTable(sqlCommand);        
		}
        
        public bool ValidaFluxoAreas(int IdServico)
        {
        	string sqlCommand = string.Format("select * from tb_0127_FluxoServico where ID_Servico = {0} and ID_Fluxo = {1} and ConcluidoFluxo=0", IdServico,SharedData.ID_ETAPA_AGUARDAR_RESPOSTA);
        	try
        	{
        		DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        		if (result.Rows.Count > 0)
        		{
        			return true;
        		}                		
        		return false;
        		
        	}
        	catch(Exception e)
        	{
        		Log.GravaLog("Erro ao validar Fluxo das Areas.Erro:"+ e.Message);
        	}
        	return false;
        }
        
        public void RegistrarFluxosServico (int servicoId, int idObjeto, string SistemaLog = "")
        {
        	string formato = _dataConnector.formatoData;
        	List<EtapasObjeto> etapasObjetoList = new List<EtapasObjeto>();
			
            etapasObjetoList = BuscarEtapasObjeto(idObjeto);
            if (etapasObjetoList.Count > 0)
            {
                StringBuilder sb_LogServico = new StringBuilder();
	            string datahora = (string) DateParser.Parse(formato,DateTime.Now.ToString(), true);
	            string sqlCommandInsert = "INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, DataAlteracaoStatus, DataCriacao, DataAlteracao, Id_Responsavel, UserCriacao, UserAlteracao, Id_Celula) SELECT * FROM (";
	
	            int auxInsert = 0;
	            foreach (EtapasObjeto etp in etapasObjetoList)
	            {
	                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", etp.ID_Servico, etp.ID_Etapa, 0, etp.ID_Status.ToString(), SistemaLog, datahora, "Insert"));
	                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", etp.ID_Servico, etp.ID_Etapa, 0, etp.IdResponsavel.ToString(), SistemaLog, datahora, "Insert"));
	               
	                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_Servico, {1} As ID_Fluxo, " +
	                	                                 "{2} As ID_Status, '{3}' As DataAlteracaoStatus, '{3}' As DataCriacao, " +
	                	                                 "'{3}' As DataAlteracao ,{4} as Id_Responsavel, '{5}' As UserCriacao, " +
	                	                                 "'{5}' As UserAlteracao, {6} As Id_Celula " +
	                	                                 "FROM tb_0080_AuxInsertDadosServico UNION ", 
	                	                                 servicoId, etp.ID_Etapa, etp.StatusInicial, 
	                	                                 datahora, etp.IdResponsavel, Environment.UserName.ToUpper(),											 
	                	                                 etp.Id_Celula_Responsavel);
	                auxInsert = auxInsert + 1;
	            }
	
	            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
	            sqlCommandInsert = sqlCommandInsert + ")";
	
	            if (auxInsert > 0)
	            {
	                string msgLog = "Criando Fluxos: " + sqlCommandInsert;
	                Log.GravaLog(msgLog);
	                DataTable multirowinsert = _dataConnector.ExecuteDataTable(sqlCommandInsert);
	            }
	            if (sb_LogServico.ToString() != "")
	                Log.GravaLog(sb_LogServico.ToString());
            }
        }
        
        List<EtapasObjeto> BuscarEtapasObjeto(int objetoId)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ObjetosEtapas " +
			                                  "WHERE ID_Objeto = {0}", objetoId);

            List<EtapasObjeto> list = new List<EtapasObjeto>();
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            foreach (DataRow row in result.Rows)
                list.Add(new EtapasObjeto(row));

            return list;
        }
        
        public void ReabrirServico(int servicoId)
        {
        	string dataHora = DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");
        	string sqlCommand = String.Format(
                "Update tb_0125_Servico " +
                "set Concluido = 0, " +
                "DataConclusao = NULL, " +
                //P/ PROPRIAS E TERCEIROS a tabela servico tem a coluna DataReabertura
                (SharedData.IsAtendimento ? "" :
                 string.Format("DataReabertura = '{0}', ", dataHora)) +
                "UsuarioConclusao = NULL, " +
                "Cancelado = 0, " +
                "DataCancelamento = NULL, " +
                "UsuarioCancelamento = NULL " +
                "where ID_Servico = {0}"
                , servicoId);

        	_dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public void RegistrarDadosStatusEtapa(int servicoId, int ID_Status, int ID_Etapa)
        {
        	string formato = _dataConnector.formatoData;
        	string sqlCommand = String.Format(
                "INSERT INTO tb_0132_DadosStatusEtapas (ID_Servico, ID_Etapa, ID_Status, DataAlteracao, Responsavel) " +
                "VALUES ({0}, {1}, {2}, '{3}', '{4}')"
                , servicoId
                , ID_Etapa
                , ID_Status
                , (string) DateParser.Parse(formato,DateTime.Now.ToString(), true)
                , System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"]);

            _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public bool IsConcluido(int servicoId)
        {
        	string sqlCommand="SELECT Concluido FROM tb_0125_Servico WHERE ID_Servico = " + servicoId;
        	DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
    		if(dt.Rows.Count > 0)
            	return Convert.ToBoolean(dt.Rows[0]["Concluido"]);
			return false;
        }
        
        public bool IsServicoPortalTEF(int servicoId)
        {
        	string sqlCommand = string.Format("SELECT ID_Servico " +
        	                                  "FROM tb_0125_Servico " +
        	                                  "WHERE ID_Servico = {0} AND CaixaEntrada = '{1}'", servicoId, 
        	                                  "ibba-linhadireta-portaltef@itaubba.com");
        	DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	return (dt.Rows.Count > 0);
        }
        
        public int GetObjetoIdByName(string nomeObjeto)
		{
			string sqlCommand = string.Format("SELECT ID_Objeto FROM tb_0001_Objetos " +
			                                       "WHERE NomeObjeto = '{0}'", nomeObjeto);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            return Convert.ToInt32(result.Rows[0][0]);
		}
		
		public int GetSegmentoIdByName(string nomeSegmento)
		{
			string sqlCommand = string.Format("SELECT ID_SEGMENTO FROM tb_0110_Segmento " +
			                                       "WHERE COD_SEGMENTO = '{0}'", nomeSegmento);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            return Convert.ToInt32(result.Rows[0][0]);
		}
	}	
}
