﻿using System;

namespace Mailbot.Data.Entity
{
	public class DadosServico
	{
		public int ID_Servico { get; set; }
		public int ID_Campo { get; set; }
		public string NomeCampo { get; set;}
		public string ValorCampo {get; set; }
		public DateTime DataCriacao {get; set;}
		public DateTime DataAtualizacao {get; set;}
	
		public DadosServico() {}
	}
}
