﻿/* Classe para persistir dados dos anexos obtidos dos e-mails
 
 */

namespace Mailbot.Data.Entity
{
	public class DadosAnexo
	{
		public string ID_Servico { get; set; }
		public string Filename { get; set; }
		public string ID_Responsavel { get; set; }
		
		public DadosAnexo(string ID_Servico, string Filename, string ID_Responsavel){
			this.ID_Servico = ID_Servico;
			this.Filename = Filename;
			this.ID_Responsavel = ID_Responsavel;
		}
		
		
	}
}
