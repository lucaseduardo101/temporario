﻿using System;
using System.Data;

namespace Mailbot.Data.Entity
{
	/// <summary>
	/// Servico Entity
	/// </summary>
	public class Servico
	{
		public int ID_Objeto { get; set; }
        public int ID_Servico { get; set; }
        public int ID_Segmento { get; set; }
        public string Usuario { get; set; }
        public DateTime DataCriacao { get; set; }
        public DateTime DataRecebimento {get; set;}
        public bool Prioridade { get; set; }
        public string Assunto { get; set; }
        public string Body { get; set; }

        public string EmailCliente { get; set; }
        public string CaixaEntrada { get; set;} /*Armazena a caixa de entrada observada pelo robo*/
        
        public Servico() { }

        public Servico(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Servico = Convert.ToInt32(row["ID_Servico"]);
            this.ID_Segmento = Convert.ToInt32(row["ID_SEGMENTO"]);
            this.Usuario = row[3].ToString();
        }
        
        
		
	}
}
