﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mailbot.Data.Entity
{
    public class DadosFollowUp
    {
        public string ID_Servico { get; set; }

        public int ID_FollowUpServico { get; set; }

        public string ConversationID { get; set; }

        public string Body { get; set; }

        public string Assunto { get; set; }

        public DateTime ReceivedTime { get; set; }
    }
}
