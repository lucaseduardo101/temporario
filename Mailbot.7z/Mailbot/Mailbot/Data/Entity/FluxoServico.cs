﻿using System;

namespace Mailbot.Data.Entity
{
	/// <summary>
	/// FluxoServico Entity
	/// </summary>
	public class FluxoServico
	{
		public int ID_Servico { get; set; }
	    public int ID_Fluxo { get; set; }
	    public int ID_Status { get; set; }
	    public DateTime DataAlteracaoStatus { get; set; }
		public DateTime DataCriacao { get; set; }
		public string UserCriacao { get; set; }
	    public DateTime DataAlteracao { get; set; }
		public string UserAlteracao { get; set; }
		public int ID_Responsavel { get; set; } 
		public int ID_Celula { get; set; }
		
	    public FluxoServico() { }
	}
}
