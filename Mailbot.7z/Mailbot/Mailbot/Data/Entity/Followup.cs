﻿using System;

namespace Mailbot.Data.Entity
{
	public class FollowUp
	{
        public int ID_Servico { get; set; }
        public int ID_Fluxo { get; set; }        
        public string FollowUpEtapa { get; set; }
        public string LOGIN { get; set; }       
        public DateTime DataCriacao { get; set; }
        public DateTime DataAlteracao { get; set; }

        public FollowUp()
        { }
      
    }
}
    
