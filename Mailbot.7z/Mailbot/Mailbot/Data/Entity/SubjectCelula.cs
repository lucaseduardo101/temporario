﻿using System;
using System.Data;

namespace Mailbot.Data.Entity
{
	/// <summary>
	/// Description of SubjectCelula.
	/// </summary>
	public class SubjectCelula
	{
		public int ID_Subject_Redirect { get; set; }
		public string Subject_Content { get; set; }
		public int ID_Celula { get; set; }
		public int ID_Segmento { get; set; }
		public int ID_Objeto { get; set; }
		public int ID_Etapa { get; set; }
		public int ID_DemandaClassificada { get; set; }
		
		public SubjectCelula () {}
		
		public SubjectCelula (DataRow row)
		{
			this.ID_Subject_Redirect = Convert.ToInt32(row["ID_Subject_Redirect"]);
			this.Subject_Content = row["Subject_Content"].ToString();
			this.ID_Celula = Convert.ToInt32(row["ID_Celula"]);
			this.ID_Segmento = Convert.ToInt32(row["ID_Segmento"]);
			this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
			this.ID_Etapa = Convert.ToInt32(row["ID_Etapa"]);
			this.ID_DemandaClassificada = 0;
		}
	}
}
