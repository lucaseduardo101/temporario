﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Exchange.WebServices.Data;

namespace Mailbot.Data.Entity
{
    public class Email
    {
        public int ID_Email { get; set; }
        public string Sender_Email { get; set; }
        public string To_Email { get; set; }
        public string ID_Conversation { get; set; }
        public DateTime ReceivedTime { get; set; }
        public AttachmentCollection Attachments { get; set; }
        public SubjectCelula Celula_Responsavel {get; set; }
        public string CC { get; set; }
        public string Assunto { get; set; }
        public string Body { get; set; }
        public string HTMLBody { get; set; }
        public string CaixaEntrada {get; set;}
        public string TipoGarantia { get; set; }
    }
}
