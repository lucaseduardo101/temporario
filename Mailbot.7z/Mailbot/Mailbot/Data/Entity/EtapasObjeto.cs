﻿using System;
using System.Data;

namespace Mailbot.Data.Entity
{	

	 public class EtapasObjeto
    {
        public int ID_Objeto { get; set; }
        public string NomeObjeto { get; set; }
        public string DescricaoObjeto { get; set; }
        public int ID_Etapa { get; set; }
        public string NomeEtapa { get; set; }
        public string DescricaoEtapa { get; set; }
        public int OrdemEtapa { get; set; }
        public int ID_Servico { get; set; }
        public int ID_Status { get; set; }
        public int StatusInicial { get; set; }
        public bool StatusFecha { get; set; }
        public bool StatusPrimeiro { get; set; }
        public bool StatusParalisa { get; set; }
        public bool StatusCancela { get; set; }
        public bool StatusNaoInicia { get; set; }
        public int IdMesmoResponsavel { get; set; }
        public int Id_Celula_Responsavel { get; set; }
        public int Id_Area_Responsavel { get; set; }
        public int IdResponsavel { get; set; }
        public string NomeResponsavel { get; set; }
        public bool ValidaResponsavel { get; set; }

        public EtapasObjeto()
        { }

        public EtapasObjeto(DataRow row)
        {
            this.ID_Objeto = Convert.ToInt32(row["ID_Objeto"]);
            this.ID_Servico = row.Table.Columns.Contains("ID_Servico") ? (row["ID_Servico"].ToString() == "" ? 0 : Convert.ToInt32(row["ID_Servico"])) : 0;
            this.NomeObjeto = row["NomeObjeto"].ToString();
            this.DescricaoObjeto = row["DescricaoObjeto"].ToString();
            this.ID_Etapa = Convert.ToInt32(row["ID_Etapa"]);
            this.NomeEtapa = row["NomeEtapa"].ToString();
            this.DescricaoEtapa = row["DescricaoEtapa"].ToString();
            this.OrdemEtapa = Convert.ToInt32(row["OrdemEtapa"]);
            this.StatusInicial = Convert.ToInt32(row["StatusInicial"]);
            this.StatusPrimeiro = Convert.ToBoolean(row["Primeiro"]);
            this.StatusFecha = Convert.ToBoolean(row["Fecha"]);
            this.StatusParalisa = Convert.ToBoolean(row["Paralisa"]);
            this.StatusCancela = Convert.ToBoolean(row["Cancela"]);
            this.StatusNaoInicia = Convert.ToBoolean(row["NaoInicia"]);
            this.IdMesmoResponsavel = row.Table.Columns.Contains("IdMesmoResponsavel") ? (row["IdMesmoResponsavel"].ToString() == "" ? 0 : Convert.ToInt32(row["IdMesmoResponsavel"])) : 0;
            this.Id_Celula_Responsavel = Convert.ToInt32(row["CelulaResponsavel"]);
            this.Id_Area_Responsavel = Convert.ToInt32(row["AreaResponsavel"]);
        }
    }
}