﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Mailbot.Data.Entity;

namespace Mailbot.Data
{
	/// <summary>
	/// Classe que faz acesso a base de dados do Mobios
	/// </summary>
	public class MobiosDataAccess  : IMobiosDataAdapter
	{
		private readonly DataConnectorAccess _dataConnector;
		
		public MobiosDataAccess()
		{
			_dataConnector = new DataConnectorAccess(DBConnectionString.Mobios);
		}
		
		public int RegistrarServico(Servico novoServico)
        {

            string sqlCommand = string.Format("INSERT INTO tb_0125_Servico (ID_Objeto, DataCriacao, Usuario, " +
                                              "ID_SEGMENTO, Prioridade, EmailCliente, DataRecebimento, CaixaEntrada) " +
                                              "VALUES ({0}, '{1}', '{2}', {3}, {4}, '{5}','{6}','{7}')", 
                                              novoServico.ID_Objeto,
                                              novoServico.DataCriacao.ToString("yyyy/MM/dd HH:mm:ss"),
                                              novoServico.Usuario, novoServico.ID_Segmento, novoServico.Prioridade,
                                              novoServico.EmailCliente,
                                              novoServico.DataRecebimento.ToString("yyyy/MM/dd HH:mm:ss"),
                                              novoServico.CaixaEntrada
                                              );

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            int servicoId = 0;
            servicoId = BuscarIDServico(novoServico.CaixaEntrada, novoServico.DataRecebimento);
            
            return servicoId;
        }
		
		public int BuscarIDServico(string CaixaEntrada, DateTime dataRecebimento)
        {
            string sqlCommand = string.Format("SELECT MAX(ID_Servico) FROM tb_0125_Servico WHERE CaixaEntrada = '{0}' AND DataRecebimento = #{1}#", CaixaEntrada, dataRecebimento.ToString("yyyy/MM/dd HH:mm:ss"));
            int maiorId;

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            if (result.Rows.Count > 0)
            	maiorId = Convert.ToInt32(result.Rows[0][0]);
            else
            	maiorId = 0;

            return maiorId;
        }
		
		public  void RegistrarFluxoServico(FluxoServico novoFluxoServico)
		{
			string sqlCommand = String.Format("INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, " +
			                                  " DataAlteracaoStatus, DataCriacao, DataAlteracao, UserCriacao, " +
			                                  " UserAlteracao, ID_Responsavel, ID_Celula)" +
                                              " VALUES ({0}, {1}, {2}, #{3}#, #{3}#, #{3}#, '{4}', '{4}', {5}, {6})"
                                              , novoFluxoServico.ID_Servico 
                                              , novoFluxoServico.ID_Fluxo
                                              , novoFluxoServico.ID_Status
                                              , novoFluxoServico.DataCriacao.ToString("yyyy/MM/dd HH:mm:ss")
                                              , novoFluxoServico.UserCriacao
                                              , novoFluxoServico.ID_Responsavel
                                              , novoFluxoServico.ID_Celula);
			
			DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
		}

        public  void RegistrarDadosServico(DadosServico dadosServico)
        {

            string sqlCommandSelect = String.Format("Select ID_Servico, ID_Campo from tb_0126_DadosServico " +
                                                    "WHERE ID_Servico={0} and ID_Campo={1}"
                                                    , dadosServico.ID_Servico
                                                    , dadosServico.ID_Campo);

            DataTable dt = _dataConnector.ExecuteDataTable(sqlCommandSelect);

            string sqlCommand = "";

            if (dt.Rows.Count > 0)
            {
                sqlCommand = String.Format("UPDATE tb_0126_DadosServico SET [Data Atualizacao] = #{0}#, ValorCampo='{1}' " +
                                                    "WHERE ID_Servico = {2} and ID_Campo = {3}"
                                                    , DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                                                    , dadosServico.ValorCampo
                                                    , dadosServico.ID_Servico
                                                    , dadosServico.ID_Campo);
            }
            else
            {
                sqlCommand = String.Format("INSERT INTO tb_0126_DadosServico (ID_Servico, Id_Campo, NomeCampo, ValorCampo, " +
                                              " [Data Criacao], [Data Atualizacao])" +
                                              " VALUES ({0}, {1}, '{2}', '{3}', #{4}#, #{4}#)"
                                              , dadosServico.ID_Servico
                                              , dadosServico.ID_Campo
                                              , dadosServico.NomeCampo
                                              , dadosServico.ValorCampo
                                              , dadosServico.DataCriacao.ToString("yyyy/MM/dd HH:mm:ss")
                                              , dadosServico.DataCriacao.ToString("yyyy/MM/dd HH:mm:ss"));

            }

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

        }

        public  void RegistrarDadosFollowUp(DadosFollowUp dadosFollowUp)
        {
            string sqlCommand = String.Format("INSERT INTO tb_0114_FollowUpEmail (ID_Servico, ID_FollowUpServico, ID_Email," +
                                                " Assunto, Body, ReceivedTime)" +
                                              " VALUES ({0}, {1}, '{2}', '{3}', '{4}',#{5}#)"
                                              , dadosFollowUp.ID_Servico
                                              , dadosFollowUp.ID_FollowUpServico
                                              , dadosFollowUp.ConversationID
                                              , dadosFollowUp.Assunto
                                              , dadosFollowUp.Body
                                              , dadosFollowUp.ReceivedTime.ToString("yyyy/MM/dd HH:mm:ss"));

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }

        public  bool ExisteConversationID(string CID)
        {

            string sqlCommand = string.Format("SELECT ID_Servico, MAX(ID_FollowUpServico) FROM tb_0114_FollowUpEmail WHERE ID_Email = '{0}' GROUP BY ID_Servico", CID);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            Log.WriteLog("ID_Servico: "+ result.Rows[0][0] + "   Max id follow up:"+ result.Rows[0][1] );

            return true;

        }
       
        public static implicit operator MobiosDataAccess(MailbotDataAccess v)
        {
            throw new NotImplementedException();
        }
        
        /*Registrar Anexos tb_0022_AnexosServicos*/
        public  void RegistrarAnexos(DadosAnexo anexo){
        	string sqlCommand = string.Format("Insert into tb_0022_AnexosServicos(ID_Servico,FileName,ID_Responsavel) "+
        	                                  "values({0},'{1}',{2})"
        	                                  ,anexo.ID_Servico
        	                                  ,anexo.Filename
        	                                  ,anexo.ID_Responsavel);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        }
        
        /*Verificar Anexos tb_0022_AnexosServicos*/
        public bool ExisteAnexo(DadosAnexo anexo){
        	string sqlCommand = string.Format("SELECT COUNT(*) FROM tb_0022_AnexosServicos WHERE ID_Servico = {0} AND FileName = '{1}'"
        	                                  ,anexo.ID_Servico
        	                                  ,anexo.Filename);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	if (Convert.ToInt32(result.Rows[0][0]) > 0)
        		return true;
        	return false;
        }
        
        public  int GetServicoByEmailConversationId(string conversationId)
        {
        	string sqlCommand = string.Format("SELECT ID_Servico " +
			                                  "FROM tb_0025_ServicoEmail " +
        			                                  "WHERE ID_ConversaEmail = '{0}'", conversationId);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	if (result.Rows.Count > 0)
        		return Convert.ToInt32(result.Rows[0]["ID_Servico"]);
        	
        	return 0;
        }
        
        public int getEtapaAtual(int ID_Servico){
        	
        	const string sqlCommand = "SELECT  ID_Servico,   ID_Etapa  " +
								"FROM (SELECT t3.ID_Servico, t3.ID_Objeto, t3.MaxDataAlteracao as MaxDataAlteracao,   MIN(eo.OrdemEtapa) AS OrdemEtapa   " +
								"FROM   (SELECT   t2.ID_Servico,   t2.ID_Objeto,   f.ID_Fluxo,   t2.MaxDataAlteracao  " +
								"FROM   (SELECT   f.ID_Servico,   s.ID_Objeto,   MAX(f.DataAlteracao) as MaxDataAlteracao   " +
								"FROM  tb_0127_FluxoServico AS f   " +
								"INNER JOIN tb_0125_Servico AS s   ON f.ID_Servico = s.ID_Servico WHERE   (f.ID_Status <> 0 AND f.ID_Servico = {0})   GROUP BY   f.ID_Servico,   s.ID_Objeto  ) AS t2   " +
								"INNER JOIN tb_0127_FluxoServico AS f   ON (t2.ID_Servico = f.ID_Servico AND t2.MaxDataAlteracao = f.DataAlteracao)  ) AS t3   " +
								"INNER JOIN tb_0010_EtapasObjetos as eo   ON (t3.ID_Objeto = eo.ID_Objeto AND t3.ID_Fluxo = eo.ID_Etapa)   GROUP BY   t3.ID_Servico,   t3.ID_Objeto,   t3.MaxDataAlteracao  ) as t4   " +
								"INNER JOIN tb_0010_EtapasObjetos as eo   ON (eo.ID_Objeto = t4.ID_Objeto AND eo.OrdemEtapa = t4.OrdemEtapa)  ";

			string sqlCommandWithParameter = String.Format(sqlCommand,ID_Servico);
			
			DataTable result = _dataConnector.ExecuteDataTable(sqlCommandWithParameter);
			
			if(result.Rows.Count > 0)					
				return Convert.ToInt32(result.Rows[0]["ID_Etapa"]);

			return 0;
		}
        
        public int GetObjetoIdByName(string nomeObjeto)
		{
			string sqlCommand = string.Format("SELECT ID_Objeto FROM tb_0001_Objetos " +
			                                       "WHERE NomeObjeto = '{0}'", nomeObjeto);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            return Convert.ToInt32(result.Rows[0][0]);
		}
		
		public int GetSegmentoIdByName(string nomeSegmento)
		{
			string sqlCommand = string.Format("SELECT ID_SEGMENTO FROM tb_0110_Segmento " +
			                                       "WHERE COD_SEGMENTO = '{0}'", nomeSegmento);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            return Convert.ToInt32(result.Rows[0][0]);
		}
        
        public  void ReabrirChamado(int servicoPaiId, int servicoFilhoId)
        {
        	string dataHora = DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");
        	string sqlCommand = string.Format("INSERT INTO tb_0024_ServicoReabertura (ID_ServicoPai, ID_ServicoFilho, Usuario, Data, Reclassificacao) " +
        	                                  "VALUES({0}, {1}, '{2}', #{3}#, {4})", servicoPaiId, servicoFilhoId, "MAILBOT", dataHora, false);

        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	//Refletir na tabela Servico para atualizar o Pipeline
    		sqlCommand = string.Format("UPDATE tb_0125_Servico " +
    		                           "SET Reclassificado = {0}, Reaberto = {1} " +
    		                           "WHERE ID_Servico = {2}", false, true, servicoPaiId);
    		result = _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public  void CreateServicoConversationId(int novoServicoId, string conversationId)
        {
        	string sqlCommand = string.Format("INSERT INTO tb_0025_ServicoEmail (ID_Servico, ID_ConversaEmail) " +
        	                                  "VALUES({0}, '{1}')", novoServicoId, conversationId);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }

        public  int GetCampoIDByNome(string nome)
        {
            string sqlCmd = "Select ID_Campo from tb_0003_Campos where CampoNome = '{0}'";
            sqlCmd = String.Format(sqlCmd, nome);

            DataTable result = _dataConnector.ExecuteDataTable(sqlCmd);

            if (result.Rows.Count > 0)
            {
                return Convert.ToInt32(result.Rows[0]["ID_Campo"]);
            }
            return -1;
        }

        public  void RegistrarFollowUpEtapaServico(FollowUp FollowUpDados)
        {
            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");

            string sqlCommand = string.Format("INSERT INTO tb_0128_FollowUpEtapaServico (ID_Servico, ID_Fluxo, FollowUpEtapa, DataCriacao, DataAlteracao, Login) " +
                                              "VALUES ({0}, {1}, '{2}', #{3}#, #{4}#, '{5}')",
                                              FollowUpDados.ID_Servico, FollowUpDados.ID_Fluxo,
                                              FollowUpDados.FollowUpEtapa,
                                              datahora, datahora, FollowUpDados.LOGIN);
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        }

        public void AlterarStatusEtapa(int servicoId, int ID_Status, int ID_Etapa = -1, bool reabrir = false)
        {
        	string sqlCommand = String.Format(
                "Update tb_0127_FluxoServico " +
                "set ID_Status = {0}, " +
                "DataAlteracaoStatus=#{1}#, " +
                "DataAlteracao=#{1}#, " +
                "UserAlteracao='{2}' {3}" +
                "where ID_Servico = {4} {5}"
                , ID_Status
                , DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                , System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"]
                , (reabrir)? ", ConcluidoFluxo = False, DataConclusao = NULL " : ""
                , servicoId
                , (ID_Etapa != -1)? String.Format("and ID_Fluxo={0}", ID_Etapa) : "");

            _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public void ReabrirServico(int servicoId)
        {
        	string dataHora = DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss");
        	string sqlCommand = String.Format(
                "Update tb_0125_Servico " +
                "set Concluido = False, " +
                "DataConclusao = NULL, " +
                //P/ PROPRIAS E TERCEIROS a tabela servico tem a coluna DataReabertura
                (SharedData.IsAtendimento ? "" :
                 string.Format("DataReabertura = #{0}#, ", dataHora)) +
                "UsuarioConclusao = NULL, " +
                "Cancelado = False, " +
                "DataCancelamento = NULL, " +
                "UsuarioCancelamento = NULL " +
                "where ID_Servico = {0}"
                , servicoId);

        	_dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public void RegistrarDadosStatusEtapa(int servicoId, int ID_Status, int ID_Etapa)
        {
        	string sqlCommand = String.Format(
                "INSERT INTO tb_0132_DadosStatusEtapas (ID_Servico, ID_Etapa, ID_Status, DataAlteracao, Responsavel) " +
                "VALUES ({0}, {1}, {2}, #{3}#, '{4}')"
                , servicoId
                , ID_Etapa
                , ID_Status
                , DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")
                , System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"]);

            _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public bool HasStatus(int idServico, int idEtapa, int idStatus)
        {
        	string sqlCommand = String.Format("SELECT COUNT(*) " + 
											  "FROM tb_0119_StatusEtapas " + 
											  "INNER JOIN tb_0125_Servico ON tb_0119_StatusEtapas.ID_Objeto = tb_0125_Servico.ID_Objeto " + 
											  "WHERE (((tb_0125_Servico.ID_Servico)={0}) " + 
											  "AND ((tb_0119_StatusEtapas.ID_Etapa)={1}) " + 
											  "AND ((tb_0119_StatusEtapas.ID_Status)={2}))", 
											  idServico, idEtapa, idStatus);
        	
        	DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        	if(result != null)
        	{
        		if(Convert.ToInt32(result.Rows[0][0]) > 0)
	        		return true;
        	}
        	return false;
        }
        
        public int GetServicoTo(int servicoId)
       	{
            string sqlCommand = "SELECT ID_Servico_To " +
            					"FROM tb_0130_ServicoFromTo " +
            					"WHERE ID_Servico_From = " + servicoId;
            
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
            
            if (result != null && result.Rows.Count > 0)
            	return Convert.ToInt32(result.Rows[0][0]);
            
            return 0;
        }
        

        public  bool VerificaObjetoFluxoAreas(int servicoID)
        {
            string sqlCommand = String.Format("select FluxoAreas from tb_0001_Objetos where ID_Objeto = (Select ID_Objeto from tb_0125_Servico where ID_Servico ={0})", servicoID);

            DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
			if(dt.Rows.Count > 0)
            	return Convert.ToBoolean(dt.Rows[0]["FluxoAreas"]);
            return false;
        }
        
        //Recupera DataTable com os valores de IDs e nomes
        public DataTable BuscarConstantes()
        {
        	string sqlCommand="Select ID_SEGMENTO as ID, COD_SEGMENTO as Nome, 'Segmento' as src from tb_0110_Segmento UNION ALL " +
        					  "Select ID_Etapa as ID, NomeEtapa as Nome, 'Etapas' as src from tb_0008_Etapas UNION ALL " +
        					  "Select ID_Status as ID, TipoStatus as Nome, 'Status' as src from tb_0111_Status UNION ALL " +
        					  "Select ID_Celula as ID, NomeCelulaResumido as Nome, 'Celula' as src from tb_0113_Celula UNION ALL " +
        					  "Select ID_Objeto as ID, NomeObjeto as Nome, 'Objeto' as src from tb_0001_Objetos UNION ALL " +
        					  "Select ID_Campo as ID, CampoNome as Nome, 'Campos' as src from tb_0003_Campos";
        	
			return _dataConnector.ExecuteDataTable(sqlCommand);
        }
        
        public bool ValidaFluxoAreas(int IdServico)
        {
        	string sqlCommand = string.Format("select * from tb_0127_FluxoServico where ID_Servico = {0} and ID_Fluxo = {1} and ConcluidoFluxo=False", IdServico,SharedData.ID_ETAPA_AGUARDAR_RESPOSTA);
        	try
        	{
        		DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);
        		if (result.Rows.Count > 0)
        		{
        			return true;
        		}                		
        		return false;
        		
        	}
        	catch(Exception e)
        	{
        		Log.GravaLog("Erro ao validar Fluxo das Areas.Erro:"+ e.Message);
        	}
        	return false;
        }
        
        public bool IsConcluido(int servicoId)
        {
        	string sqlCommand="SELECT Concluido FROM tb_0125_Servico WHERE ID_Servico = " + servicoId;
        	DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
    		if(dt.Rows.Count > 0)
            	return Convert.ToBoolean(dt.Rows[0]["Concluido"]);
			return false;
        }
        
        public bool IsServicoPortalTEF(int servicoId)
        {
        	string sqlCommand = string.Format("SELECT ID_Servico " +
        	                                  "FROM tb_0125_Servico " +
        	                                  "WHERE ID_Servico = {0} AND CaixaEntrada = '{1}'", servicoId, 
        	                                  "ibba-linhadireta-portaltef@itaubba.com");
        	DataTable dt = _dataConnector.ExecuteDataTable(sqlCommand);
        	
        	return (dt.Rows.Count > 0);
        }
        
        public void RegistrarFluxosServico(int servicoId, int idObjeto, string SistemaLog = "")
        {
            List<EtapasObjeto> etapasObjetoList = new List<EtapasObjeto>();
			
            etapasObjetoList = BuscarEtapasObjeto(idObjeto);
            if (etapasObjetoList.Count > 0)
            {
                StringBuilder sb_LogServico = new StringBuilder();
	            string datahora = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
	            string sqlCommandInsert = "INSERT INTO tb_0127_FluxoServico (ID_Servico, ID_Fluxo, ID_Status, DataAlteracaoStatus, DataCriacao, DataAlteracao, Id_Responsavel, UserCriacao, UserAlteracao, Id_Celula) SELECT * FROM (";
	
	            int auxInsert = 0;
	            foreach (EtapasObjeto etp in etapasObjetoList)
	            {
	                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Status", etp.ID_Servico, etp.ID_Etapa, 0, etp.ID_Status.ToString(), SistemaLog, datahora, "Insert"));
	                sb_LogServico.AppendLine(Log.MontaLogServico("Etapa Responsável", etp.ID_Servico, etp.ID_Etapa, 0, etp.IdResponsavel.ToString(), SistemaLog, datahora, "Insert"));
	               
	                sqlCommandInsert = String.Format(sqlCommandInsert + "SELECT {0} As ID_Servico, {1} As ID_Fluxo, " +
	                	                                 "{2} As ID_Status, #{3}# As DataAlteracaoStatus, #{3}# As DataCriacao, " +
	                	                                 "#{3}# As DataAlteracao ,{4} as Id_Responsavel, '{5}' As UserCriacao, " +
	                	                                 "'{5}' As UserAlteracao, {6} As Id_Celula " +
	                	                                 "FROM tb_0080_AuxInsertDadosServico UNION ", 
	                	                                 servicoId, etp.ID_Etapa, etp.StatusInicial, 
	                	                                 datahora, etp.IdResponsavel, Environment.UserName.ToUpper(),											 
	                	                                 etp.Id_Celula_Responsavel);
	                auxInsert = auxInsert + 1;
	            }
	
	            sqlCommandInsert = sqlCommandInsert.Remove(sqlCommandInsert.Length - 6);
	            sqlCommandInsert = sqlCommandInsert + ")";
	
	            if (auxInsert > 0)
	            {
	                string msgLog = "Criando Fluxos: " + sqlCommandInsert;
	                Log.GravaLog(msgLog);
	                DataTable multirowinsert = _dataConnector.ExecuteDataTable(sqlCommandInsert);
	            }
	            if (sb_LogServico.ToString() != "")
	                Log.GravaLog(sb_LogServico.ToString());
            }
		}
        
        List<EtapasObjeto> BuscarEtapasObjeto(int objetoId)
        {
            string sqlCommand = string.Format("SELECT * FROM vw_ObjetosEtapas " +
			                                  "WHERE ID_Objeto = {0}", objetoId);

            List<EtapasObjeto> list = new List<EtapasObjeto>();
            DataTable result = _dataConnector.ExecuteDataTable(sqlCommand);

            foreach (DataRow row in result.Rows)
                list.Add(new EtapasObjeto(row));

            return list;
        }
    }
}


/*
Alterações na tabela (feature 1):
1- Adicionar nova linha em tb_0111_Status:
		ID_Status = 32
		TipoStatus = Resposta Cliente 
		OrdemStatus = 32 
		CorStatus = YellowGreen;Black
		Primeiro = true
		Resto = False

2- Adicionar nova linha em tb_0009_PipelineVisual:
		Ordem = 12
		CriterioCor = StatusDescricao='Resposta Cliente'
		Cor = YellowGreen;Black
		TIPO = LINHA
		Colunas = null

3- Adicionar o status 'Resposta Cliente' para todas as etapas de todos objetos:
	Execute o vba (substitua o 'inserir dados' por este):
	
	Sub inserirDados()
        
        Dim rObjeto As DAO.Recordset
        Dim eEtapa As DAO.Recordset
        Dim strInsert As String
        Dim strQuery As String
        
        strQuery = "SELECT DISTINCT ID_Objeto FROM tb_0119_StatusEtapas"
        
        Set rObjeto = CurrentDb.OpenRecordset(strQuery)
        
        Do While Not rObjeto.EOF
            strQuery = "SELECT DISTINCT ID_Etapa FROM tb_0119_StatusEtapas WHERE ID_Objeto = " & rObjeto!id_objeto
            Set rEtapa = CurrentDb.OpenRecordset(strQuery)
            Do While Not rEtapa.EOF
                strInsert = "INSERT INTO tb_0119_StatusEtapas VALUES (" & rObjeto!id_objeto & ", " & rEtapa!ID_Etapa & ", 32, 'Resposta Cliente', 32, null, null, false, false, false, null)"
                CurrentDb.Execute strInsert
                rEtapa.MoveNext
            Loop
            rObjeto.MoveNext
        Loop
        
        End Sub

 
 
 */