﻿using System;
using System.Text.RegularExpressions;

namespace Mailbot
{
	public static class Utils
	{		
		public static string GetUltimaRespostaEmail(string body)
		{
			Regex regex = new Regex(@"(.*)[\r\n]*De\:(.*)[\r\n]*Enviada em\:(.*)[\r\n]*Para\:(.*)[\r\n]*(Cc\:(.*)[\n\r]*)?Assunto\:(.*)[\r\n]*");
			Match match = regex.Match(body);
			if (match.Success)
			{										
				return body.Substring(0,match.Groups[1].Index);																
			}
							
			return "";
		}
		
		public static string GetDomain(string email)
        {
        	if (email.Contains("@"))
        		return email.Split('@')[1];
        	return email;
        }
	}
}

