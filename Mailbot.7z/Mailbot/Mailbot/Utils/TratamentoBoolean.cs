﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mobios.Utils
{

    /*Dependendo do banco, retorna uma query com sintaxe apropriada*/
    static class TratamentoBoolean
    {

        public static Boolean isBoolean { set; get; }
      
        public static string TransformarBoolean(bool valor)
        {
            if (valor)
                return GetTrue();
            return GetFalse(); 
        }
        public static string GetTrue()
        {
            if (isBoolean)
                return "true";
            return "1";
        }

        public static string GetFalse()
        {         
            if (isBoolean)
                return "false";
            return "0"; 
        }
        
        private static string returnAppropriateBooleanValue(string value){
        	
        	if(value.Equals("")){
        		return "False";
        	}
        	return value;
        }
		
        public static Boolean ToBoolean(string value){
        	
        	return Convert.ToBoolean( returnAppropriateBooleanValue(value) );

        }

    }
}
