﻿using System;

namespace Mailbot
{
	/// <summary>
	/// Description of Extension.
	/// </summary>
	public static class Extension
	{
		public static string ToTrimUpper(this string value)
		{
			return value.Trim().ToUpper();
		}
	}
}
