﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mobios.Utils
{
    static class DateParser
    {
        public static Object Parse(string dateFormat,Object date, Type dateType )
        {
            string dateStr = "";
            string[] dateSplitted, dateParts;
        
            dateStr = date.ToString();
            dateSplitted = dateStr.Split(' ');
            dateParts = dateSplitted[0].Split('/');

            switch (dateFormat)
            {
                case "mdy":                    
                    dateSplitted[0] = dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2];        
                    break;
                case "dmy":
                    dateSplitted[0] = dateParts[0] + "/" + dateParts[1] + "/" + dateParts[2];
                    break;
            }
            dateStr = dateSplitted[0] + " " + dateSplitted[1];

            return Convert.ChangeType(dateStr,dateType); 
        }

        public static Object Parse(string dateFormat, Object date, bool needTime = false)
        {
            string dateStr = "";
            string[] dateSplitted, dateParts;

            dateStr = date.ToString();
            dateSplitted = dateStr.Split(' ');

            if (dateStr.IndexOf("/") != -1)
            {
                dateParts = dateSplitted[0].Split('/');
            }
            else
            {
                dateParts = dateSplitted[0].Split('-');

                // ano na frente
                if (dateParts[0].Length == 4)
                {
                    string aux = dateParts[0];
                    dateParts[0] = dateParts[2];
                    dateParts[2] = aux;
                    
                }
                
            }
            

            switch (dateFormat)
            {
                case "mdy":
                    dateSplitted[0] = dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2];
                    break;
                case "dmy":
                    dateSplitted[0] = dateParts[0] + "/" + dateParts[1] + "/" + dateParts[2];
                    break;
                case "ymd":
                    dateSplitted[0] = dateParts[2] + "/" + dateParts[1] + "/" + dateParts[0];
                    break;   
            }

            dateStr = needTime ? dateSplitted[0] + " " + dateSplitted[1] : dateSplitted[0];

            return dateStr;
        }

    }
}
