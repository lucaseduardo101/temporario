﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text.RegularExpressions;
using Mailbot.Data;
using Mailbot.Data.Entity;
using System.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Mailbot.Business
{
	/// <summary>
	/// 
	/// </summary>
	public class MailbotBusiness
	{
		MailbotDataAccess _dataAccessMailBot;
		IMobiosDataAdapter _dataAccessMobios;
		
		public MailbotBusiness()
		{
			_dataAccessMailBot = new MailbotDataAccess();
			if (System.Configuration.ConfigurationManager.AppSettings["Database"].Equals("SQLSERVER"))
			{
				_dataAccessMobios = new MobiosDataSqlServer();
			}
			else
			{
				_dataAccessMobios = new MobiosDataAccess();
			}
		}
		
		/// <summary>
		/// Elimina e-mails pelo Filtro do Assunto no Subject parametrizado em DB_Mailbot
		/// </summary>
		/// <param name="subject"></param>
		/// <param name = "pastaDestino"></param>
		/// <returns></returns>
		public bool IsValidSubject(string subject, ref string pastaDestino)
        {	
			DataTable ignoredSubjects = _dataAccessMailBot.GetIgnoreSubjects();
    		foreach (DataRow row in ignoredSubjects.Rows) 
        	{
        		if (Regex.IsMatch(subject, row["Ignore_Content"].ToString(), RegexOptions.IgnoreCase))
        		{
        			pastaDestino = row["Pasta_Destino"].ToString();
        			return false;
        		}
        	}
        	return true;
        }
		
        public bool IsValidDomain(string email, ref string pastaDestino)
        {
            return !_dataAccessMailBot.IsDomainBlackListed(email, ref pastaDestino) && !_dataAccessMailBot.IsEmailBlackListed(email, ref pastaDestino);
        }

		/// <summary>
		/// Cria Serviço genérico para área de Atendimento
		/// </summary>
		/// <returns></returns>
		public SubjectCelula GetCelulaResponsavel(string inboxEmail, string senderEmail, string assunto)
		{
			SubjectCelula subjectCelula = new SubjectCelula();
			// Suporte ao Site
			
			List<string> resultStr = _dataAccessMailBot.GetEsteiraFluxo(inboxEmail, senderEmail, assunto);
			
			if (resultStr.Count > 0)
			{
				subjectCelula.ID_DemandaClassificada = Convert.ToInt32(resultStr[0]);
				subjectCelula.ID_Segmento = _dataAccessMobios.GetSegmentoIdByName(resultStr[1]);
				subjectCelula.ID_Objeto = _dataAccessMobios.GetObjetoIdByName(resultStr[2]);
				
		    }
		    else
		    {
				if (inboxEmail.ToUpper() == System.Configuration.ConfigurationManager.AppSettings["EMAIL_SUPORTEAOSITE"].ToUpper())
				{
					subjectCelula.ID_Segmento = SharedData.ID_SEGMENTO_SUPORTEAOSITE;
					subjectCelula.ID_Celula = SharedData.ID_CELULA_SUPORTEAOSITE;
				}
				else //Atendimento
				{
					subjectCelula.ID_Segmento = SharedData.ID_SEGMENTO_ATENDIMENTO;
					subjectCelula.ID_Celula = SharedData.ID_CELULA_ATENDIMENTO;
				}
				
				/*if ((inboxName.ToUpper()) //Fluxo Portal TEF
				         .Equals(System.Configuration.ConfigurationManager.AppSettings["EMAIL_PORTALTEF"].ToUpper()))
				{
					subjectCelula.ID_Segmento = SharedData.ID_SEGMENTO_LIBERACAO;
					subjectCelula.ID_Objeto = SharedData.ID_OBJETO_LIBERACAO_PORTALTEF;
				}*/
				//else //Atendimento/Sup ao Site
				
				subjectCelula.ID_Etapa = SharedData.ID_ETAPA_ATENDIMENTO_ROBO;
				subjectCelula.ID_Objeto = SharedData.ID_OBJETO_ATENDIMENTO_ROBO;
				
			}
			return subjectCelula;
		}
		
		public List<string> GetMailBoxes(string RACF, string maquina)
		{
			List<string> result;
			
			result = _dataAccessMailBot.GetMailBoxes(RACF,maquina);
			
			return result;
		}
		
		public List<string> GetMailBoxes(string tag)
		{
			List<string> result;
			
			result = _dataAccessMailBot.GetMailBoxes(tag);
			
			return result;
		}
		
		public bool IsMailAllowed(string Email, string tag)
		{
			return _dataAccessMailBot.IsMailAllowed(Email, tag);
		}

        public void UpdateMailboxLastCheck(string mailbox)
        {
            _dataAccessMailBot.UpdateMailboxLastCheck(mailbox, DateTime.Now);
        }
		
		public bool ValidaAcesso(string usuario, string maquina)
		{
			try
			{				
				return _dataAccessMailBot.CheckAcessos(usuario,maquina);												
			}
			catch(Exception e)
			{
				Log.GravaLog("MailbotBusiness: Erro ao Autenticar o usuario. "+ e.Message);
				return false;
			}
		}
    
		public string GetEmailsParaReportarErro(){
			
			List<string> result = _dataAccessMailBot.GetEmailsParaReportarErro();
			
			string emails = "";
			
			foreach(string email in result){
				emails += email;
			}

			return emails;
		}
		
		public string VerificaVersaoExchange(string usuario, string maquina, string caixaEntrada)
		{
			try
			{				
				return _dataAccessMailBot.VerificaVersaoExchangeServer(usuario,maquina,caixaEntrada);												
			}
			catch(Exception e)
			{
				Log.GravaLog("MailbotBusiness: Erro ao recuperar a versao do exchange server. "+ e.Message);
				return "";
			}
		}
		
		public string GetTipoGarantia(string nomePastaEntrada)
		{
			string tipoGarantia = "";
			
			tipoGarantia = _dataAccessMailBot.GetTipoGarantia(nomePastaEntrada);
			
			if (tipoGarantia.Equals("") && !nomePastaEntrada.ToUpper().Equals("WORKFLOW-ATENDIMENTO-OUTROSBENS"))
				//Se não encontra tipoGarantia (exceto OutrosBens que não há DePara de Tipo de Garantia)
				SharedData.Quit();
			
			return tipoGarantia;
		}
		
		public DataTable GetParametros()
        {
        	return _dataAccessMailBot.GetParametros();
        }

	}

}
