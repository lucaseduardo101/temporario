﻿using System;
using System.Data;
using Mailbot.Data;
using Mailbot.Data.Entity;
using System.Text.RegularExpressions;
using Mailbot.Formater;

namespace Mailbot.Business
{
	public class MobiosBusiness
	{
		IMobiosDataAdapter _dataAccessMobios;
		MailbotDataAccess _dataAccessMailbot;
		
		public MobiosBusiness()
		{
			if (System.Configuration.ConfigurationManager.AppSettings["Database"].Equals("SQLSERVER"))
			{
				_dataAccessMobios = new MobiosDataSqlServer();
			}
			else
			{
				_dataAccessMobios = new MobiosDataAccess();
			}
			
			_dataAccessMailbot = new MailbotDataAccess();
		}
		
		public int RegistrarServico(Email newEmail)
        {
			string cc = (newEmail.To_Email + ";" + newEmail.CC).Replace("'", "").Replace("\"", "");
			// TODO paliativo para tratar o sql injection
			string assunto = newEmail.Assunto.Replace("'", "").Replace("\"", "");
            string body = newEmail.Body.Replace("'", "").Replace("\"", "");
            string Sender = newEmail.Sender_Email.Replace("'","''").Replace("\"","");
            
            
            newEmail.Assunto = assunto;
            newEmail.Body = body;
            newEmail.CC = cc;
            newEmail.Sender_Email = Sender;
            

            int servicoId = 0;
            //Registrar Novo Serviço
            Servico novoServico = new Servico
            {
                ID_Objeto = newEmail.Celula_Responsavel.ID_Objeto,
                DataCriacao = DateTime.Now,                
                Usuario = System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"],
                ID_Segmento = newEmail.Celula_Responsavel.ID_Segmento,
                Assunto = newEmail.Assunto,
                Body = newEmail.Body,
                /*Caixa de entrada - Adicionado 17/07
                  Suporte a divisao por caixas de entrada analisadas*/
                CaixaEntrada = newEmail.CaixaEntrada,
                EmailCliente = newEmail.Sender_Email,
				DataRecebimento = newEmail.ReceivedTime, // Data e hora em o email foi recebido no outlook                			
            };
			
            servicoId = _dataAccessMobios.RegistrarServico(novoServico);

            if (servicoId > 0)
            {
            	if (newEmail.Celula_Responsavel.ID_DemandaClassificada != 0)
            	{
            		_dataAccessMobios.RegistrarFluxosServico(servicoId, novoServico.ID_Objeto);
            		int idEtapa = _dataAccessMobios.getEtapaAtual(servicoId);
	                _dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_CRIACAO_MAILBOT, newEmail.Celula_Responsavel.ID_Etapa);
	                _dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_AGUARDANDO_ATUACAO, idEtapa);
            	}
            	else //Atendimento / Sup ao Site
            	{
	                //Sucesso -> Registrar Fluxos do Serviço
	                FluxoServico novoFluxoServico = new FluxoServico
	                {
	                    ID_Servico = servicoId,
	                    ID_Fluxo = newEmail.Celula_Responsavel.ID_Etapa, //Apenas uma etapa/fluxo para este Serviço. Não pegaremos de EtapasObjetos por enquanto.
	                    ID_Status = SharedData.ID_STATUS_AGUARDANDO_ATUACAO,
	                    DataCriacao = newEmail.ReceivedTime,
	                    UserCriacao = System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"],
	                    ID_Responsavel = 0,
	                    ID_Celula = newEmail.Celula_Responsavel.ID_Celula
	                };
	
	                _dataAccessMobios.RegistrarFluxoServico(novoFluxoServico);
	                _dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_CRIACAO_MAILBOT, newEmail.Celula_Responsavel.ID_Etapa);
	                _dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_AGUARDANDO_ATUACAO, newEmail.Celula_Responsavel.ID_Etapa);
            	}
                //Cadastrar Dados do Serviço - Assunto do email
               	DadosServico dadosServico = new DadosServico
               	{
               		ID_Servico = servicoId,
               		ID_Campo = SharedData.ID_CAMPO_EMAIL_ASSUNTO,
               		NomeCampo = System.Configuration.ConfigurationManager.AppSettings["NOME_CAMPO_EMAIL_ASSUNTO"],
               		//Remover caracteres especiais
               		ValorCampo = StringFormater.RemoveUnsuportedCharacters(newEmail.Assunto),
               		DataCriacao = newEmail.ReceivedTime
               	};
               	
               	_dataAccessMobios.RegistrarDadosServico(dadosServico);

                //Cadastrar Dados do Serviço - Corpo do email

                dadosServico.ID_Servico = servicoId;
                dadosServico.ID_Campo = SharedData.ID_CAMPO_EMAIL_CORPO;
                dadosServico.NomeCampo = System.Configuration.ConfigurationManager.AppSettings["NOME_CAMPO_EMAIL_CORPO"]; 
                
                //Remover caracteres especiais
                string htmlBody = System.Web.HttpUtility.HtmlEncode(newEmail.HTMLBody); //Enconde HTML para fazer scape de caracteres no corpo do E-mail
                htmlBody = StringFormater.RemoveUnsuportedCharacters(htmlBody);
                dadosServico.ValorCampo = htmlBody;
                dadosServico.DataCriacao = newEmail.ReceivedTime;
                
                _dataAccessMobios.RegistrarDadosServico(dadosServico);
				
                //Cadastrar Dados do Serviço - CC. do e-mail           

                dadosServico.ID_Servico = servicoId;
                dadosServico.ID_Campo = SharedData.ID_CAMPO_EMAIL_COPIA;
                dadosServico.NomeCampo = System.Configuration.ConfigurationManager.AppSettings["NOME_CAMPO_EMAIL_COPIA"];
                
                dadosServico.ValorCampo = StringFormater.RemoveUnsuportedCharacters(newEmail.CC);
                dadosServico.DataCriacao = newEmail.ReceivedTime;
                
                _dataAccessMobios.RegistrarDadosServico(dadosServico);
                
                if(newEmail.Celula_Responsavel.ID_DemandaClassificada != 0)
                {
                	DataTable dt = _dataAccessMailbot.GetCamposValor(newEmail.Celula_Responsavel.ID_DemandaClassificada);
	                foreach(DataRow row in dt.Rows)
	                {
	                	dadosServico.ID_Campo = Convert.ToInt32(row["ID_Campo"]);
	                	dadosServico.NomeCampo = row["NomeCampo"].ToString();
	                	dadosServico.ValorCampo = row["ValorCampo"].ToString();
	                	_dataAccessMobios.RegistrarDadosServico(dadosServico);
	                }
                }
                
                //Garantias Proprias - Incluir tipo de garantia de acordo com a Tag
                if (SharedData.IsProprias && !String.IsNullOrEmpty(newEmail.TipoGarantia))
                {
                	dadosServico.ID_Servico = servicoId;
                	dadosServico.ID_Campo =  SharedData.ID_CAMPO_TIPOGARANTIA;
                	dadosServico.NomeCampo = System.Configuration.ConfigurationManager.AppSettings["NOME_CAMPO_TIPOGARANTIA"];
                	dadosServico.ValorCampo = newEmail.TipoGarantia;
                	_dataAccessMobios.RegistrarDadosServico(dadosServico);
                }
                
            }
            else
            {
                Console.WriteLine("Erro ao cadastrar nova demanda. ServicoId = 0");
                Log.GravaLog("Erro ao cadastrar nova demanda. ServicoId = 0");
            }

            return servicoId;
        }		
		
		/*Registrar anexos no Mobios*/
		public void RegistrarAnexos(DadosAnexo anexo){
			if(!_dataAccessMobios.ExisteAnexo(anexo))
				_dataAccessMobios.RegistrarAnexos(anexo);
		}
		
		public int GetServicoByEmailConversationId(string conversationEmailId)
		{
			return _dataAccessMobios.GetServicoByEmailConversationId(conversationEmailId);
		}
		
		public void ReabrirChamado(int servicoPaiId, int servicoFilhoId)
		{
			_dataAccessMobios.ReabrirChamado(servicoPaiId, servicoFilhoId);
			int idEtapa = _dataAccessMobios.getEtapaAtual(servicoPaiId);
			_dataAccessMobios.RegistrarDadosStatusEtapa(servicoPaiId, SharedData.ID_STATUS_REABERTURA_NOVO_ID, idEtapa);
		}
		
		public int GetServicoTo(int servicoPaiId)
		{
			return _dataAccessMobios.GetServicoTo(servicoPaiId);
		}
		
		public void HandleAbertura(ref int servicoId, ref bool servicoCriado, ref bool novoServico, Email newEmail, ref bool updateWFId)
		{
			int servicoPaiId = 0;
			
			if(!String.IsNullOrEmpty(newEmail.ID_Conversation))
			{
				servicoPaiId = GetServicoByEmailConversationId(newEmail.ID_Conversation);
				if(servicoPaiId > 0)
					Log.WriteLog("ConversationID encontrado: ID " + servicoPaiId + "\n");
			}
				
			
			if(servicoId > 0)
			{
				if(SharedData.gReabrirMesmoId && !newEmail.CaixaEntrada.ToUpper().Equals(System.Configuration.ConfigurationManager.AppSettings["EMAIL_PORTALTEF"].ToUpper())
				   && !IsServicoPortalTEF(servicoId))
				{
					ReabrirMesmoId(servicoId, ref updateWFId);
				}
				else
				{
					int servicoReabertoId = (servicoPaiId > 0)? servicoPaiId : servicoId;
					servicoId = RegistrarServico(newEmail);
					ReabrirChamado(servicoReabertoId, servicoId);
					Log.WriteLog("Workflow reaberto por TAG (" + servicoReabertoId + "): ID " + servicoId + "\n");
					servicoCriado = true;
				}
			}
			else if(servicoPaiId > 0)
			{
				servicoId = RegistrarServico(newEmail);
				ReabrirChamado(servicoPaiId, servicoId);
				Log.WriteLog("Workflow reaberto por ConversationID (" + servicoPaiId + "): ID " + servicoId + "\n");
				servicoCriado = true;
			}
			else if (SharedData.IsTerceiros) //Caso especial de reabertura por padronizacao no assunto
			{
				var match = Regex.Match(newEmail.Assunto, System.Configuration.ConfigurationManager
				                        .AppSettings["PADRAO_PROPOSTA_ASSUNTO"]);
				if (match.Success)
				{
					//Utilizaremos a mesma logica do conversationId, 
					//porem utilizaremos a parte do assunto padronizado
					String conversationId = match.Captures[0].Value;
					//Terceiros: Se o seu assunto venha no formato 
					//#Proposta Nro 12345# devemos reabrir a demanda relacionada a esse ID
					servicoId = GetServicoByEmailConversationId(conversationId);
					
					if (servicoId > 0)
					{
						ReabrirMesmoId(servicoId, ref updateWFId);
					}
					else
					{
						//Abrir nova demanda com conversationId = #Proposta Nro 12345#
						servicoId = RegistrarServico(newEmail);
						_dataAccessMobios.CreateServicoConversationId(servicoId, conversationId);
						novoServico = true;
						servicoCriado = true;
			            Log.WriteLog("Workflow criado: ID " + servicoId + "\n");
					}
				}
				else
				{
					//Abrir nova demanda
					servicoId = RegistrarServico(newEmail);
					_dataAccessMobios.CreateServicoConversationId(servicoId, newEmail.ID_Conversation);
					novoServico = true;
					servicoCriado = true;
		            Log.WriteLog("Workflow criado: ID " + servicoId + "\n");
				}
			}
			else
			{
				servicoId = RegistrarServico(newEmail);
				_dataAccessMobios.CreateServicoConversationId(servicoId, newEmail.ID_Conversation);
				novoServico = true;
				servicoCriado = true;
	            Log.WriteLog("Workflow criado: ID " + servicoId + "\n");
			}
		}
		
		void ReabrirMesmoId(int servicoId, ref bool updateWFId)
		{
			//Encontra Servico Classificado
			int idServicoDemandaAberta = _dataAccessMobios.GetServicoTo(servicoId);
			//Se nao encontrou retorno o proprio Generico
			if (idServicoDemandaAberta == 0)
				idServicoDemandaAberta = servicoId;
			
			//Procura pela etapa atual da demanda
			int idEtapa = _dataAccessMobios.getEtapaAtual(idServicoDemandaAberta);
			if(idEtapa > 0)
			{
				int idStatus = SharedData.ID_STATUS_RESPOSTA_CLIENTE;
				//Caso a etapa atual tenha status "Resposta Cliente", entao atribuiremos este status a etapa
				bool hasStatus = _dataAccessMobios.HasStatus(idServicoDemandaAberta, idEtapa, idStatus);
				
				if (idServicoDemandaAberta > 0 && hasStatus)
				{
					AlterarStatusEtapa(idServicoDemandaAberta, idStatus, idEtapa, true);
					Log.WriteLog("Workflow atualizado: ID " + idServicoDemandaAberta + "\n");
					updateWFId = true;
				} 
			}
		}
		
		bool IsServicoPortalTEF(int servicoId)
		{
			return _dataAccessMobios.IsServicoPortalTEF(servicoId);
		}
		
        public bool VerificaFluxoAreas(int servicoId)
        {
        	return _dataAccessMobios.VerificaObjetoFluxoAreas(servicoId);
        }
        
        public int VerificaIdServico(string body)
        {
            Regex regex = new Regex("<div id=\\\\?\"?Servico(\\d+)");
            Match match = regex.Match(body);
            int id = (match.Success? Convert.ToInt32(match.Groups[1].Value) : -1);
            if(id > 0)
            	Log.WriteLog("Tag em E-mail Encontrada: ID " + id + "\n");
            return id;
        }

        public void PreencheResposta(int servicoID, string resposta)
        {
            DadosServico novo = new DadosServico();
            novo.DataCriacao = DateTime.Now;
            novo.NomeCampo = "Resposta";
            novo.ID_Campo = _dataAccessMobios.GetCampoIDByNome("Resposta");
            novo.ValorCampo = StringFormater.RemoveUnsuportedCharacters(resposta);
            novo.ID_Servico = servicoID;

            _dataAccessMobios.RegistrarDadosServico(novo);
        }

        public void PreencheFollowUp(FollowUp followup)
        {
            _dataAccessMobios.RegistrarFollowUpEtapaServico(followup);
        }
        
        public void AlterarStatusEtapa(int servicoId, int ID_Status, int ID_Etapa = -1, bool reabrir = false)
        {
        	if(reabrir && _dataAccessMobios.IsConcluido(servicoId))
            {
        		_dataAccessMobios.ReabrirServico(servicoId);
            	_dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_REABERTURA, ID_Etapa);
            	Log.WriteLog("Workflow reaberto: ID " + servicoId + "\n");
            }
        	else
        	{
            	_dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, SharedData.ID_STATUS_ATUALIZACAO_MAILBOT, ID_Etapa);
        	}
        	
            _dataAccessMobios.AlterarStatusEtapa(servicoId, ID_Status, ID_Etapa, reabrir);
            _dataAccessMobios.RegistrarDadosStatusEtapa(servicoId, ID_Status, ID_Etapa);
        }
        
        public DataTable BuscarConstantes()
        {
        	return _dataAccessMobios.BuscarConstantes();
        }
        
        public bool ValidaFluxoAreas (int IdServico)
        {
        	return _dataAccessMobios.ValidaFluxoAreas(IdServico);
        }
    }
}
