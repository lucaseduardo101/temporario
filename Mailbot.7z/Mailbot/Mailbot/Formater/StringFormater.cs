﻿/*
 * Created by SharpDevelop.
 * User: malunaa
 * Date: 13/10/2017
 * Time: 12:18
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;

namespace Mailbot.Formater
{
	/// <summary>
	/// Description of EmailFormater.
	/// </summary>
	public static class StringFormater
	{
		//Caracteres invalidos em comum para os campos de email
		public static string RemoveUnsuportedCharacters(string ValorCampo)
		{
			string newValorCampo = ValorCampo.Replace("'","''");
			
			return newValorCampo;
									
		}
	}
}
