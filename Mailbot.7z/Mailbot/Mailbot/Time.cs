﻿using System;

namespace Mailbot
{
	public static class Time
    {
        public static void pausaMilisegundos(int MyMilliseconds)
        {
            //Application.DoEvents();
            DateTime TimeNow = new DateTime();
            TimeNow = DateTime.Now;
            while (true)
            {
            	if ((DateTime.Now - TimeNow).TotalMilliseconds > MyMilliseconds)
            	{
            		break;
            	}
                //Application.DoEvents();
            }
        }
    }
}