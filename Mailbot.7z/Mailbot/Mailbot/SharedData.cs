﻿/*
 * Created by SharpDevelop.
 * User: rodbrun
 * Date: 29/06/2017
 * Time: 17:43
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using Mailbot.Business;

namespace Mailbot
{
	/// <summary>
	/// Description of SharedData.
	/// </summary>
	public static class SharedData
	{		
	
		public static int ID_SEGMENTO_ATENDIMENTO;
		public static int ID_SEGMENTO_SUPORTEAOSITE;
		public static int ID_SEGMENTO_LIBERACAO;
		public static int ID_OBJETO_ATENDIMENTO_ROBO;
		public static int ID_OBJETO_LIBERACAO_PORTALTEF;
		public static int ID_CELULA_ATENDIMENTO;
		public static int ID_CELULA_SUPORTEAOSITE;		
		public static int ID_ETAPA_ATENDIMENTO_ROBO;
		public static int ID_ETAPA_AGUARDAR_RESPOSTA;
		public static int ID_CAMPO_EMAIL_ASSUNTO;
		public static int ID_CAMPO_EMAIL_CORPO;
		public static int ID_CAMPO_EMAIL_COPIA;
		public static int ID_CAMPO_TIPOGARANTIA;
		public static int ID_STATUS_EM_ANDAMENTO;		
		public static int ID_STATUS_RESPONDIDO;
		public static int ID_STATUS_AGUARDANDO_ATUACAO;
		public static int ID_STATUS_REABERTURA;
		public static int ID_STATUS_REABERTURA_NOVO_ID;
		public static int ID_STATUS_CRIACAO_MAILBOT;
		public static int ID_STATUS_ATUALIZACAO_MAILBOT;
		public static string Usuario;
		public static string Maquina;
		public static int ID_STATUS_RESPOSTA_CLIENTE;
		public static string TAG;
		
		public static bool IsAtendimento;
		public static bool IsProprias;
		public static bool IsTerceiros;
		public static bool IsRendaFixa;
		
		public static bool gColocarIdAssunto;
		public static bool gReabrirMesmoId;
		public static bool gEnviarRespostaAutomatica { get; set; }
		
		public static DataTable Parametros { get; set; }
		public static string gRespostaAutomatica { get; set; }
		public static string gAssinatura { get; set; }
		public static string gPathImagensResposta { get; set; }
		public static string gImagensResposta { get; set; }
		public static void Quit()
        {
			/*
			try
			{
				GC.Collect();
            	GC.WaitForPendingFinalizers();            
			}
			catch
			{
				//Força fechamento do programa
				Environment.FailFast("Erro no Garbage Collector");
			}*/
            
            // Console app
            System.Environment.Exit(1);
        }			
		
		public static void LoadConstantes()
		{
			try
			{							
				MobiosBusiness mobiosbusiness = new MobiosBusiness();
				DataTable tabela = mobiosbusiness.BuscarConstantes();
				
				//Recupera Segmentos
				DataRow[] Segmentos = tabela.Select("src='Segmento'");
				foreach(DataRow dr in Segmentos)
				{
					if (dr["Nome"].Equals("Atendimento"))
						ID_SEGMENTO_ATENDIMENTO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Suporte ao Site"))
						ID_SEGMENTO_SUPORTEAOSITE = Convert.ToInt32(dr["ID"]);		
					else if (dr["Nome"].Equals("Liberação"))
						ID_SEGMENTO_LIBERACAO = Convert.ToInt32(dr["ID"]); 
				}			
				//Recupera Objetos
				DataRow[] Objetos = tabela.Select("src='Objeto'");
				foreach(DataRow dr in Objetos)
				{
					if (dr["Nome"].Equals("Atendimento-Abertura Automática") || dr["Nome"].Equals("Triagem-Email"))
						ID_OBJETO_ATENDIMENTO_ROBO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Liberação de Recursos (Portal TEF)"))
						ID_OBJETO_LIBERACAO_PORTALTEF = Convert.ToInt32(dr["ID"]);
				}			
							
				//Recupera Celula			
				DataRow[] Celulas = tabela.Select("src='Celula'");
				foreach(DataRow dr in Celulas)
				{
					if (dr["Nome"].Equals("Atendimento"))
						ID_CELULA_ATENDIMENTO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Suporte ao Site"))
						ID_CELULA_SUPORTEAOSITE = Convert.ToInt32(dr["ID"]);		
				}
				
				//Recupera Etapas
				DataRow[] Etapas = tabela.Select("src='Etapas'");
				foreach(DataRow dr in Etapas)
				{							
					if (dr["Nome"].Equals("Abertura"))
						ID_ETAPA_ATENDIMENTO_ROBO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Aguardando Resposta"))
						ID_ETAPA_AGUARDAR_RESPOSTA = Convert.ToInt32(dr["ID"]);
				}
				
				//Recupera Campos
				DataRow[] Campos = tabela.Select("src='Campos'");
				foreach(DataRow dr in Campos)
				{
					if (dr["Nome"].Equals("E-mail Assunto"))
						ID_CAMPO_EMAIL_ASSUNTO = Convert.ToInt32(dr["ID"]);			
					else if (dr["Nome"].Equals("E-mail Corpo"))
						ID_CAMPO_EMAIL_CORPO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("E-mail Copia - Retorno"))
						ID_CAMPO_EMAIL_COPIA = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Tipo de Garantia"))
						ID_CAMPO_TIPOGARANTIA = Convert.ToInt32(dr["ID"]);
				}
				
				//Recupera Status
				DataRow[] Status = tabela.Select("src='Status'");
				foreach(DataRow dr in Status)
				{				
					if (dr["Nome"].Equals("Em Andamento"))
						ID_STATUS_EM_ANDAMENTO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Respondido"))
						ID_STATUS_RESPONDIDO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Aguardando Atuação"))
						ID_STATUS_AGUARDANDO_ATUACAO = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Resposta Cliente"))
						ID_STATUS_RESPOSTA_CLIENTE = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Reabertura - Mailbot"))
						ID_STATUS_REABERTURA = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Reabertura Novo ID - Mailbot"))
						ID_STATUS_REABERTURA_NOVO_ID = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Criação Via Mailbot"))
						ID_STATUS_CRIACAO_MAILBOT = Convert.ToInt32(dr["ID"]);
					else if (dr["Nome"].Equals("Atualização Via Mailbot"))
						ID_STATUS_ATUALIZACAO_MAILBOT = Convert.ToInt32(dr["ID"]);
				}
				
				Usuario = Environment.UserName;
				Maquina = Environment.MachineName;
				
				if(System.Configuration.ConfigurationManager.AppSettings["AREA"].ToUpper().Equals("ATENDIMENTO"))
					IsAtendimento = true;
				else if(System.Configuration.ConfigurationManager.AppSettings["AREA"].ToUpper().Equals("PROPRIAS"))
					IsProprias = true;
				else if(System.Configuration.ConfigurationManager.AppSettings["AREA"].ToUpper().Equals("TERCEIROS"))
					IsTerceiros = true;
				else if(System.Configuration.ConfigurationManager.AppSettings["AREA"].ToUpper().Equals("RENDA_FIXA"))
					IsRendaFixa = true;
				
				gEnviarRespostaAutomatica = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["ENVIAR_RESPOSTA_AUTOMATICA"]);
	            gReabrirMesmoId = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["REABRIR_MESMO_ID"]);
				gColocarIdAssunto = Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["COLOCAR_ID_ASSUNTO"]);
			}
			catch(Exception e)
			{
				Log.GravaLog("Erro ao carregar constantes");
				SharedData.Quit();
			}
			finally
			{
				Log.GravaLog("Constantes carregadas");
			}
		}
		
		public static string LoadParametros()
		{
			MailbotBusiness mailbotbusiness = new MailbotBusiness();
			string str_return = "";
			
            try
            {
				DataTable dt = mailbotbusiness.GetParametros();

                if (dt.Rows.Count > 0)
                {
                    SharedData.Parametros = dt.Copy();
                    str_return = "RespostaAutomatica"; SharedData.gRespostaAutomatica = dt.Select("NOME = 'RespostaAutomatica'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "Assinatura"; SharedData.gAssinatura = dt.Select("NOME = 'Assinatura'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "PathImagensResposta"; SharedData.gPathImagensResposta = dt.Select("NOME = 'PathImagensResposta'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    str_return = "ImagensResposta"; SharedData.gImagensResposta = dt.Select("NOME = 'ImagensResposta'").CopyToDataTable().Rows[0]["VALOR"].ToString();
                    
                    str_return = "";

                }
            }
            catch (Exception ex)
            {
                string msgLog = "Erro no parametro: " + ex;
                Log.GravaLog(msgLog);
                SharedData.Quit();
            }

            return str_return;
		}
		
	}
}
