﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.IO;
using Mailbot.Data;

namespace Mailbot
{
    public static class Log
    {	
    	
    	public static void WriteLog(string message, bool Erro = false)
        {
        	Console.WriteLine(message);
        	Log.GravaLog(message, Erro);        	
        }
    	
        public static void CriaDiretorioRede(string PathAnexos)
        {
            // verifica se diretório existe
            if (!Directory.Exists(PathAnexos))
            {
                Directory.CreateDirectory(PathAnexos);
            }
        }

        public static void CopiaDiretorio(string sourceDirName, string destDirName, bool copySubDirs, bool overwrite = true)
        {
            DirectoryInfo dir = new DirectoryInfo(sourceDirName);
            DirectoryInfo[] dirs = dir.GetDirectories();

            // If the source directory does not exist, throw an exception.
            if (!dir.Exists)
            {
                throw new DirectoryNotFoundException("Source directory does not exist or could not be found: " + sourceDirName);
            }

            // If the destination directory does not exist, create it.
            if (!Directory.Exists(destDirName))
            {
                Directory.CreateDirectory(destDirName);
            }


            // Get the file contents of the directory to copy.
            FileInfo[] files = dir.GetFiles();

            foreach (FileInfo file in files)
            {
                if (file.Extension.ToUpper() != ".LACCDB")
                {
                    int i = 0;
                    while (i < 5)
                    {
                        try
                        {
                            // Create the path to the new copy of the file.
                            string temppath = Path.Combine(destDirName, file.Name);

                            // Copy the file.
                            if (!File.Exists(temppath))
                            {
                                file.CopyTo(temppath, false);
                            }
                            else
                            {
                                if (overwrite)
                                {
                                    File.Delete(temppath);
                                    file.CopyTo(temppath, false);
                                }
                            }
                            break;
                        }
                        catch (Exception e)
                        {
                            if (i == 4)
                            {
                                throw new Exception(e.Message);
                            }
                        }
                        PausaMilisegundos(800);
                        i++;
                    }
                }
            }

            // If copySubDirs is true, copy the subdirectories.
            if (copySubDirs)
            {

                foreach (DirectoryInfo subdir in dirs)
                {
                    // Create the subdirectory.
                    string temppath = Path.Combine(destDirName, subdir.Name);

                    // Copy the subdirectories.
                    CopiaDiretorio(subdir.FullName, temppath, copySubDirs);
                }
            }
        }

        public static void MoveDiretorio(string diretorioOrigem, string diretorioDestino)
        {

            if (!Directory.Exists(diretorioDestino))
            {
                Directory.Move(diretorioOrigem, diretorioDestino);
            }
            else
            {
                var files = Directory.EnumerateFiles(diretorioOrigem, "*", SearchOption.AllDirectories).GroupBy(s => Path.GetDirectoryName(s));
                foreach (var folder in files)
                {
                    foreach (var file in folder)
                    {
                        string subfolder = Path.GetDirectoryName(file);
                        subfolder = subfolder.Replace(diretorioOrigem, "");
                        if (subfolder == "")
                        {
                            subfolder = diretorioDestino;
                        }
                        else
                        {
                            subfolder = AdicionaBarraPath(diretorioDestino) + subfolder;
                        }

                        if (!Directory.Exists(subfolder))
                        {
                            Log.CriaDiretorioRede(subfolder);
                        }

                        var targetFile = Path.Combine(subfolder, Path.GetFileName(file));
                        if (File.Exists(targetFile))
                        {
                            File.Delete(targetFile);
                        }
                        File.Move(file, targetFile);
                    }
                }
                Directory.Delete(diretorioOrigem, true);
            }
        }

        public static void DeletaDiretorio(string Dir)
        {
            if (Directory.Exists(Dir))
            {
                DirectoryInfo di = new DirectoryInfo(Dir);

                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
                //foreach (DirectoryInfo dir in di.GetDirectories())
                //{
                di.Delete(true);
                //}
            }
        }

        public static void GravaLinha(StreamWriter objWriter, string Linha)
        {
            int i = 0;
            while (i < 5)
            {
                try
                {
                    objWriter.WriteLine(Linha);
                    break;
                }
                catch { }
                PausaMilisegundos(800);
                i++;
            }
        }
		                
        public static void GravaLog(string Mensagem, bool Erro=false)
        {
            try
            {
            	string NomeSistema = SharedData.Usuario;
            	string pathLog = System.Configuration.ConfigurationManager.AppSettings["PATH_LOG"];
                pathLog = AdicionaBarraPath(pathLog);
                pathLog = pathLog + "Log\\" + DateTime.Today.ToString("yyyy") + "\\" + DateTime.Today.ToString("MM") + "\\" + DateTime.Today.ToString("yyyyMMdd") + "\\" + NomeSistema;
                pathLog = AdicionaBarraPath(pathLog);                
                
                if (Erro)
                {
               		//Se for log de erro coloca em um diretorio separado
               		pathLog = AdicionaBarraPath(pathLog) + "ErrorFolder\\";               		
               		NomeSistema += "Erro";
                }
                
                CriaDiretorioRede(pathLog);
                string PathFull = pathLog + DateTime.Now.ToString("yyyyMMdd_") + NomeSistema + "Log.log";
                string Linha = "";
                //Verifica se arquivo existe
                if (!File.Exists(PathFull))
                {
                    using (StreamWriter sw = File.CreateText(PathFull))
                    {
                        Linha = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] - Arquivo de LOG - " + NomeSistema + ": Data " + DateTime.Now.ToString("dd/MM/yyyy");
                        GravaLinha(sw, Linha);
                        sw.Close();
                    }
                }

                Linha = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] [" + System.Diagnostics.Process.GetCurrentProcess().Id + "][" + Environment.MachineName.ToUpper() + "][" + Environment.UserName.ToUpper() + "] " + Mensagem;

                int i = 0;
                while (i < 5)
                {
                    try
                    {
                        StreamWriter objWriter = File.AppendText(PathFull);
                        GravaLinha(objWriter, Linha);
                        // Fecha
                        objWriter.Close();
                        break;
                    }
                    catch { }
                    PausaMilisegundos(800);
                    i++;
                }
            }
            catch (Exception ex)
            {
                StringBuilder err = new StringBuilder();
                FormatarErro(err, ex);
                Log.WriteLog("Erro ao gravar LOG:\n\n" + err);
            }
            
        }

        public static void GravaResumoServico(string PathLOG, string Mensagem, string NomeSistema)
        {
            PathLOG = AdicionaBarraPath(PathLOG);
            PathLOG = PathLOG + "Resumo\\";
            CriaDiretorioRede(PathLOG);
            string PathFull = PathLOG + DateTime.Now.ToString("yyyyMMdd_") + NomeSistema + "Servico.txt";
            string Linha = "";
            //Verifica se arquivo existe
            if (!File.Exists(PathFull))
            {
                using (StreamWriter sw = File.CreateText(PathFull))
                {
                    Linha = "[" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "] - Arquivo de Servico - " + NomeSistema + ": Data " + DateTime.Now.ToString("dd/MM/yyyy");
                    GravaLinha(sw, Linha);
                    sw.Close();
                }
            }
            StreamWriter objWriter = File.AppendText(PathFull);
            Linha = "[" + DateTime.Now.ToString("yyyy-MM-dd hh:mm:ss") + "] - " + Mensagem;
            GravaLinha(objWriter, Linha);
            // Fecha
            objWriter.Close();
        }

        public static string MontaLogServico(string Descrição, int IdServico, int IdEtapa, int IdCampo, string Valor, string Complemento, string DataHora, string tipoQuery)
        {
            string Linha = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ";" + Environment.MachineName.ToUpper().Replace(";", ",") + ";" + Environment.UserName.ToUpper().Replace(";", ",") + ";" + tipoQuery.ToUpper().Replace(";", ",") + ";" + Descrição.Replace(";", ",") + ";" + IdServico + ";" + IdEtapa + ";" + IdCampo + ";" + Valor.Replace(";", ",") + ";" + Complemento.Replace(";", ",") + ";" + DataHora;
            return Linha;
        }
        
        public static string MontaLogServico(string Titulo, int IdServico, int IdEtapa, string Valor, string Complemento, string DataHora, string tipoQuery)
        {
        	string Linha = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + ";" + Environment.MachineName.ToUpper().Replace(";", ",") + ";" + Environment.UserName.ToUpper().Replace(";", ",") + ";" + tipoQuery.ToUpper().Replace(";", ",") + ";" + Titulo.Replace(";", ",") + ";" + IdServico + ";" + IdEtapa + ";" + Valor.Replace(";", ",") + ";" + Complemento.Replace(";", ",") + ";" + DataHora;
        	return Linha;
        }
        
        static void PausaMilisegundos(int MyMilliseconds)
        {
            DateTime TimeNow = new DateTime();
            TimeNow = DateTime.Now;
            while ((DateTime.Now - TimeNow).TotalMilliseconds < MyMilliseconds)
            {
                if ((DateTime.Now - TimeNow).TotalMilliseconds > 5000 && (DateTime.Now - TimeNow).TotalMilliseconds < 5100) 
                	Log.WriteLog("5 segundos");
            }
        }
        
        static string AdicionaBarraPath(string Path)
        {
            if (Path.Length > 0)
            {
                if (Path.Substring(Path.Length - 1, 1) != @"\")
                {
                    Path += @"\";
                }
            }
            return Path;
        }
        
        static string FormatarErro(StringBuilder sb, Exception e)
        {
            string user = WindowsIdentity.GetCurrent().Name.Split('\\')[1].ToUpper();
            sb.AppendFormat("\n\n\n\n\nUser: {0}  | Date: {1} \n\n\n", user, DateTime.Now);
            sb.AppendFormat("Exception Found:\nType: {0}", e.GetType().FullName);
            sb.AppendFormat("\nMessage: {0}", e.Message);
            sb.AppendFormat("\nSource: {0}", e.Source);
            sb.AppendFormat("\nStacktrace: {0} \n\n\n", e.StackTrace);

            if (e.InnerException != null)
            {
                sb.Append("\n");
                FormatarErro(sb, e.InnerException);
            }

            return sb.ToString();
        }
                
        
    }
}


