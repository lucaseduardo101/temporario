﻿using System;
using System.Collections.Generic;
using System.Security.Authentication;
using System.Text.RegularExpressions;
using System.Timers;
using Mailbot;
using Mailbot.Business;
using Mailbot.Exceptions;
using Mailbot.Data.Entity;
using Microsoft.Exchange.WebServices.Data;
using System.IO;
using Microsoft.TeamFoundation.WorkItemTracking.Controls;
using System.Net.Mail;
using Mailbot.Formater;
using Outlook = Microsoft.Office.Interop.Outlook;

namespace Mailbot
{
	
    public class Program
    {
        public static int Main(string[] args)
        {
        	try
        	{
	        	int numEmail = 0;        	        	
	            if (args.Length == 2)
	            {
	            	
	            	SharedData.LoadConstantes(); //Carrega constantes            	
					
	            	//Funcionalidade Terceiros: Reply automatico ao cliente
					if (SharedData.gEnviarRespostaAutomatica)
					{
						if(SharedData.LoadParametros() != "")
							return -1;
					}
					
					Console.WriteLine("Parâmetros Adquiridos.");
	            	
	            	while (true)
	                {                     
	                    try 
	                    {                       	
	            			Monitor monitor = new Monitor(args[0], args[1]);                    	
	            			numEmail = monitor.CheckEmails();                    	                    
	            			if (numEmail ==0)
	            				SharedData.Quit();
	                    } 
	                    catch (Exception e)
	                    {
	                    	DateTime now = DateTime.Now;                    	
	                    	Log.WriteLog("Erro em " + now);
	                    	Log.WriteLog(e.Message);
	                    	SharedData.Quit();
	                    }                    
	                }
				}
	            else if (args.Length == 3)
	            {
	            	SharedData.LoadConstantes(); //Carrega constantes
					
					//Funcionalidade Terceiros: Reply automatico ao cliente
					if (SharedData.gEnviarRespostaAutomatica)
					{
						if(SharedData.LoadParametros() != "")
							return -1;
					}
					
					Console.WriteLine("Parâmetros Adquiridos.");
						
					while (true)
					{                     
						try 
						{
							Monitor monitor = new Monitor(args[0], args[1], args[2]);
							monitor.CheckEmails();
							if (numEmail ==0)
	            				SharedData.Quit();						
						} 
						catch (Exception e)
						{
							DateTime now = DateTime.Now;                    	
							Console.WriteLine("Erro em " + now);
							Console.WriteLine(e.Message);
							SharedData.Quit();
						}
					}
	            }
				else
				{
					Log.WriteLog("Não existem parâmetros suficientes para executar o robô.");
	            	return -1;
				}
			
			}
        	catch (Exception ex)
        	{
        		DateTime now = DateTime.Now;                    	
				Console.WriteLine("Erro em " + now);
				Console.WriteLine(ex.Message + ex.StackTrace);
				return -1;
        	}
        }
               
    }

    public class Monitor
    {
    	public string usuario;
    	public string maquina;
        private string tag;
        private ExchangeService service;
        private string exchangeServiceURL = System.Configuration.ConfigurationManager.AppSettings["EXCHANGE_SERVER_URL"];

        private string nomePastaEntrada;
        private string nomePastaProcessados;        
        private List<string> mailBoxList;
        
        private Folder entradaFolder;
        private Folder processadosFolder;
        
        private MailbotBusiness mailbotBusiness;
        private MobiosBusiness mobiosBusiness;
        
        private Folder rootFolder;
		
        private string tipoGarantia; //funcionalidade de garantias próprias
                
        private Timer timerExchange; //TimeOut para fechar o mailbot caso esse tempo de conexao com o exchange expire
        
        public Monitor(string pEntrada, string pProcessados)
        {
            init(pEntrada, pProcessados);
            ValidaAcesso(usuario, maquina);  //Verifica se pode executar o mailbot [Hara]
            this.mailBoxList = mailbotBusiness.GetMailBoxes(usuario,maquina);
            ValidaCaixas(this.mailBoxList);
            InitTimerExchange();
        }
        
        public Monitor(string pEntrada, string pProcessados, string pTag)
        {
        	SharedData.TAG = pTag;
        	this.tag = pTag;
            init(pEntrada, pProcessados);
            this.mailBoxList = mailbotBusiness.GetMailBoxes(pTag);
            ValidaCaixas(this.mailBoxList);
            InitTimerExchange();
        }
        
        void InitTimerExchange()
        {
        	timerExchange = new Timer();
        	timerExchange.Interval = Convert.ToInt32(System.Configuration.ConfigurationManager.
        	                                         AppSettings["EXCHANGE_TIMEOUT"]);
        	timerExchange.Elapsed += Timer_ExchangeTimeOut;
        	timerExchange.Enabled = false;
        }
        
        private void init(string pEntrada, string pProcessados)
        {
        	this.tag = SharedData.Usuario;
        	usuario = SharedData.Usuario;
        	maquina = SharedData.Maquina;
        	
            //WriteLog("Inicializando Mailbot..." + "\n");
            this.service = new ExchangeService();
        	this.service.UseDefaultCredentials = true;
        	this.service.Url = new Uri(exchangeServiceURL);
        		
            this.nomePastaEntrada = pEntrada;
            this.nomePastaProcessados = pProcessados;

            this.mobiosBusiness = new MobiosBusiness();
            this.mailbotBusiness = new MailbotBusiness();
            
            this.tipoGarantia = SharedData.IsProprias ? mailbotBusiness.GetTipoGarantia(this.nomePastaEntrada) : "";
            
        }
        
        private void ValidaCaixas(List<string> mailboxList)
        {
        	if (mailboxList.Count < 1)
            {
            	Log.WriteLog("ERRO: Nenhuma caixa de e-mail configurada no banco de dados.");                
                Console.ReadLine();
                SharedData.Quit();                
            }

            Log.WriteLog("Caixas de e-mail monitoradas:");
            foreach (string m in mailboxList)
            {
                Log.WriteLog("- " + m);
            }
        }

        public Folder GetFolder(string displayName)
        {
        	// valida existencia da pasta de blacklist
                FindFoldersResults foldersResults = rootFolder.FindFolders(new FolderView(int.MaxValue));
                foreach (Folder folder in foldersResults.Folders) 
                {
                	if (folder.DisplayName == displayName)
                	{
                		return folder;
                	}
                }
                
            	Log.WriteLog("ERRO: Pasta de blacklist não encontrada.");
            	Log.WriteLog("ERRO: Pasta de blacklist não encontrada. Procurando pasta: '" + displayName +"'", true);
                return null;
        }
        
		//Valida se usuario pode executar o mailbot
        public void ValidaAcesso(string usuario, string maquina)
    	{        	        	                	
        	//Verifica nome ou maquina invalidos
        	if (string.IsNullOrEmpty(usuario) || string.IsNullOrEmpty(maquina))
        	{
        		Log.WriteLog("Erro: Não foram identificados o nome do usuario/maquina");
        		Console.ReadLine();        		
        		SharedData.Quit();
        	}        	
        	if (mailbotBusiness.ValidaAcesso(usuario, maquina))
        	{
        		Log.WriteLog("Executando Mailbot.exe com a RACF: "+ usuario +" usando o terminal: " + maquina);        		      		        		
        	}
        	else
        	{
        		Log.WriteLog("Usuário: " + usuario +" sem permissão para executar o Mailbot na maquina: " + maquina +
            		              Environment.NewLine + "Entre em contato com a equipe de automação");
            	//Pausa para ler a mensagem de erro
            	Log.WriteLog("Aperte qualquer tecla para finalizar.");
            	Console.ReadLine();
            	
            	SharedData.Quit();        	      
        	}        	
        }
                
        private void WriteLog(string message, bool Erro = false)
        {
        	Console.WriteLine(message);
        	Log.GravaLog(message, Erro);        	
        }
        
        //Recupera ExchangeVersion
        public ExchangeVersion GetExchangeVersion(string usuario, string maquina, string caixaEntrada)
        {
        	try
        	{
        		string versao= mailbotBusiness.VerificaVersaoExchange(usuario,maquina, caixaEntrada);
        		switch (versao)
        		{
        			case "Exchange_2017":
        				return ExchangeVersion.Exchange2007_SP1;        				
        			case "Exchange_2010_SP1":
        				return ExchangeVersion.Exchange2010_SP1;
        			case "Exchange_2010_SP2":
        				return ExchangeVersion.Exchange2010_SP2;
        			case "Exchange_2010":
        				return ExchangeVersion.Exchange2010;
        			case "Exchange_2013":
        				return ExchangeVersion.Exchange2013;
        			case "Exchange_2016":
        				return ExchangeVersion.Exchange2016;
        			default:
        				return ExchangeVersion.Exchange2007_SP1;
        		}
        	}
        	catch (Exception e)
        	{
        		Log.GravaLog("Erro ao identificar versão do Exchange: " + e.Message);
        		return ExchangeVersion.Exchange2007_SP1;
        	}        	
        }
            
        public int CheckEmails()
        {
        	int totalEmails = 0;
        	
            foreach (string mailBox in mailBoxList)
            {            	
                Log.WriteLog("\n Verificando caixa de e-mail: " + mailBox);
                try
                {
                	if (!System.Configuration.ConfigurationManager.AppSettings["AREA"].Equals("ATENDIMENTO"))
                	{	//Exchange TimeOut para WF Próprias e Terceiros
                		timerExchange.Enabled = true;
	                	timerExchange.Start();
	                	this.service = new ExchangeService(GetExchangeVersion(this.usuario,this.maquina,mailBox));
	                	timerExchange.Enabled = false;
	                	timerExchange.Stop();
                	}
                	else
                	{
	                	this.service = new ExchangeService(GetExchangeVersion(this.usuario,this.maquina,mailBox));
                	}
                }
                catch(Exception e)
                {
            		if(SharedData.IsAtendimento)
            		{
            			this.service = new ExchangeService(ExchangeVersion.Exchange2007_SP1);
            			Log.WriteLog("Erro ao instanciar exchange service. Usando Exchange_2007 por padrão.");
            		}
            		else
            		{
            			this.service = new ExchangeService(ExchangeVersion.Exchange2010_SP1);
            			Log.WriteLog("Erro ao instanciar exchange service. Usando Exchange_2010_SP1 por padrão.");
            		}
            			
                }
	                
        		this.service.UseDefaultCredentials = true;
        		
        		try
        		{
        			service.Url = new Uri(exchangeServiceURL);
                	//this.service.AutodiscoverUrl(mailBox);
        		}
        		catch (AuthenticationException e)
        		{
        			WriteLog("\n Exceção na chamada ao método AutodiscoverUrl. Caixa de e-mail: " + mailBox);
        			throw new AutoDiscoverException(e.Message);
        		}
        		
        		
                Mailbox mailbox = new Mailbox(mailBox);
	            
                // valida acesso a chave de email
                try 
                {
	            	rootFolder = Folder.Bind(service, new FolderId(WellKnownFolderName.MsgFolderRoot, mailbox));
                }
                catch(ServiceVersionException v)
                {
                	WriteLog("Erro ao solicitar versão do Exchange: " + service.RequestedServerVersion);
                	continue;
                }
                catch (Exception e)
                {                	
                    WriteLog("ERRO: Falha ao conectar com a chave de e-mail " + mailBox + ". \n" + e.Message + "\n" + e.StackTrace);
                    continue;
                }
				
                // valida existencia da pasta de entrada e processados
                FindFoldersResults foldersResults = rootFolder.FindFolders(new FolderView(int.MaxValue));
                foreach (Folder folder in foldersResults.Folders) 
                {
                	if (folder.DisplayName == this.nomePastaEntrada)
                	{
                		this.entradaFolder = folder;
                	}
                	else if (folder.DisplayName == this.nomePastaProcessados)
                	{
                		this.processadosFolder = folder;
                	}
                }
                if (this.entradaFolder == null)
                {
                	Log.WriteLog("ERRO: Pasta de entrada não encontrada.");
                	Log.WriteLog("ERRO: Pasta de entrada não encontrada. Procurando pasta: '" + nomePastaEntrada+"'", true);
                }
                if (this.processadosFolder == null)
                {
                	Log.WriteLog("ERRO: Pasta de processados não encontrada.");
                	Log.WriteLog("ERRO: Pasta de processados não encontrada. Procurando pasta: '"+ nomePastaProcessados+"'", true);
                }
                if (this.entradaFolder == null || this.processadosFolder == null)
                {
                	continue;
                }
                
                try
                {
                	// solicita o body em html
                	PropertySet propertySet = new PropertySet(BasePropertySet.FirstClassProperties);
                	propertySet.RequestedBodyType = BodyType.HTML;
                	ItemView itemView = new ItemView(int.MaxValue);
                	itemView.PropertySet = propertySet;
                	
                	// busca os emails
                	FindItemsResults<Item> itemsResult = entradaFolder.FindItems(itemView);
                    Log.WriteLog("E-mails encontrados: " + itemsResult.TotalCount + "\n");
                    totalEmails += itemsResult.TotalCount;
                    
                    
                    foreach (Item item in itemsResult) 
                    {
                    	// solicita o body em text
                    	item.Load(propertySet);
                    	
                    	// trata o email'
                    	HandleEmail((EmailMessage) item, mailBox);
                    }
					
                    // atualiza data e hora da ultima verificacao
                    // this.mailbotBusiness.UpdateMailboxLastCheck(mailBox);
                }
                catch (Exception e)
                {                	
                    Log.WriteLog("ERRO: Erro ao tratar e-mail. \n" + e.Message + "\n" + e.StackTrace, true);
                    continue;
                }
            }
            return totalEmails;
        }
       
        private void HandleEmail(EmailMessage item, string mailbox)
        {
        	int servicoId = 0;
        	bool fluxoAreas = false;
        	bool validarFluxoAreas = false;
        	bool descartado = false;
        	string pastaDestino = "";
            Email newEmail = GetEmail(item, mailbox);
	        bool servicoCriado = false;
	        bool novoServico = false;
	        bool updateWFId = false;
            
            string logMsg = "" +
		    	"Chave: " + newEmail.CaixaEntrada + "\n" +
		    	"De: " + newEmail.Sender_Email + "\n" +
		    	"Para: " + newEmail.To_Email + "\n" +
		    	"Assunto: " + newEmail.Assunto + "\n" +
		    	"Conversation ID: " + newEmail.ID_Conversation + "\n";
            Log.WriteLog(logMsg);
            
            // verifica regras de blacklist
            bool notValidSubject = !this.mailbotBusiness.IsValidSubject(newEmail.Assunto, ref pastaDestino);
            bool notValidDomain  = !this.mailbotBusiness.IsValidDomain(newEmail.Sender_Email, ref pastaDestino);
            bool notAllowedMail  = !this.mailbotBusiness.IsMailAllowed(newEmail.Sender_Email, this.tag);
            if ( (notValidSubject || notValidDomain) && (notAllowedMail) )
            {
            	Log.WriteLog("E-mail descartado por regras de blacklist. \n");
            	descartado = true;
            }
            else
            {
	            // verifica se tem alguma tag no e-mail
	            servicoId = this.mobiosBusiness.VerificaIdServico(newEmail.HTMLBody);
	            if(SharedData.IsAtendimento)
	            {
	            	//Verifica se o objeto é do fluxo das áreas
					fluxoAreas = (servicoId >= 0) && this.mobiosBusiness.VerificaFluxoAreas(servicoId);
					if (fluxoAreas)
						//Valida se é possivel seguir o fluxo de resposta do cliente
						validarFluxoAreas = mobiosBusiness.ValidaFluxoAreas(servicoId);
	            }
	            
				if ((!fluxoAreas) || (!validarFluxoAreas))
	            {
					mobiosBusiness.HandleAbertura(ref servicoId, ref servicoCriado, ref novoServico, newEmail, ref updateWFId);               
	            }
	            else
	            {
	            	
	                mobiosBusiness.AlterarStatusEtapa(
	                    servicoId,
	                    SharedData.ID_STATUS_RESPONDIDO,
	                    SharedData.ID_ETAPA_AGUARDAR_RESPOSTA
	                );
	            	Log.WriteLog("Workflow respondido (Fluxo Áreas): ID " + servicoId + "\n");
	            	PreencheFollowUp(servicoId, SharedData.ID_ETAPA_AGUARDAR_RESPOSTA, newEmail);
	            	mobiosBusiness.PreencheResposta(servicoId, newEmail.HTMLBody);
	            	servicoCriado = true;
	            }
	            
	            // salvar anexos
	            if (newEmail.Attachments.Count > 0 && servicoId > 0)
	            {
	            	SaveAttachments(servicoId, newEmail);
	            }
            }
			
           	string fileName = "";
            if(novoServico)
            {
            	//Adicionar tag invisivel para localizar o email .eml depois    
        		AdicionarTagIdentificacao(ref item, servicoId, false); 
            }
        	
        	SaveEml(ref item, servicoId, false, ref fileName);
        	//Adiciona anexo na base sql
        	if(!string.IsNullOrEmpty(fileName) && servicoId > 0 && !descartado && servicoCriado)            	
        		mobiosBusiness.RegistrarAnexos(new DadosAnexo(Convert.ToString(servicoId), fileName, "0"));
                
        	
        	int servicoFilhoId = mobiosBusiness.GetServicoTo(servicoId);
        	
        	if(servicoFilhoId > 0)
        	{
        		SaveEml(ref item, servicoFilhoId, false, ref fileName);
        		//Adiciona anexo na base sql
	        	if(!string.IsNullOrEmpty(fileName) && servicoFilhoId > 0 && !descartado && servicoCriado)            	
	        		mobiosBusiness.RegistrarAnexos(new DadosAnexo(Convert.ToString(servicoFilhoId), fileName, "0"));
        	}
        	
        	if(novoServico || updateWFId)
        	{
        		// Envio de Resposta Automática apenas para novoServico
	        	if(SharedData.gEnviarRespostaAutomatica && !updateWFId)
	        		ResponderEmail(item, mailbox, servicoId, newEmail);
	            
	        	//Inclusão de ID de abertura em assunto para facilitar encontro de demanda
	        	if(SharedData.gColocarIdAssunto)
	        		ColocarIdAssunto(ref item, servicoId, descartado, updateWFId);
        	}
        	
            try
            {	
            	if(descartado && !String.IsNullOrEmpty(pastaDestino))
            	{
            		var folder = GetFolder(pastaDestino);
            		if(folder != null)
            			item.Move(folder.Id);
            		else
            			item.Move(this.processadosFolder.Id);
            	}
            	else
            	{
	            	// move email para pasta de processados
	                item.Move(this.processadosFolder.Id);
            	}
            }
            catch (Exception ex)
            {            	
                Log.WriteLog("ERRO: Erro ao mover e-mail. \n" + ex.Message+ "\n\n" + ex.StackTrace, true);
            }
		}

		private void AdicionarTagIdentificacao(ref EmailMessage Item, int ServicoId, bool descartado)
        {
        	string tagInvisivel = string.Format ("<div id=Servico{0} style=display:none>_<//div>", ServicoId);              
        	
        	if ((descartado) || (ServicoId == 0)) return;
 			
        	try
 			{
 				PropertyDefinition[] properties = 
        		{
        			EmailMessageSchema.MimeContent,
        			EmailMessageSchema.Body
        		};
        		Item.Load(new PropertySet(properties));
        		Item.Body = Item.Body + tagInvisivel;
        		Item.Update(ConflictResolutionMode.AlwaysOverwrite); 
 			}
 			catch(Exception e)
 			{
 				WriteLog("Erro ao editar e-mail original para adicionar tag de identificação. Erro:" +
 				         e.Message + ". StackTrace: " + e.StackTrace, true);
 			}
        }
	
		private void SaveEml(ref EmailMessage Item, int ServicoId, bool descartado, ref string fileName)
		{
			string path = System.Configuration.ConfigurationManager.AppSettings["ATTACHMENTS_PATH"];
        	if (path.EndsWith(@"\"))
        		path += ServicoId;
        	else
        		path += @"\" + ServicoId;
        	fileName = path + "\\email_original_"+ServicoId+".eml";
        	FileStream fsFileStream = null;
        	                 
        	if ((descartado) || (ServicoId == 0)) return;
 			try
 			{
 				if (!Directory.Exists(path)) Directory.CreateDirectory(path);           	            	
        		Item.Load(new PropertySet(EmailMessageSchema.MimeContent));
 				MimeContent mc = Item.MimeContent;
        		byte[] mcBytes = mc.Content;
 				fsFileStream = new FileStream(fileName,FileMode.OpenOrCreate,FileAccess.ReadWrite);
        		fsFileStream.Write(mcBytes, 0, mcBytes.Length);
 			}
 			catch(Exception e)
 			{
 				WriteLog("Erro ao salvar e-mail original na rede. Erro: "+ e.Message + ". StackTrace: " + e.StackTrace, true);
 			}
 			finally
 			{
 				if (fsFileStream != null)
 				{
 					fsFileStream.Close();
 					fsFileStream.Dispose();
 				}
 			}
		}
        
        void ResponderEmail(EmailMessage item, string mailbox, int servicoId, Email newEmail)
        {
        	EmailMessage temporaria = null;
        	try
    		{
    			ResponseMessage resposta = item.CreateReply(true);
    			resposta.BodyPrefix = String.Format(SharedData.gRespostaAutomatica, mailbox, SharedData.gAssinatura);
    			temporaria = resposta.Save(new FolderId(WellKnownFolderName.Drafts, new Mailbox(mailbox)));
    			var anexos = SharedData.gImagensResposta.Split(';');
    			for (int i = 0; i < anexos.Length; i++)
    			{
    				temporaria.Attachments.AddFileAttachment(anexos[i], SharedData.gPathImagensResposta + anexos[i]);
    				temporaria.Attachments[i].IsInline = true;
    				temporaria.Attachments[i].ContentId = anexos[i];
    			}
    			temporaria.SendAndSaveCopy(new FolderId(WellKnownFolderName.SentItems, new Mailbox(mailbox)));
    			Log.WriteLog(string.Format(@"Resposta Automática Enviada de ID {0}, email de assunto '{1}'", servicoId, newEmail.Assunto));
    		}
    		catch(System.Exception e)
    		{
    			try
    			{
	    			temporaria.Attachments.Clear();
	    			temporaria.SendAndSaveCopy(new FolderId(WellKnownFolderName.SentItems, new Mailbox(mailbox)));
	    			Log.WriteLog(String.Format(@"Enviando Resposta Automática de ID {0}, email de assunto '{1}' sem imagens anexas.", servicoId, newEmail.Assunto),true);
	    			Log.WriteLog("Erro:" + e.Message + ". StackTrace: " + e.StackTrace,true);
    			}
    			catch(Exception e2)
    			{
	    			Log.WriteLog(String.Format(@"ERRO ao enviar Resposta Automática de ID {0}, email de assunto '{1}'", servicoId, newEmail.Assunto),true);
	    			Log.WriteLog("Erro:" + e2.Message + ". StackTrace: " + e2.StackTrace,true);
    			}
    		}
        }
        
        void ColocarIdAssunto(ref EmailMessage Item, int ServicoId, bool descartado, bool updateWFId)
        {
        	if ((descartado) || (ServicoId == 0)) return;
 			
        	int servicoTo = 0;
        	
        	String wfIdString = System.Configuration.ConfigurationManager.AppSettings["PADRAO_ID_ASSUNTO"];
        	try
 			{
 				PropertyDefinition[] properties = 
        		{
        			EmailMessageSchema.Subject
        		};
        		Item.Load(new PropertySet(properties));
        		
        		//Get Servico classificado, se nao encontrar usa o do proprio generico
				servicoTo = mobiosBusiness.GetServicoTo(ServicoId);
				if (servicoTo < 1) 
					servicoTo = ServicoId;
				
        		if (updateWFId)
        		{	//Caso em que usuario respondeu cliente pelo e-mail na pasta Processados (Assunto tem a tag #WF12345#)
        			//Localizar o padrao do ID:
        			var match = Regex.Match(Item.Subject, "#WF[^#]+#");
        			if (match.Success)
        			{	//Atualiza a tag ID
        				String oldWFId = match.Captures[0].Value;
        				String newWFId = String.Format("#WF{0}#", servicoTo);
        				Item.Subject = Item.Subject.Replace(oldWFId, newWFId);
        				Log.GravaLog("ASSUNTO_ID Atualizado com sucesso");
        			}
        			else
        			{	//Se nao encontrou a tag, insere nova tag de ID
        				Item.Subject = String.Format(wfIdString, servicoTo, Item.Subject);
        			}
        		}
        		else
        		{	//Nova Demanda: Insere novo WFId
        			Item.Subject = String.Format(wfIdString, servicoTo, Item.Subject);
    				Log.GravaLog("ASSUNTO_ID Inserido com sucesso");
        		}
        		Item.Update(ConflictResolutionMode.AlwaysOverwrite);
 			}
 			catch(Exception e)
 			{
 				WriteLog("Erro ao editar e-mail original para adicionar ID no assunto. Erro:" +
 				         e.Message + ". StackTrace: " + e.StackTrace, true);
 			}
        }
        
        void PreencheFollowUp(int servicoId, int idEtapa, Email newEmail)
        {        	
            // cria followup com o retorno do cliente
            FollowUp follow = new FollowUp();
            follow.ID_Servico = servicoId;
            follow.DataCriacao = follow.DataAlteracao = DateTime.Now;
            follow.ID_Fluxo = idEtapa; 
            follow.LOGIN = System.Configuration.ConfigurationManager.AppSettings["LOGIN_ROBO"];
			
            //teste para guardar em html
            string mensagemTxt = newEmail.HTMLBody;
            follow.FollowUpEtapa = " De: " + newEmail.Sender_Email + Environment.NewLine +
                                   " Recebida em: " + newEmail.ReceivedTime + Environment.NewLine +
                                   " Assunto: " + newEmail.Assunto + Environment.NewLine + Environment.NewLine +
            						" " + HtmlFilter.ConvertToPlainText(mensagemTxt);
            
            mobiosBusiness.PreencheFollowUp(follow);
        }

        private Email GetEmail(EmailMessage mail, string mailbox)
        {        
            Email email = new Email();
            email.CaixaEntrada = mailbox;
            email.TipoGarantia = tipoGarantia;
            email.Sender_Email = GetSender(mail);
            email.To_Email = GetTo(mail);
            email.CC = GetCC(mail);
            email.Body = HtmlFilter.ConvertToPlainText(!String.IsNullOrEmpty(mail.Body.Text)? mail.Body.Text : " ");
            email.HTMLBody = !String.IsNullOrEmpty(mail.Body.Text)? mail.Body.Text : " ";
            email.ReceivedTime = mail.DateTimeReceived;
            email.Attachments = mail.Attachments;
            email.Assunto = !String.IsNullOrEmpty(mail.ConversationTopic) ? mail.ConversationTopic: " ";            
            try
            {
            	email.ID_Conversation = mail.ConversationId.ToString();	            	            	
            }
            catch (Exception) // suportado apenas a partir do exchange 2010 
            {
            	email.ID_Conversation = null;
            }
            email.Celula_Responsavel = this.mailbotBusiness.GetCelulaResponsavel(email.CaixaEntrada, email.Sender_Email, email.Assunto);
            return email;
        }
        
        private string GetSender(EmailMessage mail)
        {
        	return ResolveEmail(mail.Sender.Address);
        }
        
        private String GetTo(EmailMessage mail)
        {
        	if (mail.ToRecipients.Count > 0)
        	{
        		return ResolveEmails(mail.ToRecipients);
        	}
        	return ResolveEmail(mail.ReceivedRepresenting.Address);
        }
        
        private String GetCC(EmailMessage mail)
        {
        	return ResolveEmails(mail.CcRecipients);
        }
        
        private string ResolveEmail(EmailAddress emailAddress)
        {
            try
            {
                return new MailAddress(emailAddress.Address).Address;

            }
            catch (Exception)
            {
                try
                {
                    return service.ResolveName(emailAddress.Address)[0].Mailbox.Address;
                }
                catch (Exception)
                {
                    return emailAddress.Address;
                }
            }
        }
        
        private string ResolveEmails(EmailAddressCollection addresses)
        {
        	string mails = "";
        	foreach (EmailAddress address in addresses) 
        	{
        		mails += ResolveEmail(address.Address) + ";";
        	}
        	return mails;
        }
        
        private void SaveAttachments(int servicoId, Email newEmail)
        {
            try
            {
                string path = System.Configuration.ConfigurationManager.AppSettings["ATTACHMENTS_PATH"] + @"\" + servicoId;
                System.IO.Directory.CreateDirectory(path);
                int i = 0;
                int j = 2;
                foreach (Microsoft.Exchange.WebServices.Data.Attachment att in newEmail.Attachments) 
                {
                	att.Load();
                	string attName = "";
                	attName = FilenameFormater.FormatFilename(att.Name);
                	attName = path + @"\" + attName;
                	
                	//Verifica se arquivo existe na pasta                	
                	if (File.Exists(attName))
                	{
                		Log.WriteLog("Arquivo com o mesmo nome já existe no diretório: " + attName);
                		try{
                			string filename = Path.GetFileName(attName);
                			string[] filepart = filename.Split('.');
                			if (filepart !=null)
                			{
                				filepart[0] += "("+ j +")";
                				if (filepart.Length > 0)
                					filename = filepart[0] +"."+ filepart[1];
                				attName = Path.GetDirectoryName(attName) +"\\"+ filename;
	                		}
							else
							{
								attName += "(" + j + ")";
							}
							j++;
                		}
                		catch(Exception)
                		{
                			Log.WriteLog ("Erro ao adicionar ("+ j +") ao arquivo com nome repetido");
                			attName += "("+j+")";
                		}                		 
                			                		                		                	
                	}
                	
                	if (att is FileAttachment) 
                	{
                		FileStream fileStream = new FileStream(attName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                		FileAttachment fAttch = (Microsoft.Exchange.WebServices.Data.FileAttachment) att;
                		fAttch.Load(fileStream);
                		fileStream.Close();
                	}
                	else if (att is ItemAttachment)
                	{
                		ItemAttachment iAttch = (Microsoft.Exchange.WebServices.Data.ItemAttachment) att;
                		iAttch.Load(new PropertySet(EmailMessageSchema.MimeContent));
                		MimeContent mc = iAttch.Item.MimeContent;
                		byte[] mcBytes = mc.Content;
                		attName = attName + ".eml";
                		FileStream fileStream = new FileStream(attName, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                		fileStream.Write(mcBytes, 0, mcBytes.Length);
                		fileStream.Close();
                	}
                	else
                	{
                		Log.WriteLog("ERRO: Tipo de anexo não reconhecido.");
                		Log.WriteLog("ERRO: Tipo de anexo não reconhecido. Nome do Arquivo: " + att.Name, true);
                	}
                
                	
                	this.mobiosBusiness.RegistrarAnexos(new DadosAnexo(Convert.ToString(servicoId), attName, "0"));
                	i++;
                }
            }
            catch (Exception ex)
            {
            	Log.WriteLog("Erro ao salvar anexos do e-mail. \n");
                Log.WriteLog("Erro ao salvar anexos do e-mail. \n Erro: " + ex.Message + "\n\n" + ex.StackTrace, true);
            }
        }
        
        void Timer_ExchangeTimeOut(object sender, EventArgs e)
        {
        	SharedData.Quit();
        }
    }

    
}
