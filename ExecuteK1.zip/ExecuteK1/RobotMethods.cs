﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Linq;
using System.Globalization;
using System.Web.Script.Serialization;

namespace ExecuteK1
{
	public class RobotMethods
	{

		//07/2017
		//Robô: execução dos robôs.
		
		public bool CallRobot(  string enderecoAutomate, string enderecoRobo, ref string parameters)
		{
			
				
			string output = "";
			bool automateSitesConclude = false;
			string msgOutput = null;	
			
			automateSitesConclude = ExecuteAutomateSites(enderecoAutomate, enderecoRobo, parameters, ref output);

			if (automateSitesConclude == true)
			{
				msgOutput = "Robô executado com sucesso.";
			}
			else if (automateSitesConclude == false)
			{
				msgOutput = "Robô falhou: " + output;
			}
			
			return automateSitesConclude;
		}

		public bool ExecuteAutomateSites(string enderecoAutomate, string enderecoRobo,  string parameters, ref string output)
		{
			bool succeed;
			Dictionary<string, string> variaveis;
			
			Dictionary<string, string> outputs = new Dictionary<string, string>();
			System.Diagnostics.Process process = new System.Diagnostics.Process();

			try
			{
				// Redirect the output stream of the child process.
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.FileName = enderecoAutomate;
				process.StartInfo.Arguments = parameters;
				process.StartInfo.StandardOutputEncoding = Encoding.GetEncoding(850);

				// Do not wait for the child process to exit before reading to the end of its redirected stream.
				process.Start();

				// Read the output stream first and then wait.
				output = process.StandardOutput.ReadToEnd();

				JavaScriptSerializer parser = new JavaScriptSerializer();
				variaveis = parser.Deserialize<Dictionary<string, string>>(output);

				string resultado = variaveis["result"];
				string msgErro = null;
				string msgSucesso = null;
				

				process.WaitForExit();

				if (resultado == "1")
				{
					output = "Robô executado com sucesso";
					succeed = true;
				}
				else
				{
					output = "Erro na execução do robô";
					succeed = false;
				}
			}
			catch (Exception e)
			{
				succeed = false;
				output = "Erro: " + e.Message.ToString();
			}
			return succeed;
		}

	}
}
