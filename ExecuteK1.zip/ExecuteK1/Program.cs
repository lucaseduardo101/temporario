﻿/*
 * Created by SharpDevelop.
 * User: rodbrun
 * Date: 05/01/2018
 * Time: 14:03
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Data;
using System.IO;
using System.Threading;
using System.Threading.Tasks;


 
namespace ExecuteK1
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Hello World!");
			
			// TODO: Implement Functionality Here
			Parallel.For( 0, 5, index => { Console.WriteLine("Press any key to continue . . . " + index.ToString());	}   );
			Console.ReadKey(true);
			
			String enderecoAutomate = "C:\\Users\\rodbrun\\Documents\\AutomateSites\\AutomateSites\\AutomateSites\\bin\\Debug\\AutomateSites.exe";
			String enderecoRobo = "C:\\Users\\rodbrun\\Workspace\\RendaFixa\\RendaFixa\\old\\RC9_Conciliacao_Eventos\\LerCodigosFundosK1.xlsx";
			String parameters = "";
			RobotMethods.CallRobot( enderecoAutomate, enderecoRobo, ref parameters);
			
			
		}


	}
}
	